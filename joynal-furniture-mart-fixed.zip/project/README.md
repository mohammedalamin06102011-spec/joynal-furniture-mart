# জয়নাল ফার্নিচার মার্ট — Joynal Furniture Mart

Responsive Bengali furniture catalogue with a separate admin area, Express API, JSON data store, media uploads and advertisement placements.

## Requirements
- Node.js 22 or newer (Vite 8 requires a modern Node runtime)
- A persistent writable disk for `server/data/store.json` and `uploads/`

## Local setup
1. Install dependencies: `npm install`
2. Copy `.env.example` to `.env` and set unique `ADMIN_PASSWORD`, `ADMIN_RECOVERY_CODE`, and your real `ADMIN_EMAIL`.
3. Start the combined API + Vite development server: `npm run dev`
4. Open `http://localhost:3000` and `/admin/login` for the admin login.

The initial admin account is provisioned from environment variables only when the data store has no admin user. There are no built-in public default credentials. If a data store was previously initialized without an admin, set the secrets before first use.

## Production build and start
1. Set `NODE_ENV=production`, `ADMIN_USERNAME`, `ADMIN_EMAIL`, `ADMIN_PASSWORD`, `ADMIN_RECOVERY_CODE`, and `PORT` in the host's private environment/secrets settings.
2. Run `npm ci` (if a package lock is present; otherwise `npm install`).
3. Run `npm run build`.
4. Start with `npm start`.
5. Configure the hosting provider to preserve `server/data/store.json` and `uploads/` between deployments/restarts. Without persistent storage, products, inquiries, and uploaded images may be lost on some hosts.
6. Use HTTPS and a host that supports a long-running Node.js process. This is not a static-only HTML deployment.

## Image paths
Bundled images live in `public/images/` so they remain available after a production Vite build. User-uploaded images are stored under `uploads/`; the host must persist that directory.

## Ads
The admin panel manages the site's own banner placements and click/impression tracking. Third-party ad networks require their own approved publisher account and a valid network-provided ad snippet/placement ID; configure those only after the site is hosted on its final domain.

## Important
This project uses a JSON file as its database. It is suitable for a small catalogue on a single persistent Node instance, not for multi-instance/serverless hosting without replacing the data layer with a shared database and persistent object storage. Back up the data file and uploads regularly.
