import fs from 'fs';
import path from 'path';
import crypto from 'crypto';

export interface Category {
  id: string;
  slug: string;
  name_bn: string;
  name_en: string;
  description_bn: string;
  cover_image: string;
  display_order: number;
  is_active: boolean;
}

export interface Product {
  id: string;
  slug: string;
  category_slug: string;
  name_bn: string;
  name_en: string;
  price: number;
  discount_price?: number;
  short_desc_bn: string;
  full_desc_bn: string;
  main_image: string;
  additional_images: string[];
  dimensions: string;
  materials: string;
  colors: string[];
  in_stock: boolean;
  is_popular: boolean;
  is_featured: boolean;
  created_at: string;
}

export interface Advertisement {
  id: string;
  title: string;
  placement:
    | 'homepage_top'
    | 'homepage_between_sections'
    | 'homepage_below_featured'
    | 'homepage_above_footer'
    | 'category_top'
    | 'category_grid'
    | 'category_bottom'
    | 'product_below_info'
    | 'product_below_related';
  image_url: string;
  destination_url: string;
  start_date: string;
  end_date: string;
  is_enabled: boolean;
  row_interval: number; // e.g. 2 or 3 rows
  display_order?: number;
  impressions?: number;
  clicks?: number;
  third_party_code?: string;
}

export interface WebsiteSettings {
  site_name_bn: string;
  site_name_en: string;
  slogan_bn: string;
  phone_primary: string;
  phone_secondary: string;
  whatsapp_number: string;
  email: string;
  address_bn: string;
  address_en: string;
  facebook_url: string;
  announcement_text: string;
  hero_title: string;
  hero_subtitle: string;
  hero_image: string;
  about_story_bn: string;
  warranty_policy_bn: string;
  hero_cta_text?: string;
  hero_cta_link?: string;
  currency_symbol?: string;
  seo_title?: string;
  seo_description?: string;
  footer_text_bn?: string;
  recovery_code_hash?: string;
  recovery_code_salt?: string;
}

export interface CustomerInquiry {
  id: string;
  customer_name: string;
  phone: string;
  message: string;
  product_id?: string;
  product_name?: string;
  created_at: string;
  status?: 'unread' | 'read' | 'contacted';
}

export interface AdminUser {
  id: string;
  username: string;
  email: string;
  password_hash: string;
  salt: string;
  password_salt?: string;
  role: 'superadmin' | 'editor';
  created_at: string;
  last_login?: string;
}

export interface AdminSession {
  token: string;
  user_id: string;
  username?: string;
  role?: 'superadmin' | 'editor';
  created_at: string | number;
  expires_at: number;
}

export interface MediaItem {
  id: string;
  filename: string;
  original_name: string;
  mime_type: string;
  size?: number;
  file_size?: number;
  url: string;
  uploaded_at?: string;
  created_at?: string;
  usage_count?: number;
}

export interface HomepageSectionConfig {
  id: string;
  title_bn: string;
  is_visible: boolean;
  order: number;
}

export interface HomepageConfig {
  hero_badge_bn?: string;
  hero_heading_bn?: string;
  hero_subheading_bn?: string;
  hero_image_url?: string;
  hero_cta_text_bn?: string;
  hero_cta_link?: string;
  announcement_bar_enabled?: boolean;
  announcement_bar_text_bn?: string;
  featured_category_slugs?: string[];
  popular_product_ids?: string[];
  featured_product_ids?: string[];
  sections_order?: HomepageSectionConfig[];
}

export interface DatabaseSchema {
  categories: Category[];
  products: Product[];
  advertisements: Advertisement[];
  settings: WebsiteSettings;
  inquiries: CustomerInquiry[];
  admin_users: AdminUser[];
  admin_sessions: AdminSession[];
  media_files: MediaItem[];
  homepage_config: HomepageConfig;
}

export const UPLOADS_DIR = path.resolve(process.cwd(), 'uploads');

export function hashPassword(password: string): { hash: string; salt: string } {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return { hash, salt };
}

export function verifyPassword(password: string, hash: string, salt: string): boolean {
  try {
    const calculated = crypto.scryptSync(password, salt, 64).toString('hex');
    return crypto.timingSafeEqual(Buffer.from(calculated, 'hex'), Buffer.from(hash, 'hex'));
  } catch {
    return false;
  }
}

export function generateSessionToken(): string {
  return crypto.randomBytes(32).toString('hex');
}

const DATA_DIR = path.resolve(process.cwd(), 'server', 'data');
const DB_FILE = path.resolve(DATA_DIR, 'store.json');

const INITIAL_DATA: DatabaseSchema = {
  settings: {
    site_name_bn: 'জয়নাল ফার্নিচার মার্ট',
    site_name_en: 'Joynal Furniture Mart',
    slogan_bn: 'অভিজাত ও আধুনিক টেকসই কাঠের ফার্নিচার সম্ভার',
    phone_primary: '+880 1712-345678',
    phone_secondary: '+880 1812-987654',
    whatsapp_number: '8801712345678',
    email: 'info@joynalfurniture.com',
    address_bn: 'দোকান নং ১২-১৫, প্রধান সড়ক, মিরপুর-১০ গোলচত্বর, ঢাকা-১২১৬',
    address_en: 'Shop 12-15, Main Road, Mirpur-10 Circle, Dhaka-1216, Bangladesh',
    facebook_url: 'https://facebook.com/joynalfurnituremart',
    announcement_text: '✨ জয়নাল ফার্নিচার মার্ট — সারা বাংলাদেশে নিরাপদ হোম ডেলিভারি ও আধুনিক কাঠে তৈরি আসবাবপত্র | ১০০% অকৃত্রিম সেগুন ও মেহগনি কাঠ!',
    hero_title: 'আপনার স্বপ্নের গৃহসজ্জায় ঐতিহ্যের সেরা কাঠের ফার্নিচার',
    hero_subtitle: 'চিটাগাং সেগুন ও সিজনড মেহগনি কাঠে তৈরি শৈল্পিক কারুকার্যখচিত খাট, সোফা, ডাইনিং ও গৃহসজ্জা সামগ্রী। তিন দশকের আস্থার নাম।',
    hero_image: '/images/hero_furniture_cover_1793102992976.jpg',
    about_story_bn: 'জয়নাল ফার্নিচার মার্ট দীর্ঘ ৩০ বছর ধরে গুণগত মান ও সততার সাথে বাংলাদেশের গৃহসজ্জা ও কর্পোরেট প্রতিষ্ঠানে কাঠজাত ফার্নিচার সরবরাহ করে আসছে। আমাদের দক্ষ কারিগরদের নিখুঁত হাত ও আধুনিক মেশিনের সমন্বয়ে প্রস্তুত প্রতিটি ফার্নিচারে রয়েছে স্থায়িত্ব ও নান্দনিক আভিজাত্যের নিশ্চয়তা। চিটাগাং সেগুন, গামারি ও সিজনিং মেহগনি কাঠ ব্যবহার করে আমরা প্রতিটি গ্রাহকের পছন্দমাফিক আসবাব তৈরি করে থাকি।',
    warranty_policy_bn: 'কাঠের ঘুণের বিরুদ্ধে ১৫ বছরের গ্যারান্টি এবং ফিনিশিং সার্ভিসের জন্য ১ বছরের ফ্রি ওয়ারেন্টি।'
  },
  categories: [
    {
      id: 'cat-1',
      slug: 'bed',
      name_bn: 'খাট',
      name_en: 'Bed',
      description_bn: 'রয়্যাল কারুকাজ ও আধুনিক ডিজাইনের মজবুত চিটাগাং সেগুন ও মেহগনি কাঠের খাট।',
      cover_image: '/images/category_bed_teak_1793102993462.jpg',
      display_order: 1,
      is_active: true
    },
    {
      id: 'cat-2',
      slug: 'sofa',
      name_bn: 'সোফা',
      name_en: 'Sofa',
      description_bn: 'লিভিং রুমের সৌন্দর্য বৃদ্ধি করার জন্য আরামদায়ক কুশন ও কাঠের ক্লাসিক সোফা সেট।',
      cover_image: '/images/category_sofa_luxury_1793102994389.jpg',
      display_order: 2,
      is_active: true
    },
    {
      id: 'cat-3',
      slug: 'almirah',
      name_bn: 'আলমারি',
      name_en: 'Almirah & Wardrobe',
      description_bn: 'বহুস্তর বিশিষ্ট ড্রয়ার ও লকার সুবিধাযুক্ত টেকসই ও নিরাপদ কাঠের আলমারি।',
      cover_image: '/images/category_wardrobe_almirah_1793102994788.jpg',
      display_order: 3,
      is_active: true
    },
    {
      id: 'cat-4',
      slug: 'dressing-table',
      name_bn: 'ড্রেসিং টেবিল',
      name_en: 'Dressing Table',
      description_bn: 'আকর্ষণীয় আয়না, স্টোরেজ ড্রয়ার ও ম্যাচিং টুল সহ মার্জিত কাঠের ড্রেসিং টেবিল।',
      cover_image: '/images/category_dressing_table_1793103050374.jpg',
      display_order: 4,
      is_active: true
    },
    {
      id: 'cat-5',
      slug: 'dining-table',
      name_bn: 'ডাইনিং টেবিল',
      name_en: 'Dining Table',
      description_bn: 'পরিবারের সাথে খাবার সময়কে বিশেষ করে তুলতে ৪, ৬ বা ৮ সিটের আকর্ষণীয় ডাইনিং টেবিল।',
      cover_image: '/images/category_dining_table_1793102995112.jpg',
      display_order: 5,
      is_active: true
    },
    {
      id: 'cat-6',
      slug: 'showcase',
      name_bn: 'শোকেস',
      name_en: 'Showcase Cabinet',
      description_bn: 'গ্লাস ডোর ও প্রিমিয়াম লাইটিং সুবিধা সহ ড্রয়িং রুমের আকর্ষণীয় কাঠের শোকেস।',
      cover_image: '/images/category_showcase_cabinet_1793103050887.jpg',
      display_order: 6,
      is_active: true
    },
    {
      id: 'cat-7',
      slug: 'other',
      name_bn: 'অন্যান্য ফার্নিচার',
      name_en: 'Other Furniture',
      description_bn: 'টি-টেবিল, রকিং চেয়ার, বুকশেলফ, টিভি ক্যাবিনেট ও অফিস ডেস্ক।',
      cover_image: '/images/hero_furniture_cover_1793102992976.jpg',
      display_order: 7,
      is_active: true
    }
  ],
  products: [
    {
      id: 'prod-bed-01',
      slug: 'royal-chittagong-teak-king-bed',
      category_slug: 'bed',
      name_bn: 'রয়্যাল চিটাগাং সেগুন কিং খাট',
      name_en: 'Royal Chittagong Teak King Bed',
      price: 68500,
      discount_price: 64000,
      short_desc_bn: '১০০% খাটি চিটাগাং সেগুন কাঠে হাতে খোদাই করা রাজকীয় কিং সাইজ খাট।',
      full_desc_bn: 'আমাদের অন্যতম সেরা হস্তনির্মিত মাস্টারপিস। চিটাগাং সেগুন কাঠের নিখুঁত কারুকাজ ও দীর্ঘস্থায়ী প্রিমিয়াম হ্যান্ড-বার্নিশ ফিনিশ। এই খাটের হেডবোর্ড ও লেগবোর্ডে ঐতিহ্যবাহী ইসলামিক ও বাঙালি ফুল-লতার নকশা খোদাই করা হয়েছে। বিছানার শক্ত পায়া ও ফ্রেম সর্বোচ্চ ওজন ও চাপ বহনে সক্ষম।',
      main_image: '/images/category_bed_teak_1793102993462.jpg',
      additional_images: [
        '/images/category_bed_teak_1793102993462.jpg',
        '/images/hero_furniture_cover_1793102992976.jpg'
      ],
      dimensions: '৬ ফুট × ৭ ফুট (কিং সাইজ), হেডবোর্ড উচ্চতা ৫০ ইঞ্চি',
      materials: 'চিটাগাং সেগুন কাঠ (C.T.G Teak Solid Wood) ও হেভি ডিউটি গর্জন বিট',
      colors: ['ন্যাচারাল সেগুন বার্নিশ', 'অ্যান্টিক ব্রাউন পলিশ', 'ডার্ক ওয়ালনাট'],
      in_stock: true,
      is_popular: true,
      is_featured: true,
      created_at: '2026-03-15T10:00:00.000Z'
    },
    {
      id: 'prod-bed-02',
      slug: 'classic-mahogany-box-bed',
      category_slug: 'bed',
      name_bn: 'ক্লাসিক বক্স মেহগনি সেমি-বক্স খাট',
      name_en: 'Classic Mahogany Semi-Box Bed',
      price: 45000,
      discount_price: 42000,
      short_desc_bn: 'সিজনিং ও ট্রিটমেন্ট করা মেহগনি কাঠের আধুনিক ফ্ল্যাট প্যানেল খাট।',
      full_desc_bn: 'মর্ডান অ্যাপার্টমেন্ট ও বেডরুমের জন্য পারফেক্ট পরিমিত ডিজাইনের খাট। সম্পূর্ণ আধুনিক ড্রয়ার এবং ইন্টারনাল স্টোরেজ সুবিধা সমন্বিত। দীর্ঘমেয়াদি রাসায়নিক ট্রিটমেন্টের কারণে কখনোই ঘুণের উপদ্রব হয় না।',
      main_image: '/images/category_bed_teak_1793102993462.jpg',
      additional_images: ['/images/category_bed_teak_1793102993462.jpg'],
      dimensions: '৫ ফুট × ৭ ফুট (কুইন সাইজ)',
      materials: 'সিজনড মেহগনি কাঠ ও গর্জন প্লাই সাইড সাপোর্ট',
      colors: ['গ্লসি রেডিশ মেহগনি', 'ম্যাট ন্যাচারাল কাঠ'],
      in_stock: true,
      is_popular: false,
      is_featured: false,
      created_at: '2026-04-10T12:00:00.000Z'
    },
    {
      id: 'prod-sofa-01',
      slug: 'luxury-l-shape-fabric-teak-sofa',
      category_slug: 'sofa',
      name_bn: 'লাক্সারি এল-শেপ উডেন ফ্যাব্রিক সোফা সেট',
      name_en: 'Luxury L-Shape Wooden Fabric Sofa Set',
      price: 78000,
      discount_price: 72500,
      short_desc_bn: 'সেগুন কাঠের মজবুত বডি ও হাই-ডেনসিটি ফোমযুক্ত ৭ সিটার এল-শেপ সোফা।',
      full_desc_bn: 'বসার ঘরে আধুনিক আভিজাত্য এনে দেবে এই চমৎকার এল-শেপ সোফা। কাঠামোর চারপাশে মজবুত সেগুন কাঠের এক্সটেরিয়র ফ্রেম এবং দীর্ঘস্থায়ী আরামের জন্য প্রিমিয়াম ডেনসিটি ফোম ও ওয়াটার-রেপেলেন্ট ফেব্রিক ব্যবহার করা হয়েছে। সেটটিতে পাচ্ছেন ৩+২+কর্নার+১ সিটিং কম্বিনেশন।',
      main_image: '/images/category_sofa_luxury_1793102994389.jpg',
      additional_images: [
        '/images/category_sofa_luxury_1793102994389.jpg',
        '/images/hero_furniture_cover_1793102992976.jpg'
      ],
      dimensions: 'দৈর্ঘ্য ৯ ফুট × প্রস্থ ৬ ফুট (এল-শেপ কর্নার অ্যালাইনমেন্ট)',
      materials: 'চিটাগাং সেগুন কাঠ স্ট্রাকচার, হাই-ডেনসিটি রিবাউন্ডেড ফোম ও বেলজিয়াম ভেলভেট ফেব্রিক',
      colors: ['ওয়ার্ম ওটমিল বেইজ', 'কফি ব্রাউন', 'রয়েল নেভি ব্লু'],
      in_stock: true,
      is_popular: true,
      is_featured: true,
      created_at: '2026-03-12T09:30:00.000Z'
    },
    {
      id: 'prod-sofa-02',
      slug: 'traditional-carved-wooden-sofa-3-2-1',
      category_slug: 'sofa',
      name_bn: 'ঐতিহ্যবাহী নকশাদার সেগুন সোফা (৩+১+১)',
      name_en: 'Traditional Carved Teak Sofa Set (3+1+1)',
      price: 85000,
      discount_price: 79900,
      short_desc_bn: 'হাতে নকশা করা চিটাগাং সেগুন কাঠের ৫ সিটার ঐতিহ্যবাহী সোফা ও সেন্টার টি-টেবিল।',
      full_desc_bn: 'বাংলার চিরায়ত ড্রয়িংরুমের গাম্ভীর্য ও অহংকার। পুরো সোফার আর্ম ও ব্যাকরেস্টে অত্যন্ত নিখুঁত খোদাই করা হস্তশিল্প। এর সাথে অন্তর্ভুক্ত রয়েছে একটি নিখুঁত ম্যাচিং টি-টেবিল। কুশনগুলো সম্পূর্ণ খোলা যায় এবং ড্রাই-ক্লিন উপযোগী।',
      main_image: '/images/hero_furniture_cover_1793102992976.jpg',
      additional_images: ['/images/hero_furniture_cover_1793102992976.jpg'],
      dimensions: '৩ সিটার: ৭২" × ৩২", ১ সিটার: ৩২" × ৩২"',
      materials: '১০০% অরিজিনাল সি.টি.জি সেগুন কাঠ',
      colors: ['অরিজিনাল সেগুন কালার', 'অ্যান্টিক পলিশ'],
      in_stock: false,
      is_popular: true,
      is_featured: false,
      created_at: '2026-02-18T14:15:00.000Z'
    },
    {
      id: 'prod-almirah-01',
      slug: 'handcrafted-4-door-teak-wardrobe',
      category_slug: 'almirah',
      name_bn: 'হ্যান্ডক্রাফটেড ৪-পাল্লা রাজকীয় সেগুন আলমারি',
      name_en: 'Handcrafted 4-Door Royal Teak Wardrobe',
      price: 92000,
      discount_price: 88000,
      short_desc_bn: '৪ পাল্লার বিশাল স্টোরেজ ও লকার সমন্বিত প্রিমিয়াম সেগুন কাঠের আলমারি।',
      full_desc_bn: 'আপনার মূল্যবান পোশাক, স্বর্ণালংকার ও প্রয়োজনীয় জিনিসপত্র নিরাপদে গুছিয়ে রাখার সর্বাধুনিক ৪-পাল্লার আলমারি। এতে রয়েছে গোপন লকার সিস্টেম, একাধিক ড্রয়ার ও হ্যাঙ্গার স্পেস। পাল্লার উপরে আকর্ষণীয় কাঠের ফ্রেম নকশা ও অ্যান্টি-রাস্ট ব্রাস হ্যান্ডেল।',
      main_image: '/images/category_wardrobe_almirah_1793102994788.jpg',
      additional_images: ['/images/category_wardrobe_almirah_1793102994788.jpg'],
      dimensions: 'উচ্চতা ৬.৫ ফুট × প্রস্থ ৬ ফুট × গভীরতা ২২ ইঞ্চি',
      materials: 'চিটাগাং সেগুন কাঠ বডি ও মজবুত ড্রয়ার চ্যানেল',
      colors: ['প্রাকৃতিক বার্নিশ', 'অ্যান্টিক ডার্ক পলিশ'],
      in_stock: true,
      is_popular: true,
      is_featured: true,
      created_at: '2026-01-20T11:00:00.000Z'
    },
    {
      id: 'prod-dining-01',
      slug: 'prestige-6-chair-mahogany-dining-set',
      category_slug: 'dining-table',
      name_bn: 'প্রেস্টিজ ৬-চেয়ার মেহগনি ডাইনিং টেবিল সেট',
      name_en: 'Prestige 6-Chair Mahogany Dining Table Set',
      price: 65000,
      discount_price: 59500,
      short_desc_bn: '১০ মিমি টেম্পার্ড গ্লাস টপ ও ৬টি আরামদায়ক কুশন চেয়ার সহ ডাইনিং সেট।',
      full_desc_bn: 'একটি অভিজাত ডাইনিং স্পেস গড়ে তোলার জন্য সুদৃশ্য এই টেবিল সেট। টেবিলের উপরিভাগে ১০ মিমি পুরু ফ্ল্যাট পলিশড গ্লাস টপ এবং নিচে আকর্ষণীয় কাঠের কারুকাজ। প্রতিটি চেয়ারে এরগনোমিক কার্ভড ব্যাকরেস্ট ও দীর্ঘক্ষণ আরামদায়ক বসার কুশন রয়েছে।',
      main_image: '/images/category_dining_table_1793102995112.jpg',
      additional_images: ['/images/category_dining_table_1793102995112.jpg'],
      dimensions: 'টেবিল: ৬ ফুট × ৩.৫ ফুট, উচ্চতা ৩০ ইঞ্চি',
      materials: 'সিজনড মেহগনি কাঠ, ১০ মিমি টেম্পার্ড গ্লাস, ডুরো ফোম কুশন',
      colors: ['রয়্যাল মেহগনি পলিশ', 'ওয়ালনাট ফিনিশ'],
      in_stock: true,
      is_popular: true,
      is_featured: true,
      created_at: '2026-02-05T15:00:00.000Z'
    },
    {
      id: 'prod-dressing-01',
      slug: 'classic-oval-mirror-teak-dressing-table',
      category_slug: 'dressing-table',
      name_bn: 'ক্লাসিক ওভাল মিরর সেগুন ড্রেসিং টেবিল',
      name_en: 'Classic Oval Mirror Teak Dressing Table',
      price: 36000,
      discount_price: 33500,
      short_desc_bn: 'বড় ওভাল বেলজিয়াম গ্লাস আয়না ও ৩টি সুপরিসর ড্রয়ারযুক্ত ড্রেসিং টেবিল ও টুল।',
      full_desc_bn: 'রুচিশীল নারীদের প্রতিদিনের সাজসজ্জার বিশ্বস্ত সঙ্গী। বেলজিয়াম থেকে আমদানিকৃত পরিষ্কার প্রতিফলনযুক্ত ফেস মিরর। কসমেটিকস ও অলংকারাদি সংরক্ষণের জন্য মসৃণ ড্রয়ার এবং সাথে থাকছে আরামদায়ক গদিযুক্ত কাঠের টুল।',
      main_image: '/images/category_dressing_table_1793103050374.jpg',
      additional_images: ['/images/category_dressing_table_1793103050374.jpg'],
      dimensions: 'উচ্চতা ৬ ফুট × প্রস্থ ৩ ফুট × গভীরতা ১৮ ইঞ্চি',
      materials: 'চিটাগাং সেগুন কাঠ, ৫ মিমি বেলজিয়াম ফ্ল্যাট গ্লাস',
      colors: ['ন্যাচারাল উড গ্লস', 'অ্যান্টিক ব্রাউন'],
      in_stock: true,
      is_popular: true,
      is_featured: false,
      created_at: '2026-03-01T10:30:00.000Z'
    },
    {
      id: 'prod-showcase-01',
      slug: 'heritage-illuminated-glass-showcase',
      category_slug: 'showcase',
      name_bn: 'হেরিটেজ লাইটিং গ্লাস শোকেস ক্যাবিনেট',
      name_en: 'Heritage Illuminated Glass Showcase Cabinet',
      price: 58000,
      discount_price: 54000,
      short_desc_bn: 'ড্রয়িংরুমের তৈজসপত্র সাজিয়ে রাখার জন্য আধুনিক হিডেন এলইডি লাইটিং শোকেস।',
      full_desc_bn: 'ক্রিস্টাল শোপিস ও নান্দনিক সিরামিক তৈজসপত্র প্রদর্শনের জন্য আদর্শ শোকেস। ৪টি পুরু গ্লাস শেলফ, দুটি ব্যাক-হিডেন সফট ওয়ার্ম এলইডি স্পটলাইট এবং নিচের অংশে দুটি কাঠামোগত স্টোরেজ ক্যাবিনেট। মেহগনি ও সেগুন কাঠের দৃঢ় সুরক্ষায় আজীবন ব্যবহারের উপযোগী।',
      main_image: '/images/category_showcase_cabinet_1793103050887.jpg',
      additional_images: ['/images/category_showcase_cabinet_1793103050887.jpg'],
      dimensions: 'উচ্চতা ৬.৫ ফুট × প্রস্থ ৪.৫ ফুট × গভীরতা ১৬ ইঞ্চি',
      materials: 'মেহগনি ফ্রেম, ৮ মিমি গ্লাস শেলফ ও অ্যালুমিনিয়াম হিঞ্জ',
      colors: ['ডার্ক মেহগনি', 'অ্যান্টিক পলিশ'],
      in_stock: true,
      is_popular: false,
      is_featured: true,
      created_at: '2026-02-28T16:00:00.000Z'
    },
    {
      id: 'prod-other-01',
      slug: 'artisan-carved-coffee-tea-table',
      category_slug: 'other',
      name_bn: 'আর্টিসান কার্ভড সেন্টার টি-টেবিল',
      name_en: 'Artisan Carved Center Tea Table',
      price: 18500,
      discount_price: 16500,
      short_desc_bn: '৮ মিমি গ্লাস টপ ও ঐতিহ্যবাহী কারুকাজযুক্ত সেগুন কাঠের কফি টেবিল।',
      full_desc_bn: 'বসার ঘরের কেন্দ্রবিন্দুতে রাখার জন্য দৃষ্টিনন্দন টি-টেবিল। চারপাশের পায়াগুলোতে নিখুঁত খাঁজকাটা কারুকাজ রয়েছে। এর ওপর স্বচ্ছ শক্ত কাঁচ থাকায় ধুলোবালি সহজেই পরিষ্কার করা যায়।',
      main_image: '/images/hero_furniture_cover_1793102992976.jpg',
      additional_images: ['/images/hero_furniture_cover_1793102992976.jpg'],
      dimensions: 'দৈর্ঘ্য ৪ ফুট × প্রস্থ ২.৫ ফুট × উচ্চতা ১৮ ইঞ্চি',
      materials: '১০০% অরিজিনাল সেগুন কাঠ ও ৮ মিমি ফ্ল্যাট গ্লাস',
      colors: ['ন্যাচারাল সেগুন', 'ওয়ালনাট ফিনিশ'],
      in_stock: true,
      is_popular: true,
      is_featured: false,
      created_at: '2026-03-25T13:00:00.000Z'
    }
  ],
  advertisements: [
    {
      id: 'ad-01',
      title: 'অভিজাত আসবাবপত্র মেলা ও বিশেষ ছাড়',
      placement: 'homepage_top',
      image_url: '/images/ad_banner_discount_1793103050698.jpg',
      destination_url: '/category/bed',
      start_date: '2026-01-01',
      end_date: '2027-12-31',
      is_enabled: true,
      row_interval: 3
    },
    {
      id: 'ad-02',
      title: 'নতুন কালেকশন প্রদর্শনী - আকর্ষণীয় কিস্তি ও ক্যাশব্যাক',
      placement: 'homepage_between_sections',
      image_url: '/images/ad_banner_discount_1793103050698.jpg',
      destination_url: '/category/sofa',
      start_date: '2026-01-01',
      end_date: '2027-12-31',
      is_enabled: true,
      row_interval: 2
    },
    {
      id: 'ad-03',
      title: 'হোম ডেলিভারি অফার ও ১৫ বছরের ঘুণের গ্যারান্টি',
      placement: 'homepage_below_featured',
      image_url: '/images/ad_banner_discount_1793103050698.jpg',
      destination_url: '/contact',
      start_date: '2026-01-01',
      end_date: '2027-12-31',
      is_enabled: true,
      row_interval: 2
    },
    {
      id: 'ad-04',
      title: 'ক্যাটাগরি ব্যানার স্পেশাল ডিসকাউন্ট',
      placement: 'category_top',
      image_url: '/images/ad_banner_discount_1793103050698.jpg',
      destination_url: '#contact',
      start_date: '2026-01-01',
      end_date: '2027-12-31',
      is_enabled: true,
      row_interval: 2
    },
    {
      id: 'ad-05',
      title: 'প্রোডাক্ট গ্রিড স্পনসরড ব্যানার',
      placement: 'category_grid',
      image_url: '/images/ad_banner_discount_1793103050698.jpg',
      destination_url: '#contact',
      start_date: '2026-01-01',
      end_date: '2027-12-31',
      is_enabled: true,
      row_interval: 2
    },
    {
      id: 'ad-06',
      title: 'পণ্য সম্পর্কিত বিশেষ অফার ও কিস্তি সুবিধা',
      placement: 'product_below_info',
      image_url: '/images/ad_banner_discount_1793103050698.jpg',
      destination_url: '#contact',
      start_date: '2026-01-01',
      end_date: '2027-12-31',
      is_enabled: true,
      row_interval: 2
    }
  ],
  inquiries: [],
  admin_users: [],
  admin_sessions: [],
  media_files: [],
  homepage_config: {
    hero_badge_bn: '১০০% অকৃত্রিম চিটাগাং সেগুন ও সিজনড মেহগনি কাঠ',
    hero_heading_bn: 'আপনার স্বপ্নের গৃহসজ্জায় ঐতিহ্যের সেরা কাঠের ফার্নিচার',
    hero_subheading_bn: 'চিটাগাং সেগুন ও সিজনড মেহগনি কাঠে তৈরি শৈল্পিক কারুকার্যখচিত খাট, সোফা, ডাইনিং ও গৃহসজ্জা সামগ্রী। তিন দশকের আস্থার নাম।',
    hero_image_url: '/images/hero_furniture_cover_1793102992976.jpg',
    hero_cta_text_bn: 'পণ্য ক্যাটালগ দেখুন',
    hero_cta_link: '#categories',
    announcement_bar_enabled: true,
    announcement_bar_text_bn: '✨ জয়নাল ফার্নিচার মার্ট — সারা বাংলাদেশে নিরাপদ হোম ডেলিভারি ও আধুনিক কাঠে তৈরি আসবাবপত্র | ১০০% অকৃত্রিম সেগুন ও মেহগনি কাঠ!',
    featured_category_slugs: ['bed', 'sofa', 'dining', 'almirah', 'dressing', 'showcase'],
    popular_product_ids: ['prod-01', 'prod-03', 'prod-05', 'prod-07'],
    featured_product_ids: ['prod-02', 'prod-04', 'prod-06', 'prod-08'],
    sections_order: [
      { id: 'announcement', title_bn: 'ঘোষণা বার্তা', is_visible: true, order: 1 },
      { id: 'hero', title_bn: 'হিরো ব্যানার', is_visible: true, order: 2 },
      { id: 'ad_top', title_bn: 'টপ বিজ্ঞাপন ব্যানার', is_visible: true, order: 3 },
      { id: 'categories', title_bn: 'ফার্নিচার ক্যাটাগরি', is_visible: true, order: 4 },
      { id: 'ad_between', title_bn: 'মিডল বিজ্ঞাপন ব্যানার', is_visible: true, order: 5 },
      { id: 'popular', title_bn: 'জনপ্রিয় পণ্যসমূহ', is_visible: true, order: 6 },
      { id: 'ad_below_featured', title_bn: 'ফিচার্ড পণ্যের নিচে বিজ্ঞাপন', is_visible: true, order: 7 },
      { id: 'featured', title_bn: 'বিশেষ আকর্ষণ / ফিচার্ড পণ্য', is_visible: true, order: 8 },
      { id: 'about', title_bn: 'আমাদের সম্পর্কে ও কারিগরি মান', is_visible: true, order: 9 },
      { id: 'ad_footer', title_bn: 'ফুটারের ওপর বিজ্ঞাপন', is_visible: true, order: 10 },
      { id: 'contact', title_bn: 'যোগাযোগ ও শোরুম লোকেশন', is_visible: true, order: 11 }
    ]
  }
};

// Ensure data folder and file exist
export function initDB(): DatabaseSchema {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
  if (!fs.existsSync(UPLOADS_DIR)) {
    fs.mkdirSync(UPLOADS_DIR, { recursive: true });
  }

  let data: DatabaseSchema;
  if (!fs.existsSync(DB_FILE)) {
    data = JSON.parse(JSON.stringify(INITIAL_DATA));
  } else {
    try {
      const raw = fs.readFileSync(DB_FILE, 'utf8');
      data = JSON.parse(raw);
    } catch (err) {
      console.error('Error reading DB, re-initializing:', err);
      data = JSON.parse(JSON.stringify(INITIAL_DATA));
    }
  }

  // Never ship a known/default admin password. Provision credentials through deployment secrets.
  if (!Array.isArray(data.admin_users)) data.admin_users = [];
  if (data.admin_users.length === 0 && process.env.ADMIN_PASSWORD) {
    const username = (process.env.ADMIN_USERNAME || 'admin').trim();
    const email = (process.env.ADMIN_EMAIL || '').trim().toLowerCase();
    if (process.env.NODE_ENV === 'production' && !email) {
      throw new Error('Set ADMIN_EMAIL before starting in production.');
    }
    const { hash, salt } = hashPassword(process.env.ADMIN_PASSWORD);
    data.admin_users = [{
      id: 'admin-1', username, email: email || `${username}@localhost`,
      password_hash: hash, password_salt: salt, salt, role: 'superadmin',
      created_at: new Date().toISOString()
    }];
  }
  if (process.env.NODE_ENV === 'production' && data.admin_users.length === 0) {
    throw new Error('No admin exists. Set ADMIN_USERNAME, ADMIN_EMAIL and ADMIN_PASSWORD, then restart.');
  }

  if (!data.settings) data.settings = INITIAL_DATA.settings;
  // Recovery is disabled unless a private deployment secret is explicitly configured.
  if (process.env.ADMIN_RECOVERY_CODE) {
    if (!data.settings.recovery_code_hash || process.env.ROTATE_ADMIN_RECOVERY_CODE === 'true') {
      const { hash, salt } = hashPassword(process.env.ADMIN_RECOVERY_CODE);
      data.settings.recovery_code_hash = hash;
      data.settings.recovery_code_salt = salt;
    }
  }
  if (process.env.NODE_ENV === 'production' && !data.settings.recovery_code_hash) {
    throw new Error('Set ADMIN_RECOVERY_CODE before starting in production.');
  }

  if (!Array.isArray(data.admin_sessions)) {
    data.admin_sessions = [];
  }

  if (!Array.isArray(data.media_files)) {
    data.media_files = [
      {
        id: 'media-01',
        filename: 'hero_furniture_cover_1793102992976.jpg',
        original_name: 'hero_furniture_cover.jpg',
        mime_type: 'image/jpeg',
        size: 245000,
        url: '/images/hero_furniture_cover_1793102992976.jpg',
        created_at: new Date().toISOString(),
        usage_count: 1
      },
      {
        id: 'media-02',
        filename: 'category_bed_teak_1793102993462.jpg',
        original_name: 'category_bed_teak.jpg',
        mime_type: 'image/jpeg',
        size: 198000,
        url: '/images/category_bed_teak_1793102993462.jpg',
        created_at: new Date().toISOString(),
        usage_count: 1
      },
      {
        id: 'media-03',
        filename: 'category_sofa_luxury_1793102994389.jpg',
        original_name: 'category_sofa_luxury.jpg',
        mime_type: 'image/jpeg',
        size: 210000,
        url: '/images/category_sofa_luxury_1793102994389.jpg',
        created_at: new Date().toISOString(),
        usage_count: 1
      },
      {
        id: 'media-04',
        filename: 'ad_banner_discount_1793103050698.jpg',
        original_name: 'ad_banner_discount.jpg',
        mime_type: 'image/jpeg',
        size: 154000,
        url: '/images/ad_banner_discount_1793103050698.jpg',
        created_at: new Date().toISOString(),
        usage_count: 3
      }
    ];
  }

  if (!data.homepage_config) {
    data.homepage_config = {
      hero_badge_bn: '১০০% অকৃত্রিম চিটাগাং সেগুন ও সিজনড মেহগনি কাঠ',
      hero_heading_bn: data.settings.hero_title || 'আপনার স্বপ্নের গৃহসজ্জায় ঐতিহ্যের সেরা কাঠের ফার্নিচার',
      hero_subheading_bn: data.settings.hero_subtitle || 'চিটাগাং সেগুন ও সিজনড মেহগনি কাঠে তৈরি শৈল্পিক কারুকার্যখচিত খাট, সোফা, ডাইনিং ও গৃহসজ্জা সামগ্রী। তিন দশকের আস্থার নাম।',
      hero_image_url: data.settings.hero_image,
      hero_cta_text_bn: 'পণ্য ক্যাটালগ দেখুন',
      hero_cta_link: '#categories',
      announcement_bar_enabled: true,
      announcement_bar_text_bn: data.settings.announcement_text,
      featured_category_slugs: ['bed', 'sofa', 'dining', 'almirah', 'dressing', 'showcase'],
      popular_product_ids: ['prod-01', 'prod-03', 'prod-05', 'prod-07'],
      featured_product_ids: ['prod-02', 'prod-04', 'prod-06', 'prod-08'],
      sections_order: [
        { id: 'announcement', title_bn: 'ঘোষণা বার্তা', is_visible: true, order: 1 },
        { id: 'hero', title_bn: 'হিরো ব্যানার', is_visible: true, order: 2 },
        { id: 'ad_top', title_bn: 'টপ বিজ্ঞাপন ব্যানার', is_visible: true, order: 3 },
        { id: 'categories', title_bn: 'ফার্নিচার ক্যাটাগরি', is_visible: true, order: 4 },
        { id: 'ad_between', title_bn: 'মিডল বিজ্ঞাপন ব্যানার', is_visible: true, order: 5 },
        { id: 'popular', title_bn: 'জনপ্রিয় পণ্যসমূহ', is_visible: true, order: 6 },
        { id: 'ad_below_featured', title_bn: 'ফিচার্ড পণ্যের নিচে বিজ্ঞাপন', is_visible: true, order: 7 },
        { id: 'featured', title_bn: 'বিশেষ আকর্ষণ / ফিচার্ড পণ্য', is_visible: true, order: 8 },
        { id: 'about', title_bn: 'আমাদের সম্পর্কে ও কারিগরি মান', is_visible: true, order: 9 },
        { id: 'ad_footer', title_bn: 'ফুটারের ওপর বিজ্ঞাপন', is_visible: true, order: 10 },
        { id: 'contact', title_bn: 'যোগাযোগ ও শোরুম লোকেশন', is_visible: true, order: 11 }
      ]
    };
  }

  if (!data.settings.currency_symbol) data.settings.currency_symbol = '৳';
  if (!data.settings.seo_title) data.settings.seo_title = 'জয়নাল ফার্নিচার মার্ট | Joynal Furniture Mart';
  if (!data.settings.seo_description) data.settings.seo_description = 'অভিজাত ও আধুনিক কাঠের খাট, সোফা, ডাইনিং টেবিল, আলমারি, শোকেস ও ঘরের সব ধরনের আসবাবপত্র প্রস্তুতকারক।';
  if (!data.settings.footer_text_bn) data.settings.footer_text_bn = '© ২০২৬ জয়নাল ফার্নিচার মার্ট। সর্বস্বত্ব সংরক্ষিত। সেরা মানের কাঠের ফার্নিচার আপনার সেবায়।';

  fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf8');
  return data;
}

export function readDB(): DatabaseSchema {
  return initDB();
}

export function writeDB(data: DatabaseSchema): void {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
  const tempPath = `${DB_FILE}.tmp`;
  fs.writeFileSync(tempPath, JSON.stringify(data, null, 2), 'utf8');
  fs.renameSync(tempPath, DB_FILE);
}
