import 'dotenv/config';
import express, { Request, Response, NextFunction } from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import {
  readDB,
  writeDB,
  Category,
  Product,
  Advertisement,
  CustomerInquiry,
  MediaItem,
  hashPassword,
  verifyPassword,
  generateSessionToken,
  UPLOADS_DIR
} from './server/db.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Rate limiter state for login: key = ip/identifier -> { count, lockedUntil }
const loginAttempts = new Map<string, { count: number; lockedUntil: number }>();

function checkRateLimit(ip: string): { isLocked: boolean; waitMinutes: number } {
  const record = loginAttempts.get(ip);
  if (!record) return { isLocked: false, waitMinutes: 0 };
  const now = Date.now();
  if (record.lockedUntil > now) {
    const waitMinutes = Math.ceil((record.lockedUntil - now) / 60000);
    return { isLocked: true, waitMinutes };
  }
  if (now > record.lockedUntil && record.lockedUntil > 0) {
    loginAttempts.delete(ip);
  }
  return { isLocked: false, waitMinutes: 0 };
}

function recordLoginAttempt(ip: string, success: boolean) {
  if (success) {
    loginAttempts.delete(ip);
    return;
  }
  const now = Date.now();
  const record = loginAttempts.get(ip) || { count: 0, lockedUntil: 0 };
  record.count += 1;
  if (record.count >= 5) {
    record.lockedUntil = now + 15 * 60 * 1000; // 15 mins lockout
  }
  loginAttempts.set(ip, record);
}

// Admin Auth Middleware
interface AuthRequest extends Request {
  adminUser?: any;
}

function requireAdminAuth(req: AuthRequest, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'লগইন অনুমোদিত নয়। দয়া করে পুনরায় লগইন করুন।' });
  }

  const token = authHeader.replace('Bearer ', '').trim();
  const db = readDB();
  const session = db.admin_sessions.find(s => s.token === token);

  if (!session || session.expires_at < Date.now()) {
    return res.status(401).json({ error: 'সেশনটির মেয়াদ শেষ হয়েছে। দয়া করে পুনরায় লগইন করুন।' });
  }

  const user = db.admin_users.find(u => u.id === session.user_id);
  if (!user) {
    return res.status(401).json({ error: 'ব্যবহারকারী পাওয়া যায়নি।' });
  }

  req.adminUser = user;
  next();
}

async function startServer() {
  const app = express();

  // Baseline browser security headers. HTTPS should be enforced by the production host.
  app.disable('x-powered-by');
  app.use((_req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'DENY');
    res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
    res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
    next();
  });

  // Increase payload limit for Base64 image uploads
  app.use(express.json({ limit: '25mb' }));
  app.use(express.urlencoded({ extended: true, limit: '25mb' }));

  // Ensure uploads directory exists and is statically served
  if (!fs.existsSync(UPLOADS_DIR)) {
    fs.mkdirSync(UPLOADS_DIR, { recursive: true });
  }
  app.use('/uploads', express.static(UPLOADS_DIR));

  // Initialize DB
  readDB();

  const apiRouter = express.Router();

  // ==========================================
  // PUBLIC ENDPOINTS
  // ==========================================

  // Public Settings
  apiRouter.get('/settings', (req, res) => {
    try {
      const db = readDB();
      // Omit private security fields in public response
      const { recovery_code_hash, recovery_code_salt, ...publicSettings } = db.settings as any;
      res.json(publicSettings);
    } catch (err) {
      res.status(500).json({ error: 'Failed to read settings' });
    }
  });

  // Public Homepage Config
  apiRouter.get('/homepage', (req, res) => {
    try {
      const db = readDB();
      res.json(db.homepage_config || {});
    } catch (err) {
      res.status(500).json({ error: 'Failed to read homepage config' });
    }
  });

  // Public Categories
  apiRouter.get('/categories', (req, res) => {
    try {
      const db = readDB();
      const categories = db.categories
        .filter(c => c.is_active)
        .sort((a, b) => a.display_order - b.display_order)
        .map(cat => {
          const productCount = db.products.filter(p => p.category_slug === cat.slug).length;
          return { ...cat, product_count: productCount };
        });
      res.json(categories);
    } catch (err) {
      res.status(500).json({ error: 'Failed to read categories' });
    }
  });

  apiRouter.get('/categories/:slug', (req, res) => {
    try {
      const db = readDB();
      const cat = db.categories.find(c => c.slug === req.params.slug);
      if (!cat) return res.status(404).json({ error: 'Category not found' });
      const productCount = db.products.filter(p => p.category_slug === cat.slug).length;
      res.json({ ...cat, product_count: productCount });
    } catch (err) {
      res.status(500).json({ error: 'Failed to read category' });
    }
  });

  // Public Products
  apiRouter.get('/products', (req, res) => {
    try {
      const db = readDB();
      let list = [...db.products];
      const { category, search, sort, featured, popular, limit } = req.query;

      if (category && typeof category === 'string' && category !== 'all') {
        list = list.filter(p => p.category_slug === category);
      }

      if (search && typeof search === 'string') {
        const q = search.toLowerCase().trim();
        list = list.filter(
          p =>
            p.name_bn.toLowerCase().includes(q) ||
            p.name_en.toLowerCase().includes(q) ||
            p.short_desc_bn.toLowerCase().includes(q) ||
            p.materials.toLowerCase().includes(q)
        );
      }

      if (featured === 'true') {
        list = list.filter(p => p.is_featured);
      }

      if (popular === 'true') {
        list = list.filter(p => p.is_popular);
      }

      if (sort === 'price_asc') {
        list.sort((a, b) => (a.discount_price || a.price) - (b.discount_price || b.price));
      } else if (sort === 'price_desc') {
        list.sort((a, b) => (b.discount_price || b.price) - (a.discount_price || a.price));
      } else if (sort === 'newest') {
        list.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
      } else if (sort === 'popular') {
        list.sort((a, b) => (b.is_popular ? 1 : 0) - (a.is_popular ? 1 : 0));
      }

      if (limit) {
        const num = parseInt(limit as string, 10);
        if (!isNaN(num)) list = list.slice(0, num);
      }

      res.json(list);
    } catch (err) {
      res.status(500).json({ error: 'Failed to fetch products' });
    }
  });

  apiRouter.get('/products/:idOrSlug', (req, res) => {
    try {
      const db = readDB();
      const param = req.params.idOrSlug;
      const product = db.products.find(p => p.id === param || p.slug === param);
      if (!product) return res.status(404).json({ error: 'Product not found' });

      const related = db.products
        .filter(p => p.category_slug === product.category_slug && p.id !== product.id)
        .slice(0, 4);

      res.json({ product, related });
    } catch (err) {
      res.status(500).json({ error: 'Failed to fetch product' });
    }
  });

  // Public Advertisements (increments impressions on read)
  apiRouter.get('/advertisements', (req, res) => {
    try {
      const db = readDB();
      const now = new Date().toISOString().split('T')[0];
      const { placement } = req.query;

      let ads = db.advertisements.filter(ad => {
        if (!ad.is_enabled) return false;
        if (ad.start_date && ad.start_date > now) return false;
        if (ad.end_date && ad.end_date < now) return false;
        return true;
      });

      if (placement && typeof placement === 'string') {
        ads = ads.filter(ad => ad.placement === placement);
      }

      // Track impressions
      let changed = false;
      for (const ad of ads) {
        const idx = db.advertisements.findIndex(a => a.id === ad.id);
        if (idx !== -1) {
          db.advertisements[idx].impressions = (db.advertisements[idx].impressions || 0) + 1;
          changed = true;
        }
      }
      if (changed) writeDB(db);

      res.json(ads);
    } catch (err) {
      res.status(500).json({ error: 'Failed to fetch advertisements' });
    }
  });

  // Track ad click
  apiRouter.post('/advertisements/:id/click', (req, res) => {
    try {
      const db = readDB();
      const ad = db.advertisements.find(a => a.id === req.params.id);
      if (ad) {
        ad.clicks = (ad.clicks || 0) + 1;
        writeDB(db);
      }
      res.json({ success: true });
    } catch (err) {
      res.status(500).json({ error: 'Failed to record click' });
    }
  });

  // Public Inquiries
  apiRouter.post('/inquiries', (req, res) => {
    try {
      const { customer_name, phone, message, product_id, product_name } = req.body;
      if (!customer_name || !phone) {
        return res.status(400).json({ error: 'নাম ও মোবাইল নম্বর আবশ্যক।' });
      }

      const db = readDB();
      const newInquiry: CustomerInquiry = {
        id: `inq-${Date.now()}`,
        customer_name: customer_name.trim(),
        phone: phone.trim(),
        message: message ? message.trim() : '',
        product_id: product_id || undefined,
        product_name: product_name || undefined,
        created_at: new Date().toISOString(),
        status: 'unread'
      };

      db.inquiries.unshift(newInquiry);
      writeDB(db);

      res.status(201).json({ success: true, inquiry: newInquiry });
    } catch (err) {
      res.status(500).json({ error: 'Failed to record inquiry' });
    }
  });

  // ==========================================
  // ADMIN AUTHENTICATION ENDPOINTS
  // ==========================================

  // Admin Login
  apiRouter.post('/admin/auth/login', (req, res) => {
    const ip = req.ip || req.socket.remoteAddress || 'unknown';
    const rateCheck = checkRateLimit(ip);
    if (rateCheck.isLocked) {
      return res.status(429).json({
        error: `খুব বেশি ভুল চেষ্টার কারণে একাউন্ট সাময়িকভাবে লক হয়েছে। ${rateCheck.waitMinutes} মিনিট পর চেষ্টা করুন।`
      });
    }

    const { username_or_email, password } = req.body;
    if (!username_or_email || !password) {
      return res.status(400).json({ error: 'ইউজারনেম/ইমেইল এবং পাসওয়ার্ড আবশ্যক।' });
    }

    const db = readDB();
    const query = username_or_email.trim().toLowerCase();
    const user = db.admin_users.find(
      u => u.username.toLowerCase() === query || u.email.toLowerCase() === query
    );

    if (!user) {
      recordLoginAttempt(ip, false);
      return res.status(401).json({ error: 'ভুল ইউজারনেম অথবা পাসওয়ার্ড।' });
    }

    const isValid = verifyPassword(password, user.password_hash, user.salt);
    if (!isValid) {
      recordLoginAttempt(ip, false);
      return res.status(401).json({ error: 'ভুল ইউজারনেম অথবা পাসওয়ার্ড।' });
    }

    // Success
    recordLoginAttempt(ip, true);
    const token = generateSessionToken();
    const expiresAt = Date.now() + 7 * 24 * 60 * 60 * 1000; // 7 days

    // Store session
    db.admin_sessions.push({
      token,
      user_id: user.id,
      expires_at: expiresAt,
      created_at: new Date().toISOString()
    });
    user.last_login = new Date().toISOString();
    writeDB(db);

    res.json({
      success: true,
      token,
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        role: user.role
      }
    });
  });

  // Admin Logout
  apiRouter.post('/admin/auth/logout', (req, res) => {
    const authHeader = req.headers.authorization;
    if (authHeader && authHeader.startsWith('Bearer ')) {
      const token = authHeader.replace('Bearer ', '').trim();
      const db = readDB();
      db.admin_sessions = db.admin_sessions.filter(s => s.token !== token);
      writeDB(db);
    }
    res.json({ success: true });
  });

  // Verify Admin Session
  apiRouter.get('/admin/auth/me', requireAdminAuth, (req: AuthRequest, res) => {
    const user = req.adminUser;
    res.json({
      id: user.id,
      username: user.username,
      email: user.email,
      role: user.role,
      last_login: user.last_login
    });
  });

  // Admin Change Password
  apiRouter.post('/admin/auth/change-password', requireAdminAuth, (req: AuthRequest, res) => {
    const { current_password, new_password } = req.body;
    if (!current_password || !new_password || new_password.length < 12) {
      return res.status(400).json({ error: 'নতুন পাসওয়ার্ড কমপক্ষে ১২ অক্ষরের হতে হবে।' });
    }

    const db = readDB();
    const user = db.admin_users.find(u => u.id === req.adminUser.id);
    if (!user) return res.status(404).json({ error: 'ব্যবহারকারী পাওয়া যায়নি।' });

    if (!verifyPassword(current_password, user.password_hash, user.salt)) {
      return res.status(400).json({ error: 'বর্তমান পাসওয়ার্ডটি সঠিক নয়।' });
    }

    const newCred = hashPassword(new_password);
    user.password_hash = newCred.hash;
    user.salt = newCred.salt;
    // Revoke every existing session after a credential change.
    db.admin_sessions = [];
    writeDB(db);

    res.json({ success: true, message: 'পাসওয়ার্ড সফলভাবে পরিবর্তিত হয়েছে।' });
  });

  // Admin Password Recovery via Recovery Code
  apiRouter.post('/admin/auth/recover', (req, res) => {
    const ip = req.ip || req.socket.remoteAddress || 'unknown';
    const rateCheck = checkRateLimit(`recovery:${ip}`);
    if (rateCheck.isLocked) return res.status(429).json({ error: `অনেকবার চেষ্টা করা হয়েছে। ${rateCheck.waitMinutes} মিনিট পর চেষ্টা করুন।` });
    const { recovery_code, new_password } = req.body;
    if (typeof recovery_code !== 'string' || typeof new_password !== 'string' || new_password.length < 12) {
      return res.status(400).json({ error: 'রিকভারি কোড ও কমপক্ষে ১২ অক্ষরের নতুন পাসওয়ার্ড প্রদান করুন।' });
    }

    const db = readDB();
    const settings = db.settings;
    if (!settings.recovery_code_hash || !settings.recovery_code_salt) {
      return res.status(400).json({ error: 'রিকভারি সিস্টেম কনফিগার করা নেই।' });
    }

    const isValid = verifyPassword(recovery_code.trim(), settings.recovery_code_hash, settings.recovery_code_salt);
    if (!isValid) {
      recordLoginAttempt(`recovery:${ip}`, false);
      return res.status(401).json({ error: 'প্রদত্ত রিকভারি কোডটি সঠিক নয়।' });
    }
    recordLoginAttempt(`recovery:${ip}`, true);

    // Reset superadmin password
    const superadmin = db.admin_users.find(u => u.role === 'superadmin') || db.admin_users[0];
    if (!superadmin) return res.status(500).json({ error: 'অ্যাডমিন অ্যাকাউন্ট পাওয়া যায়নি।' });

    const newCred = hashPassword(new_password);
    superadmin.password_hash = newCred.hash;
    superadmin.salt = newCred.salt;
    db.admin_sessions = [];
    writeDB(db);

    res.json({ success: true, message: 'অ্যাডমিন পাসওয়ার্ড সফলভাবে রিসেট হয়েছে। এখন নতুন পাসওয়ার্ড দিয়ে লগইন করুন।' });
  });

  // ==========================================
  // ADMIN DASHBOARD STATS
  // ==========================================
  apiRouter.get('/admin/dashboard/stats', requireAdminAuth, (req, res) => {
    try {
      const db = readDB();
      const totalProducts = db.products.length;
      const totalCategories = db.categories.length;
      const activeAds = db.advertisements.filter(a => a.is_enabled).length;
      const inactiveAds = db.advertisements.filter(a => !a.is_enabled).length;
      const totalMedia = db.media_files.length;
      const unreadInquiries = db.inquiries.filter(i => i.status === 'unread').length;
      const totalInquiries = db.inquiries.length;

      const recentProducts = [...db.products]
        .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
        .slice(0, 5);

      const recentInquiries = [...db.inquiries].slice(0, 5);

      res.json({
        totalProducts,
        totalCategories,
        activeAds,
        inactiveAds,
        totalMedia,
        unreadInquiries,
        totalInquiries,
        recentProducts,
        recentInquiries
      });
    } catch (err) {
      res.status(500).json({ error: 'Failed to fetch dashboard stats' });
    }
  });

  // ==========================================
  // ADMIN CATEGORY CRUD
  // ==========================================
  apiRouter.get('/admin/categories', requireAdminAuth, (req, res) => {
    try {
      const db = readDB();
      const categories = db.categories
        .sort((a, b) => a.display_order - b.display_order)
        .map(cat => ({
          ...cat,
          product_count: db.products.filter(p => p.category_slug === cat.slug).length
        }));
      res.json(categories);
    } catch (err) {
      res.status(500).json({ error: 'Failed to fetch categories' });
    }
  });

  apiRouter.post('/admin/categories', requireAdminAuth, (req, res) => {
    try {
      const { name_bn, name_en, slug, description_bn, cover_image, is_active } = req.body;
      if (!name_bn || !slug) {
        return res.status(400).json({ error: 'ক্যাটাগরির বাংলা নাম এবং স্লাগ আবশ্যক।' });
      }

      const db = readDB();
      const cleanSlug = slug.toLowerCase().trim().replace(/[^a-z0-9_-]/g, '-');
      if (db.categories.some(c => c.slug === cleanSlug)) {
        return res.status(400).json({ error: 'এই স্লাগ দিয়ে ইতিমধ্যে একটি ক্যাটাগরি রয়েছে।' });
      }

      const newCategory: Category = {
        id: `cat-${Date.now()}`,
        slug: cleanSlug,
        name_bn: name_bn.trim(),
        name_en: name_en ? name_en.trim() : '',
        description_bn: description_bn ? description_bn.trim() : '',
        cover_image: cover_image || '/src/assets/images/hero_furniture_cover_1793102992976.jpg',
        display_order: db.categories.length + 1,
        is_active: is_active !== undefined ? Boolean(is_active) : true
      };

      db.categories.push(newCategory);
      writeDB(db);

      res.status(201).json(newCategory);
    } catch (err) {
      res.status(500).json({ error: 'Failed to create category' });
    }
  });

  apiRouter.put('/admin/categories/:id', requireAdminAuth, (req, res) => {
    try {
      const db = readDB();
      const idx = db.categories.findIndex(c => c.id === req.params.id);
      if (idx === -1) return res.status(404).json({ error: 'ক্যাটাগরি পাওয়া যায়নি।' });

      const oldSlug = db.categories[idx].slug;
      const updated = { ...db.categories[idx], ...req.body };

      // If slug changed, update associated products
      if (req.body.slug && req.body.slug !== oldSlug) {
        const cleanSlug = req.body.slug.toLowerCase().trim().replace(/[^a-z0-9_-]/g, '-');
        updated.slug = cleanSlug;
        db.products.forEach(p => {
          if (p.category_slug === oldSlug) p.category_slug = cleanSlug;
        });
      }

      db.categories[idx] = updated;
      writeDB(db);

      res.json(updated);
    } catch (err) {
      res.status(500).json({ error: 'Failed to update category' });
    }
  });

  apiRouter.delete('/admin/categories/:id', requireAdminAuth, (req, res) => {
    try {
      const db = readDB();
      const cat = db.categories.find(c => c.id === req.params.id);
      if (!cat) return res.status(404).json({ error: 'ক্যাটাগরি পাওয়া যায়নি।' });

      // Safeguard: Check if products exist in category
      const associatedProducts = db.products.filter(p => p.category_slug === cat.slug);
      const force = req.query.force === 'true';

      if (associatedProducts.length > 0 && !force) {
        return res.status(400).json({
          error: `এই ক্যাটাগরিতে ${associatedProducts.length}টি পণ্য রয়েছে। ডিলিট করার পূর্বে পণ্যগুলো অন্য ক্যাটাগরিতে স্থানান্তর করুন অথবা ফোর্স ডিলিট নির্বাচন করুন।`,
          hasProducts: true,
          productCount: associatedProducts.length
        });
      }

      // If force delete, remove products or move to 'other'
      if (force && associatedProducts.length > 0) {
        db.products = db.products.filter(p => p.category_slug !== cat.slug);
      }

      db.categories = db.categories.filter(c => c.id !== req.params.id);
      writeDB(db);

      res.json({ success: true, message: 'ক্যাটাগরি সফলভাবে মুছে ফেলা হয়েছে।' });
    } catch (err) {
      res.status(500).json({ error: 'Failed to delete category' });
    }
  });

  // Reorder categories
  apiRouter.put('/admin/categories/reorder/batch', requireAdminAuth, (req, res) => {
    try {
      const { orderedIds } = req.body;
      if (!Array.isArray(orderedIds)) return res.status(400).json({ error: 'orderedIds array required' });

      const db = readDB();
      orderedIds.forEach((id: string, index: number) => {
        const cat = db.categories.find(c => c.id === id);
        if (cat) cat.display_order = index + 1;
      });
      writeDB(db);

      res.json({ success: true });
    } catch (err) {
      res.status(500).json({ error: 'Failed to reorder categories' });
    }
  });

  // ==========================================
  // ADMIN PRODUCT CRUD
  // ==========================================
  apiRouter.get('/admin/products', requireAdminAuth, (req, res) => {
    try {
      const db = readDB();
      let list = [...db.products];
      const { category, search, stock } = req.query;

      if (category && typeof category === 'string' && category !== 'all') {
        list = list.filter(p => p.category_slug === category);
      }
      if (stock === 'in_stock') {
        list = list.filter(p => p.in_stock);
      } else if (stock === 'out_of_stock') {
        list = list.filter(p => !p.in_stock);
      }
      if (search && typeof search === 'string') {
        const q = search.toLowerCase().trim();
        list = list.filter(
          p =>
            p.name_bn.toLowerCase().includes(q) ||
            p.name_en.toLowerCase().includes(q) ||
            p.materials.toLowerCase().includes(q)
        );
      }

      list.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
      res.json(list);
    } catch (err) {
      res.status(500).json({ error: 'Failed to fetch products' });
    }
  });

  apiRouter.post('/admin/products', requireAdminAuth, (req, res) => {
    try {
      const {
        name_bn,
        name_en,
        category_slug,
        price,
        discount_price,
        short_desc_bn,
        full_desc_bn,
        main_image,
        additional_images,
        dimensions,
        materials,
        colors,
        in_stock,
        is_popular,
        is_featured
      } = req.body;

      if (!name_bn || !category_slug || !price) {
        return res.status(400).json({ error: 'পণ্যের নাম, ক্যাটাগরি এবং মূল্য আবশ্যক।' });
      }

      const db = readDB();
      const slug = (name_en || name_bn)
        .toLowerCase()
        .replace(/[^a-z0-9]/g, '-')
        .replace(/-+/g, '-') + `-${Date.now().toString().slice(-4)}`;

      const newProduct: Product = {
        id: `prod-${Date.now()}`,
        slug,
        category_slug,
        name_bn: name_bn.trim(),
        name_en: name_en ? name_en.trim() : '',
        price: Number(price),
        discount_price: discount_price ? Number(discount_price) : undefined,
        short_desc_bn: short_desc_bn ? short_desc_bn.trim() : '',
        full_desc_bn: full_desc_bn ? full_desc_bn.trim() : '',
        main_image: main_image || '/src/assets/images/hero_furniture_cover_1793102992976.jpg',
        additional_images: Array.isArray(additional_images) ? additional_images : [],
        dimensions: dimensions || '',
        materials: materials || '',
        colors: Array.isArray(colors) ? colors : (typeof colors === 'string' ? colors.split(',').map(c => c.trim()) : []),
        in_stock: in_stock !== undefined ? Boolean(in_stock) : true,
        is_popular: Boolean(is_popular),
        is_featured: Boolean(is_featured),
        created_at: new Date().toISOString()
      };

      db.products.push(newProduct);
      writeDB(db);

      res.status(201).json(newProduct);
    } catch (err) {
      res.status(500).json({ error: 'Failed to create product' });
    }
  });

  apiRouter.put('/admin/products/:id', requireAdminAuth, (req, res) => {
    try {
      const db = readDB();
      const idx = db.products.findIndex(p => p.id === req.params.id);
      if (idx === -1) return res.status(404).json({ error: 'পণ্য পাওয়া যায়নি।' });

      const updated: Product = {
        ...db.products[idx],
        ...req.body,
        price: Number(req.body.price ?? db.products[idx].price),
        discount_price: req.body.discount_price ? Number(req.body.discount_price) : undefined
      };

      db.products[idx] = updated;
      writeDB(db);

      res.json(updated);
    } catch (err) {
      res.status(500).json({ error: 'Failed to update product' });
    }
  });

  apiRouter.delete('/admin/products/:id', requireAdminAuth, (req, res) => {
    try {
      const db = readDB();
      const exists = db.products.some(p => p.id === req.params.id);
      if (!exists) return res.status(404).json({ error: 'পণ্য পাওয়া যায়নি।' });

      db.products = db.products.filter(p => p.id !== req.params.id);
      writeDB(db);

      res.json({ success: true, message: 'পণ্যটি সফলভাবে মুছে ফেলা হয়েছে।' });
    } catch (err) {
      res.status(500).json({ error: 'Failed to delete product' });
    }
  });

  // ==========================================
  // ADMIN ADVERTISEMENT CRUD
  // ==========================================
  apiRouter.get('/admin/advertisements', requireAdminAuth, (req, res) => {
    try {
      const db = readDB();
      const ads = [...db.advertisements].sort((a, b) => (a.display_order || 0) - (b.display_order || 0));
      res.json(ads);
    } catch (err) {
      res.status(500).json({ error: 'Failed to fetch advertisements' });
    }
  });

  apiRouter.post('/admin/advertisements', requireAdminAuth, (req, res) => {
    try {
      const { title, placement, image_url, destination_url, start_date, end_date, is_enabled, row_interval, third_party_code } = req.body;
      if (!title || !placement) {
        return res.status(400).json({ error: 'বিজ্ঞাপনের শিরোনাম এবং প্লেসমেন্ট আবশ্যক।' });
      }

      const db = readDB();
      const newAd: Advertisement = {
        id: `ad-${Date.now()}`,
        title: title.trim(),
        placement,
        image_url: image_url || '',
        destination_url: destination_url || '',
        start_date: start_date || new Date().toISOString().split('T')[0],
        end_date: end_date || '2027-12-31',
        is_enabled: is_enabled !== undefined ? Boolean(is_enabled) : true,
        row_interval: row_interval ? Number(row_interval) : 2,
        display_order: db.advertisements.length + 1,
        impressions: 0,
        clicks: 0,
        third_party_code: third_party_code || undefined
      };

      db.advertisements.push(newAd);
      writeDB(db);

      res.status(201).json(newAd);
    } catch (err) {
      res.status(500).json({ error: 'Failed to create advertisement' });
    }
  });

  apiRouter.put('/admin/advertisements/:id', requireAdminAuth, (req, res) => {
    try {
      const db = readDB();
      const idx = db.advertisements.findIndex(a => a.id === req.params.id);
      if (idx === -1) return res.status(404).json({ error: 'বিজ্ঞাপন পাওয়া যায়নি।' });

      const updated = {
        ...db.advertisements[idx],
        ...req.body,
        row_interval: req.body.row_interval ? Number(req.body.row_interval) : db.advertisements[idx].row_interval
      };

      db.advertisements[idx] = updated;
      writeDB(db);

      res.json(updated);
    } catch (err) {
      res.status(500).json({ error: 'Failed to update advertisement' });
    }
  });

  apiRouter.delete('/admin/advertisements/:id', requireAdminAuth, (req, res) => {
    try {
      const db = readDB();
      db.advertisements = db.advertisements.filter(a => a.id !== req.params.id);
      writeDB(db);
      res.json({ success: true, message: 'বিজ্ঞাপন সফলভাবে মুছে ফেলা হয়েছে।' });
    } catch (err) {
      res.status(500).json({ error: 'Failed to delete advertisement' });
    }
  });

  // ==========================================
  // ADMIN HOMEPAGE MANAGEMENT
  // ==========================================
  apiRouter.get('/admin/homepage', requireAdminAuth, (req, res) => {
    try {
      const db = readDB();
      res.json(db.homepage_config);
    } catch (err) {
      res.status(500).json({ error: 'Failed to fetch homepage config' });
    }
  });

  apiRouter.put('/admin/homepage', requireAdminAuth, (req, res) => {
    try {
      const db = readDB();
      db.homepage_config = {
        ...db.homepage_config,
        ...req.body
      };

      // Also sync top-level settings fields for backward compatibility
      if (req.body.hero_title) db.settings.hero_title = req.body.hero_title;
      if (req.body.hero_subtitle) db.settings.hero_subtitle = req.body.hero_subtitle;
      if (req.body.hero_image) db.settings.hero_image = req.body.hero_image;
      if (req.body.announcement_text) db.settings.announcement_text = req.body.announcement_text;

      writeDB(db);
      res.json(db.homepage_config);
    } catch (err) {
      res.status(500).json({ error: 'Failed to update homepage config' });
    }
  });

  // ==========================================
  // ADMIN MEDIA MANAGEMENT
  // ==========================================
  apiRouter.get('/admin/media', requireAdminAuth, (req, res) => {
    try {
      const db = readDB();
      res.json(db.media_files || []);
    } catch (err) {
      res.status(500).json({ error: 'Failed to fetch media files' });
    }
  });

  // Upload image via Base64 payload
  apiRouter.post('/admin/media/upload', requireAdminAuth, (req, res) => {
    try {
      const { filename, file_data, mime_type } = req.body;
      if (!filename || !file_data) {
        return res.status(400).json({ error: 'ফাইলের নাম এবং ডাটা প্রদান করুন।' });
      }

      // Validate allowed mime types
      const allowedMimes = ['image/jpeg', 'image/png', 'image/webp', 'image/jpg'];
      const mime = mime_type || 'image/jpeg';
      if (!allowedMimes.includes(mime.toLowerCase())) {
        return res.status(400).json({ error: 'শুধুমাত্র JPG, JPEG, PNG, এবং WebP ছবি আপলোড করা যাবে।' });
      }

      // Strip Base64 header if present
      const base64Data = file_data.replace(/^data:image\/\w+;base64,/, '');
      const buffer = Buffer.from(base64Data, 'base64');

      // Max size check: 5MB
      if (buffer.length > 5 * 1024 * 1024) {
        return res.status(400).json({ error: 'ছবির সাইজ সর্বোচ্চ ৫ মেগাবাইট (5MB) হতে হবে।' });
      }

      const expectedExt = mime.includes('png') ? '.png' : mime.includes('webp') ? '.webp' : '.jpg';
      const requestedExt = path.extname(String(filename)).toLowerCase();
      const allowedExts = ['.jpg', '.jpeg', '.png', '.webp'];
      if (requestedExt && !allowedExts.includes(requestedExt)) {
        return res.status(400).json({ error: 'ছবির ফাইল এক্সটেনশন সঠিক নয়।' });
      }
      const ext = requestedExt || expectedExt;
      const baseClean = path.basename(String(filename), path.extname(String(filename))).replace(/[^a-zA-Z0-9_-]/g, '_').slice(0, 80) || 'image';
      const uniqueFilename = `${baseClean}_${Date.now()}${ext}`;
      const filePath = path.resolve(UPLOADS_DIR, uniqueFilename);

      fs.writeFileSync(filePath, buffer);

      const url = `/uploads/${uniqueFilename}`;
      const db = readDB();

      const newMedia: MediaItem = {
        id: `media-${Date.now()}`,
        filename: uniqueFilename,
        original_name: filename,
        url,
        file_size: buffer.length,
        mime_type: mime,
        uploaded_at: new Date().toISOString()
      };

      if (!db.media_files) db.media_files = [];
      db.media_files.unshift(newMedia);
      writeDB(db);

      res.status(201).json(newMedia);
    } catch (err: any) {
      console.error('Media upload error:', err);
      res.status(500).json({ error: 'ছবি আপলোড করতে ব্যর্থ হয়েছে।' });
    }
  });

  // Delete media with safety check
  apiRouter.delete('/admin/media/:id', requireAdminAuth, (req, res) => {
    try {
      const db = readDB();
      const media = db.media_files.find(m => m.id === req.params.id);
      if (!media) return res.status(404).json({ error: 'ছবি পাওয়া যায়নি।' });

      // Check if image is currently in use
      const inCategories = db.categories.filter(c => c.cover_image === media.url).map(c => c.name_bn);
      const inProducts = db.products.filter(p => p.main_image === media.url || p.additional_images?.includes(media.url)).map(p => p.name_bn);
      const inAds = db.advertisements.filter(a => a.image_url === media.url).map(a => a.title);

      const usage: string[] = [];
      if (inCategories.length) usage.push(`ক্যাটাগরি: ${inCategories.join(', ')}`);
      if (inProducts.length) usage.push(`পণ্য: ${inProducts.join(', ')}`);
      if (inAds.length) usage.push(`বিজ্ঞাপন: ${inAds.join(', ')}`);

      if (usage.length > 0) {
        return res.status(400).json({
          error: `এই ছবিটি বর্তমানে ব্যবহৃত হচ্ছে (${usage.join('; ')}), তাই এটি মুছে ফেলা সম্ভব নয়।`,
          inUse: true
        });
      }

      // Safe to delete file from disk if it was saved in uploads
      const diskPath = path.resolve(UPLOADS_DIR, media.filename);
      if (fs.existsSync(diskPath)) {
        try {
          fs.unlinkSync(diskPath);
        } catch (e) {
          console.warn('Could not delete disk file:', e);
        }
      }

      db.media_files = db.media_files.filter(m => m.id !== req.params.id);
      writeDB(db);

      res.json({ success: true, message: 'ছবি সফলভাবে মুছে ফেলা হয়েছে।' });
    } catch (err) {
      res.status(500).json({ error: 'Failed to delete media' });
    }
  });

  // ==========================================
  // ADMIN WEBSITE SETTINGS
  // ==========================================
  apiRouter.get('/admin/settings', requireAdminAuth, (req, res) => {
    try {
      const db = readDB();
      // Omit private credentials
      const { recovery_code_hash, recovery_code_salt, ...safeSettings } = db.settings as any;
      res.json(safeSettings);
    } catch (err) {
      res.status(500).json({ error: 'Failed to fetch settings' });
    }
  });

  apiRouter.put('/admin/settings', requireAdminAuth, (req, res) => {
    try {
      const db = readDB();
      db.settings = {
        ...db.settings,
        ...req.body
      };
      writeDB(db);
      res.json({ success: true, settings: db.settings });
    } catch (err) {
      res.status(500).json({ error: 'Failed to update settings' });
    }
  });

  // Admin Inquiries List & Status Update
  apiRouter.get('/admin/inquiries', requireAdminAuth, (req, res) => {
    try {
      const db = readDB();
      res.json(db.inquiries || []);
    } catch (err) {
      res.status(500).json({ error: 'Failed to fetch inquiries' });
    }
  });

  apiRouter.patch('/admin/inquiries/:id/status', requireAdminAuth, (req, res) => {
    try {
      const db = readDB();
      const inq = db.inquiries.find(i => i.id === req.params.id);
      if (!inq) return res.status(404).json({ error: 'ইনকোয়ারি পাওয়া যায়নি।' });
      inq.status = req.body.status || 'read';
      writeDB(db);
      res.json(inq);
    } catch (err) {
      res.status(500).json({ error: 'Failed to update inquiry status' });
    }
  });

  app.use('/api', apiRouter);

  // Vite Integration / SPA Fallback
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  }

  const port = Number(process.env.PORT) || 3000;
  app.listen(port, '0.0.0.0', () => {
    console.log(`> জয়নাল ফার্নিচার মার্ট Server running at http://0.0.0.0:${port}`);
  });
}

startServer().catch(err => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
