import { useState, useEffect } from 'react';
import {
  Category,
  Product,
  Advertisement,
  WebsiteSettings,
  AdminUser
} from './types.ts';
import {
  fetchSettings,
  fetchCategories,
  fetchProducts,
  fetchAdvertisements,
  adminGetMe,
  adminLogout,
  getAuthToken
} from './services/api.ts';

// Public Components
import Header from './components/Header.tsx';
import Hero from './components/Hero.tsx';
import CategorySection from './components/CategorySection.tsx';
import CategoryPage from './components/CategoryPage.tsx';
import ProductDetailsPage from './components/ProductDetailsPage.tsx';
import ProductCard from './components/ProductCard.tsx';
import AdvertisementBanner from './components/AdvertisementBanner.tsx';
import AboutSection from './components/AboutSection.tsx';
import ContactPage from './components/ContactPage.tsx';
import InquiryModal from './components/InquiryModal.tsx';
import Footer from './components/Footer.tsx';

// Admin Components
import AdminLayout from './components/admin/AdminLayout.tsx';
import AdminLogin from './components/admin/AdminLogin.tsx';
import AdminDashboard from './components/admin/AdminDashboard.tsx';
import AdminCategories from './components/admin/AdminCategories.tsx';
import AdminProducts from './components/admin/AdminProducts.tsx';
import AdminAdvertisements from './components/admin/AdminAdvertisements.tsx';
import AdminHomepage from './components/admin/AdminHomepage.tsx';
import AdminMedia from './components/admin/AdminMedia.tsx';
import AdminSettings from './components/admin/AdminSettings.tsx';

import {
  Sparkles,
  TrendingUp,
  ArrowRight,
  MessageCircle,
  Phone,
  RefreshCw,
  Lock
} from 'lucide-react';

export default function App() {
  // Public Data State
  const [settings, setSettings] = useState<WebsiteSettings>();
  const [categories, setCategories] = useState<Category[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [advertisements, setAdvertisements] = useState<Advertisement[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Navigation State
  const [isAdminRoute, setIsAdminRoute] = useState(false);
  const [adminTab, setAdminTab] = useState<string>('dashboard');
  const [adminUser, setAdminUser] = useState<AdminUser | null>(null);
  const [checkingAuth, setCheckingAuth] = useState(true);

  // Public Navigation View
  const [currentView, setCurrentView] = useState<string>('home');
  const [selectedCategorySlug, setSelectedCategorySlug] = useState<string>('');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

  // Quick Inquiry Modal
  const [inquiryModalProduct, setInquiryModalProduct] = useState<Product | null>(null);

  // Load Initial Public Data from Backend
  const loadPublicData = async () => {
    try {
      setLoading(true);
      setError(null);
      const [settingsData, categoriesData, productsData, adsData] = await Promise.all([
        fetchSettings(),
        fetchCategories(),
        fetchProducts(),
        fetchAdvertisements()
      ]);
      setSettings(settingsData);
      setCategories(categoriesData);
      setProducts(productsData);
      setAdvertisements(adsData);
    } catch (err: any) {
      console.error('Failed to load initial data:', err);
      setError('ডাটা লোড করতে সমস্যা হয়েছে। দয়া করে রিফ্রেশ করুন।');
    } finally {
      setLoading(false);
    }
  };

  // Check Admin Authentication
  const verifyAuth = async () => {
    const token = getAuthToken();
    if (!token) {
      setAdminUser(null);
      setCheckingAuth(false);
      return;
    }
    try {
      setCheckingAuth(true);
      const user = await adminGetMe();
      setAdminUser(user);
    } catch {
      setAdminUser(null);
    } finally {
      setCheckingAuth(false);
    }
  };

  useEffect(() => {
    loadPublicData();
    verifyAuth();
  }, []);

  // Parse Route from Location pathname or hash
  const parseCurrentRoute = () => {
    const pathname = window.location.pathname.toLowerCase();
    const hash = window.location.hash.replace('#/', '').replace('#', '').toLowerCase();

    // Check if on Admin route
    if (pathname.startsWith('/admin') || hash.startsWith('admin')) {
      setIsAdminRoute(true);
      let tab = 'dashboard';
      if (pathname.includes('/admin/')) {
        tab = pathname.replace('/admin/', '');
      } else if (hash.includes('admin/')) {
        tab = hash.replace('admin/', '');
      }
      if (['login', 'dashboard', 'categories', 'products', 'advertisements', 'homepage', 'media', 'settings'].includes(tab)) {
        setAdminTab(tab);
      } else {
        setAdminTab('dashboard');
      }
      return;
    }

    // Public website route
    setIsAdminRoute(false);
    if (!hash || hash === '') {
      setCurrentView('home');
    } else if (hash.startsWith('category/')) {
      const slug = hash.replace('category/', '');
      setSelectedCategorySlug(slug);
      setCurrentView('category');
    } else if (hash.startsWith('product/')) {
      const idOrSlug = hash.replace('product/', '');
      const found = products.find(p => p.id === idOrSlug || p.slug === idOrSlug);
      if (found) {
        setSelectedProduct(found);
        setCurrentView('product-detail');
      }
    } else if (['categories', 'popular', 'about', 'contact'].includes(hash)) {
      setCurrentView(hash);
    }
  };

  useEffect(() => {
    parseCurrentRoute();

    const handleRouteChange = () => {
      parseCurrentRoute();
    };

    window.addEventListener('hashchange', handleRouteChange);
    window.addEventListener('popstate', handleRouteChange);
    return () => {
      window.removeEventListener('hashchange', handleRouteChange);
      window.removeEventListener('popstate', handleRouteChange);
    };
  }, [products]);

  // Navigate function
  const navigateTo = (view: string, param?: string) => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    setIsAdminRoute(false);

    if (view === 'home') {
      window.location.hash = '#/';
      setCurrentView('home');
    } else if (view === 'category' && param) {
      setSelectedCategorySlug(param);
      window.location.hash = `#/category/${param}`;
      setCurrentView('category');
    } else if (view === 'product-detail' && param) {
      const found = products.find(p => p.id === param || p.slug === param);
      if (found) {
        setSelectedProduct(found);
        window.location.hash = `#/product/${found.id}`;
        setCurrentView('product-detail');
      }
    } else {
      window.location.hash = `#/${view}`;
      setCurrentView(view);
    }
  };

  // Admin Navigation
  const navigateAdmin = (tab: string) => {
    setAdminTab(tab);
    window.location.hash = `#/admin/${tab}`;
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleAdminLogout = async () => {
    await adminLogout();
    setAdminUser(null);
    setAdminTab('login');
    window.location.hash = '#/admin/login';
  };

  const handleViewWebsite = () => {
    setIsAdminRoute(false);
    window.location.hash = '#/';
    loadPublicData();
  };

  // Public handlers
  const handleSelectProduct = (product: Product) => {
    setSelectedProduct(product);
    window.location.hash = `#/product/${product.id}`;
    setCurrentView('product-detail');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Ads filtered by placements
  const adHomepageTop = advertisements.find(a => a.placement === 'homepage_top');
  const adBetweenSections = advertisements.find(a => a.placement === 'homepage_between_sections');
  const adBelowFeatured = advertisements.find(a => a.placement === 'homepage_below_featured');
  const adAboveFooter = advertisements.find(a => a.placement === 'homepage_above_footer');

  // Filter products for homepage
  const popularProducts = products.filter(p => p.is_popular);
  const featuredProducts = products.filter(p => p.is_featured);

  // Active Category for Category View
  const activeCategory =
    categories.find(c => c.slug === selectedCategorySlug) || categories[0];

  const whatsappNumber = settings?.whatsapp_number?.replace(/[^0-9]/g, '') || '8801712345678';
  const phonePrimary = settings?.phone_primary || '+880 1712-345678';

  // ==========================================
  // RENDER ADMIN PANEL (SEPARATE INTERFACE)
  // ==========================================
  if (isAdminRoute) {
    if (checkingAuth) {
      return (
        <div className="min-h-screen bg-[#1F140E] flex flex-col items-center justify-center text-amber-200">
          <div className="w-10 h-10 border-4 border-[#B45309] border-t-transparent rounded-full animate-spin mb-3" />
          <p className="text-xs font-semibold">অ্যাডমিন প্রমাণীকরণ যাচাই করা হচ্ছে...</p>
        </div>
      );
    }

    // If not logged in, show dedicated Admin Login view
    if (!adminUser || adminTab === 'login') {
      return (
        <AdminLogin
          onLoginSuccess={user => {
            setAdminUser(user);
            setAdminTab('dashboard');
            window.location.hash = '#/admin/dashboard';
          }}
          onNavigateHome={handleViewWebsite}
        />
      );
    }

    // Authenticated Admin Dashboard Layout
    return (
      <AdminLayout
        user={adminUser}
        activeTab={adminTab}
        onNavigateTab={navigateAdmin}
        onLogout={handleAdminLogout}
        onViewWebsite={handleViewWebsite}
      >
        {adminTab === 'dashboard' && (
          <AdminDashboard
            onNavigateTab={navigateAdmin}
            onOpenAddProduct={() => navigateAdmin('products')}
            onOpenAddCategory={() => navigateAdmin('categories')}
            onOpenAddAd={() => navigateAdmin('advertisements')}
          />
        )}
        {adminTab === 'categories' && <AdminCategories />}
        {adminTab === 'products' && <AdminProducts />}
        {adminTab === 'advertisements' && <AdminAdvertisements />}
        {adminTab === 'homepage' && <AdminHomepage />}
        {adminTab === 'media' && <AdminMedia />}
        {adminTab === 'settings' && <AdminSettings />}
      </AdminLayout>
    );
  }

  // ==========================================
  // RENDER PUBLIC CUSTOMER WEBSITE
  // ==========================================
  return (
    <div className="min-h-screen flex flex-col bg-[#FAF7F2] text-[#2C1810]">
      {/* Header */}
      <Header
        settings={settings}
        currentView={currentView}
        onNavigate={navigateTo}
      />

      {/* Main Content Router */}
      <main className="flex-1">
        {loading ? (
          <div className="min-h-[50vh] flex flex-col items-center justify-center py-20">
            <div className="w-10 h-10 border-4 border-[#B45309] border-t-transparent rounded-full animate-spin mb-4" />
            <p className="text-sm font-semibold text-[#8B4513]">
              জয়নাল ফার্নিচার মার্ট ক্যাটালগ লোড হচ্ছে...
            </p>
          </div>
        ) : error ? (
          <div className="max-w-xl mx-auto my-16 p-8 bg-white rounded-2xl border border-red-200 text-center shadow-xs">
            <p className="text-red-700 font-bold mb-3">{error}</p>
            <button
              onClick={loadPublicData}
              className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-lg bg-[#B45309] text-white hover:bg-[#92400E]"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>পুনরায় চেষ্টা করুন</span>
            </button>
          </div>
        ) : currentView === 'category' && activeCategory ? (
          /* Dedicated Category Page */
          <CategoryPage
            category={activeCategory}
            products={products}
            advertisements={advertisements}
            settings={settings}
            allCategories={categories}
            onViewProduct={handleSelectProduct}
            onNavigateHome={() => navigateTo('home')}
            onNavigateCategories={() => navigateTo('categories')}
            onSelectCategory={slug => navigateTo('category', slug)}
          />
        ) : currentView === 'product-detail' && selectedProduct ? (
          /* Dedicated Product Details Page */
          <ProductDetailsPage
            product={selectedProduct}
            relatedProducts={products.filter(
              p => p.category_slug === selectedProduct.category_slug && p.id !== selectedProduct.id
            )}
            advertisements={advertisements}
            settings={settings}
            onViewProduct={handleSelectProduct}
            onNavigateCategory={slug => navigateTo('category', slug)}
            onNavigateHome={() => navigateTo('home')}
            onOpenInquiryModal={prod => setInquiryModalProduct(prod)}
          />
        ) : currentView === 'categories' ? (
          /* All Categories Overview */
          <div className="py-10 sm:py-16">
            <CategorySection
              categories={categories}
              onSelectCategory={slug => navigateTo('category', slug)}
            />
          </div>
        ) : currentView === 'popular' ? (
          /* Popular Products Page */
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-16">
            <div className="pb-4 border-b border-[#E8DFD3] mb-8">
              <span className="text-xs font-semibold text-[#8B4513] uppercase tracking-wider">
                গ্রাহকদের সবচেয়ে পছন্দের
              </span>
              <h1 className="text-3xl font-bold text-[#2C1810] mt-1">
                জনপ্রিয় ফার্নিচার পণ্যসমূহ
              </h1>
              <p className="text-sm text-[#6B5A4E] mt-1">
                আমাদের শোরুমের সর্বাধিক বিক্রিত ও জনপ্রিয় খাট, সোফা, ডাইনিং ও আলমারি কালেকশন।
              </p>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-6">
              {popularProducts.map(prod => (
                <ProductCard
                  key={prod.id}
                  product={prod}
                  settings={settings}
                  onViewDetails={handleSelectProduct}
                />
              ))}
            </div>
          </div>
        ) : currentView === 'about' ? (
          /* Dedicated About Page */
          <div className="py-10">
            <AboutSection
              settings={settings}
              onContactClick={() => navigateTo('contact')}
            />
          </div>
        ) : currentView === 'contact' ? (
          /* Dedicated Contact Page */
          <ContactPage settings={settings} />
        ) : (
          /* Default: Full Homepage */
          <div>
            {/* Top Advertisement Banner Placement */}
            {adHomepageTop && (
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-4">
                <AdvertisementBanner
                  ad={adHomepageTop}
                  onNavigate={url => {
                    if (url.startsWith('/category/')) {
                      navigateTo('category', url.replace('/category/', ''));
                    } else if (url === '/contact') {
                      navigateTo('contact');
                    }
                  }}
                />
              </div>
            )}

            {/* Large Hero Section */}
            <Hero
              settings={settings}
              onExploreProducts={() => {
                const el = document.getElementById('categories-section');
                el?.scrollIntoView({ behavior: 'smooth' });
              }}
              onContactClick={() => navigateTo('contact')}
            />

            {/* Furniture Categories Section */}
            <div id="categories-section">
              <CategorySection
                categories={categories}
                onSelectCategory={slug => navigateTo('category', slug)}
              />
            </div>

            {/* Advertisement Placement: Between Sections */}
            {adBetweenSections && (
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
                <AdvertisementBanner
                  ad={adBetweenSections}
                  onNavigate={url => {
                    if (url.startsWith('/category/')) {
                      navigateTo('category', url.replace('/category/', ''));
                    } else if (url === '/contact') {
                      navigateTo('contact');
                    }
                  }}
                />
              </div>
            )}

            {/* Popular Furniture Products Section */}
            <section className="py-12 sm:py-16 bg-[#FDFBF7]">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex flex-col sm:flex-row sm:items-end justify-between pb-4 border-b border-[#E8DFD3] mb-8 gap-3">
                  <div>
                    <div className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#8B4513] uppercase tracking-wider mb-1">
                      <TrendingUp className="w-3.5 h-3.5" />
                      <span>গ্রাহকদের সেরা পছন্দ</span>
                    </div>
                    <h2 className="text-2xl sm:text-3xl font-bold text-[#2C1810]">
                      জনপ্রিয় ফার্নিচার পণ্য
                    </h2>
                  </div>
                  <button
                    onClick={() => navigateTo('popular')}
                    className="inline-flex items-center gap-1 text-xs sm:text-sm font-bold text-[#B45309] hover:text-[#92400E] group"
                  >
                    <span>সবগুলো জনপ্রিয় পণ্য</span>
                    <ArrowRight className="w-4 h-4 transform group-hover:translate-x-1 transition-transform" />
                  </button>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-6">
                  {popularProducts.slice(0, 4).map(prod => (
                    <ProductCard
                      key={prod.id}
                      product={prod}
                      settings={settings}
                      onViewDetails={handleSelectProduct}
                    />
                  ))}
                </div>
              </div>
            </section>

            {/* Advertisement Placement: Below Featured Products */}
            {adBelowFeatured && (
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
                <AdvertisementBanner
                  ad={adBelowFeatured}
                  onNavigate={url => {
                    if (url.startsWith('/category/')) {
                      navigateTo('category', url.replace('/category/', ''));
                    } else if (url === '/contact') {
                      navigateTo('contact');
                    }
                  }}
                />
              </div>
            )}

            {/* Featured Products Section */}
            <section className="py-12 sm:py-16 bg-[#FAF7F2]">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex flex-col sm:flex-row sm:items-end justify-between pb-4 border-b border-[#E8DFD3] mb-8 gap-3">
                  <div>
                    <div className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#8B4513] uppercase tracking-wider mb-1">
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>প্রিমিয়াম ও আভিজাত্য</span>
                    </div>
                    <h2 className="text-2xl sm:text-3xl font-bold text-[#2C1810]">
                      সেরা কালেকশন ও স্পেশাল ডিজাইন
                    </h2>
                  </div>
                  <button
                    onClick={() => navigateTo('categories')}
                    className="inline-flex items-center gap-1 text-xs sm:text-sm font-bold text-[#B45309] hover:text-[#92400E] group"
                  >
                    <span>ক্যাটালগ ব্রাউজ করুন</span>
                    <ArrowRight className="w-4 h-4 transform group-hover:translate-x-1 transition-transform" />
                  </button>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-6">
                  {featuredProducts.slice(0, 4).map(prod => (
                    <ProductCard
                      key={prod.id}
                      product={prod}
                      settings={settings}
                      onViewDetails={handleSelectProduct}
                    />
                  ))}
                </div>
              </div>
            </section>

            {/* About the Business Section */}
            <AboutSection
              settings={settings}
              onContactClick={() => navigateTo('contact')}
            />

            {/* Contact & WhatsApp Section Banner */}
            <section className="py-12 bg-gradient-to-r from-[#2C1810] via-[#482819] to-[#2C1810] text-white">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center sm:text-left flex flex-col md:flex-row items-center justify-between gap-6">
                <div>
                  <h3 className="text-2xl sm:text-3xl font-bold tracking-tight text-amber-100">
                    পছন্দের ডিজাইনে কাস্টম ফার্নিচার তৈরি করতে চান?
                  </h3>
                  <p className="text-xs sm:text-sm text-amber-200/80 mt-1 max-w-xl">
                    আপনার ঘরের মাপ অনুযায়ী সেগুন বা মেহগনি কাঠে যেকোনো নকশার ফার্নিচার বানিয়ে নিন সরাসরি কারিগরদের সাথে কথা বলে।
                  </p>
                </div>

                <div className="flex flex-wrap items-center justify-center gap-3 shrink-0">
                  <a
                    href={`https://wa.me/${whatsappNumber}?text=${encodeURIComponent('আসসালামু আলাইকুম, আমি জয়নাল ফার্নিচার মার্ট থেকে কাস্টমাইজড ফার্নিচার অর্ডার করতে চাই।')}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 px-5 py-3 rounded-xl bg-[#25D366] text-white font-bold text-sm hover:bg-[#20BA5A] shadow-md transition-all"
                  >
                    <MessageCircle className="w-4 h-4" />
                    <span>হোয়াটসঅ্যাপে নকশা পাঠান</span>
                  </a>

                  <a
                    href={`tel:${phonePrimary.replace(/[^0-9+]/g, '')}`}
                    className="inline-flex items-center gap-2 px-5 py-3 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-sm border border-white/20 backdrop-blur-xs transition-all"
                  >
                    <Phone className="w-4 h-4 text-amber-400" />
                    <span>সরাসরি কল দিন</span>
                  </a>
                </div>
              </div>
            </section>

            {/* Advertisement Placement: Above Footer */}
            {adAboveFooter && (
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
                <AdvertisementBanner
                  ad={adAboveFooter}
                  onNavigate={url => {
                    if (url.startsWith('/category/')) {
                      navigateTo('category', url.replace('/category/', ''));
                    } else if (url === '/contact') {
                      navigateTo('contact');
                    }
                  }}
                />
              </div>
            )}
          </div>
        )}
      </main>

      {/* Quick Inquiry Modal */}
      {inquiryModalProduct && (
        <InquiryModal
          product={inquiryModalProduct}
          settings={settings}
          onClose={() => setInquiryModalProduct(null)}
        />
      )}

      {/* Footer */}
      <Footer
        categories={categories}
        settings={settings}
        onSelectCategory={slug => navigateTo('category', slug)}
        onNavigate={navigateTo}
      />

      {/* Discreet Admin Portal Access Link in bottom footer bar */}
      <div className="bg-[#1A0E08] py-2 px-4 text-center border-t border-[#311A0E]">
        <button
          onClick={() => {
            setIsAdminRoute(true);
            setAdminTab('login');
            window.location.hash = '#/admin/login';
          }}
          className="inline-flex items-center gap-1.5 text-[11px] text-[#8C7667] hover:text-amber-400 transition-colors"
        >
          <Lock className="w-3 h-3" />
          <span>জয়নাল ফার্নিচার মার্ট অ্যাডমিন লগইন (/admin/login)</span>
        </button>
      </div>
    </div>
  );
}
