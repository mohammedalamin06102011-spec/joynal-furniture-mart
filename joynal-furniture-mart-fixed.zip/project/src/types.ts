export interface Category {
  id: string;
  slug: string;
  name_bn: string;
  name_en: string;
  description_bn: string;
  cover_image: string;
  display_order: number;
  is_active: boolean;
  product_count?: number;
}

export interface Product {
  id: string;
  slug: string;
  category_slug: string;
  name_bn: string;
  name_en: string;
  price: number;
  discount_price?: number;
  short_desc_bn: string;
  full_desc_bn: string;
  main_image: string;
  additional_images: string[];
  dimensions: string;
  materials: string;
  colors: string[];
  in_stock: boolean;
  is_popular: boolean;
  is_featured: boolean;
  created_at: string;
}

export interface Advertisement {
  id: string;
  title: string;
  placement:
    | 'homepage_top'
    | 'homepage_between_sections'
    | 'homepage_below_featured'
    | 'homepage_above_footer'
    | 'category_top'
    | 'category_grid'
    | 'category_bottom'
    | 'product_below_info'
    | 'product_below_related';
  image_url: string;
  destination_url: string;
  start_date: string;
  end_date: string;
  is_enabled: boolean;
  row_interval: number;
  display_order?: number;
  impressions?: number;
  clicks?: number;
  third_party_code?: string;
}

export interface WebsiteSettings {
  site_name_bn: string;
  site_name_en: string;
  slogan_bn: string;
  phone_primary: string;
  phone_secondary: string;
  whatsapp_number: string;
  email: string;
  address_bn: string;
  address_en: string;
  facebook_url: string;
  announcement_text: string;
  hero_title: string;
  hero_subtitle: string;
  hero_image: string;
  hero_cta_text?: string;
  hero_cta_link?: string;
  about_story_bn: string;
  warranty_policy_bn: string;
  currency_symbol?: string;
  seo_title?: string;
  seo_description?: string;
  footer_text_bn?: string;
}

export interface CustomerInquiry {
  id?: string;
  customer_name: string;
  phone: string;
  message: string;
  product_id?: string;
  product_name?: string;
  created_at?: string;
  status?: 'unread' | 'read' | 'contacted';
}

export interface AdminUser {
  id: string;
  username: string;
  email: string;
  role: 'superadmin' | 'admin';
  last_login?: string;
}

export interface MediaItem {
  id: string;
  filename: string;
  original_name: string;
  url: string;
  file_size: number;
  mime_type: string;
  uploaded_at: string;
}

export interface HomepageSectionConfig {
  id: string;
  name_bn: string;
  is_enabled: boolean;
  order: number;
}

export interface HomepageConfig {
  hero_title: string;
  hero_subtitle: string;
  hero_image: string;
  hero_cta_text: string;
  hero_cta_link: string;
  announcement_text: string;
  sections: HomepageSectionConfig[];
  featured_product_ids: string[];
  popular_product_ids: string[];
}

export interface DashboardStats {
  totalProducts: number;
  totalCategories: number;
  activeAds: number;
  inactiveAds: number;
  totalMedia: number;
  unreadInquiries: number;
  totalInquiries: number;
  recentProducts: Product[];
  recentInquiries: CustomerInquiry[];
}
