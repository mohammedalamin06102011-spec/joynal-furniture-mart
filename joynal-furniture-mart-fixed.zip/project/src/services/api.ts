import {
  Category,
  Product,
  Advertisement,
  WebsiteSettings,
  CustomerInquiry,
  AdminUser,
  DashboardStats,
  MediaItem,
  HomepageConfig
} from '../types.ts';

const API_BASE = '/api';
const TOKEN_KEY = 'joynal_admin_token';

export function getAuthToken(): string | null {
  try {
    return localStorage.getItem(TOKEN_KEY);
  } catch {
    return null;
  }
}

export function setAuthToken(token: string): void {
  try {
    localStorage.setItem(TOKEN_KEY, token);
  } catch {}
}

export function clearAuthToken(): void {
  try {
    localStorage.removeItem(TOKEN_KEY);
  } catch {}
}

function getAuthHeaders(): HeadersInit {
  const token = getAuthToken();
  const headers: HeadersInit = {
    'Content-Type': 'application/json'
  };
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }
  return headers;
}

// ==========================================
// PUBLIC API
// ==========================================

export async function fetchSettings(): Promise<WebsiteSettings> {
  const res = await fetch(`${API_BASE}/settings`);
  if (!res.ok) throw new Error('Failed to load settings');
  return res.json();
}

export async function fetchHomepageConfig(): Promise<HomepageConfig> {
  const res = await fetch(`${API_BASE}/homepage`);
  if (!res.ok) throw new Error('Failed to load homepage config');
  return res.json();
}

export async function fetchCategories(): Promise<Category[]> {
  const res = await fetch(`${API_BASE}/categories`);
  if (!res.ok) throw new Error('Failed to load categories');
  return res.json();
}

export async function fetchCategoryBySlug(slug: string): Promise<Category> {
  const res = await fetch(`${API_BASE}/categories/${slug}`);
  if (!res.ok) throw new Error(`Category ${slug} not found`);
  return res.json();
}

export interface ProductFilterParams {
  category?: string;
  search?: string;
  sort?: 'price_asc' | 'price_desc' | 'newest' | 'popular';
  featured?: boolean;
  popular?: boolean;
  limit?: number;
}

export async function fetchProducts(params?: ProductFilterParams): Promise<Product[]> {
  const searchParams = new URLSearchParams();
  if (params?.category) searchParams.set('category', params.category);
  if (params?.search) searchParams.set('search', params.search);
  if (params?.sort) searchParams.set('sort', params.sort);
  if (params?.featured) searchParams.set('featured', 'true');
  if (params?.popular) searchParams.set('popular', 'true');
  if (params?.limit) searchParams.set('limit', params.limit.toString());

  const url = `${API_BASE}/products${searchParams.toString() ? `?${searchParams.toString()}` : ''}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error('Failed to load products');
  return res.json();
}

export async function fetchProductById(idOrSlug: string): Promise<{ product: Product; related: Product[] }> {
  const res = await fetch(`${API_BASE}/products/${idOrSlug}`);
  if (!res.ok) throw new Error(`Product ${idOrSlug} not found`);
  return res.json();
}

export async function fetchAdvertisements(placement?: string): Promise<Advertisement[]> {
  const url = `${API_BASE}/advertisements${placement ? `?placement=${placement}` : ''}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error('Failed to load advertisements');
  return res.json();
}

export async function recordAdClick(id: string): Promise<void> {
  try {
    await fetch(`${API_BASE}/advertisements/${id}/click`, { method: 'POST' });
  } catch {}
}

export async function submitInquiry(data: CustomerInquiry): Promise<{ success: boolean; inquiry: any }> {
  const res = await fetch(`${API_BASE}/inquiries`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  });
  if (!res.ok) {
    const errorData = await res.json().catch(() => ({}));
    throw new Error(errorData.error || 'Failed to submit inquiry');
  }
  return res.json();
}

// ==========================================
// ADMIN API
// ==========================================

export async function adminLogin(username_or_email: string, password: string): Promise<{ token: string; user: AdminUser }> {
  const res = await fetch(`${API_BASE}/admin/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username_or_email, password })
  });
  const data = await res.json();
  if (!res.ok) {
    throw new Error(data.error || 'লগইন ব্যর্থ হয়েছে।');
  }
  setAuthToken(data.token);
  return data;
}

export async function adminLogout(): Promise<void> {
  try {
    await fetch(`${API_BASE}/admin/auth/logout`, {
      method: 'POST',
      headers: getAuthHeaders()
    });
  } finally {
    clearAuthToken();
  }
}

export async function adminGetMe(): Promise<AdminUser> {
  const res = await fetch(`${API_BASE}/admin/auth/me`, {
    headers: getAuthHeaders()
  });
  if (!res.ok) {
    clearAuthToken();
    throw new Error('Unauthorized');
  }
  return res.json();
}

export async function adminChangePassword(current_password: string, new_password: string): Promise<void> {
  const res = await fetch(`${API_BASE}/admin/auth/change-password`, {
    method: 'POST',
    headers: getAuthHeaders(),
    body: JSON.stringify({ current_password, new_password })
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'পাসওয়ার্ড পরিবর্তন ব্যর্থ হয়েছে');
}

export async function adminRecoverPassword(recovery_code: string, new_password: string): Promise<string> {
  const res = await fetch(`${API_BASE}/admin/auth/recover`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ recovery_code, new_password })
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'রিকভারি ব্যর্থ হয়েছে');
  return data.message;
}

export async function adminGetStats(): Promise<DashboardStats> {
  const res = await fetch(`${API_BASE}/admin/dashboard/stats`, {
    headers: getAuthHeaders()
  });
  if (!res.ok) throw new Error('Failed to load admin stats');
  return res.json();
}

// Categories
export async function adminGetCategories(): Promise<Category[]> {
  const res = await fetch(`${API_BASE}/admin/categories`, {
    headers: getAuthHeaders()
  });
  if (!res.ok) throw new Error('Failed to fetch categories');
  return res.json();
}

export async function adminCreateCategory(category: Partial<Category>): Promise<Category> {
  const res = await fetch(`${API_BASE}/admin/categories`, {
    method: 'POST',
    headers: getAuthHeaders(),
    body: JSON.stringify(category)
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Failed to create category');
  return data;
}

export async function adminUpdateCategory(id: string, category: Partial<Category>): Promise<Category> {
  const res = await fetch(`${API_BASE}/admin/categories/${id}`, {
    method: 'PUT',
    headers: getAuthHeaders(),
    body: JSON.stringify(category)
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Failed to update category');
  return data;
}

export async function adminDeleteCategory(id: string, force = false): Promise<void> {
  const res = await fetch(`${API_BASE}/admin/categories/${id}${force ? '?force=true' : ''}`, {
    method: 'DELETE',
    headers: getAuthHeaders()
  });
  const data = await res.json();
  if (!res.ok) {
    const error: any = new Error(data.error || 'Failed to delete category');
    error.hasProducts = data.hasProducts;
    error.productCount = data.productCount;
    throw error;
  }
}

export async function adminReorderCategories(orderedIds: string[]): Promise<void> {
  const res = await fetch(`${API_BASE}/admin/categories/reorder/batch`, {
    method: 'PUT',
    headers: getAuthHeaders(),
    body: JSON.stringify({ orderedIds })
  });
  if (!res.ok) throw new Error('Failed to reorder categories');
}

// Products
export async function adminGetProducts(filters?: { category?: string; search?: string; stock?: string }): Promise<Product[]> {
  const params = new URLSearchParams();
  if (filters?.category) params.set('category', filters.category);
  if (filters?.search) params.set('search', filters.search);
  if (filters?.stock) params.set('stock', filters.stock);

  const res = await fetch(`${API_BASE}/admin/products?${params.toString()}`, {
    headers: getAuthHeaders()
  });
  if (!res.ok) throw new Error('Failed to fetch products');
  return res.json();
}

export async function adminCreateProduct(product: Partial<Product>): Promise<Product> {
  const res = await fetch(`${API_BASE}/admin/products`, {
    method: 'POST',
    headers: getAuthHeaders(),
    body: JSON.stringify(product)
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Failed to create product');
  return data;
}

export async function adminUpdateProduct(id: string, product: Partial<Product>): Promise<Product> {
  const res = await fetch(`${API_BASE}/admin/products/${id}`, {
    method: 'PUT',
    headers: getAuthHeaders(),
    body: JSON.stringify(product)
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Failed to update product');
  return data;
}

export async function adminDeleteProduct(id: string): Promise<void> {
  const res = await fetch(`${API_BASE}/admin/products/${id}`, {
    method: 'DELETE',
    headers: getAuthHeaders()
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Failed to delete product');
}

// Advertisements
export async function adminGetAdvertisements(): Promise<Advertisement[]> {
  const res = await fetch(`${API_BASE}/admin/advertisements`, {
    headers: getAuthHeaders()
  });
  if (!res.ok) throw new Error('Failed to fetch advertisements');
  return res.json();
}

export async function adminCreateAdvertisement(ad: Partial<Advertisement>): Promise<Advertisement> {
  const res = await fetch(`${API_BASE}/admin/advertisements`, {
    method: 'POST',
    headers: getAuthHeaders(),
    body: JSON.stringify(ad)
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Failed to create advertisement');
  return data;
}

export async function adminUpdateAdvertisement(id: string, ad: Partial<Advertisement>): Promise<Advertisement> {
  const res = await fetch(`${API_BASE}/admin/advertisements/${id}`, {
    method: 'PUT',
    headers: getAuthHeaders(),
    body: JSON.stringify(ad)
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Failed to update advertisement');
  return data;
}

export async function adminDeleteAdvertisement(id: string): Promise<void> {
  const res = await fetch(`${API_BASE}/admin/advertisements/${id}`, {
    method: 'DELETE',
    headers: getAuthHeaders()
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Failed to delete advertisement');
}

// Homepage
export async function adminGetHomepageConfig(): Promise<HomepageConfig> {
  const res = await fetch(`${API_BASE}/admin/homepage`, {
    headers: getAuthHeaders()
  });
  if (!res.ok) throw new Error('Failed to fetch homepage config');
  return res.json();
}

export async function adminUpdateHomepageConfig(config: Partial<HomepageConfig>): Promise<HomepageConfig> {
  const res = await fetch(`${API_BASE}/admin/homepage`, {
    method: 'PUT',
    headers: getAuthHeaders(),
    body: JSON.stringify(config)
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Failed to update homepage config');
  return data;
}

// Media
export async function adminGetMedia(): Promise<MediaItem[]> {
  const res = await fetch(`${API_BASE}/admin/media`, {
    headers: getAuthHeaders()
  });
  if (!res.ok) throw new Error('Failed to fetch media');
  return res.json();
}

export async function adminUploadMedia(filename: string, file_data: string, mime_type: string): Promise<MediaItem> {
  const res = await fetch(`${API_BASE}/admin/media/upload`, {
    method: 'POST',
    headers: getAuthHeaders(),
    body: JSON.stringify({ filename, file_data, mime_type })
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Failed to upload image');
  return data;
}

export async function adminDeleteMedia(id: string): Promise<void> {
  const res = await fetch(`${API_BASE}/admin/media/${id}`, {
    method: 'DELETE',
    headers: getAuthHeaders()
  });
  const data = await res.json();
  if (!res.ok) {
    const error: any = new Error(data.error || 'Failed to delete media');
    error.inUse = data.inUse;
    throw error;
  }
}

// Settings
export async function adminGetSettings(): Promise<WebsiteSettings> {
  const res = await fetch(`${API_BASE}/admin/settings`, {
    headers: getAuthHeaders()
  });
  if (!res.ok) throw new Error('Failed to fetch settings');
  return res.json();
}

export async function adminUpdateSettings(settings: Partial<WebsiteSettings>): Promise<void> {
  const res = await fetch(`${API_BASE}/admin/settings`, {
    method: 'PUT',
    headers: getAuthHeaders(),
    body: JSON.stringify(settings)
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Failed to update settings');
}

// Inquiries
export async function adminGetInquiries(): Promise<CustomerInquiry[]> {
  const res = await fetch(`${API_BASE}/admin/inquiries`, {
    headers: getAuthHeaders()
  });
  if (!res.ok) throw new Error('Failed to fetch inquiries');
  return res.json();
}

export async function adminUpdateInquiryStatus(id: string, status: 'unread' | 'read' | 'contacted'): Promise<CustomerInquiry> {
  const res = await fetch(`${API_BASE}/admin/inquiries/${id}/status`, {
    method: 'PATCH',
    headers: getAuthHeaders(),
    body: JSON.stringify({ status })
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Failed to update inquiry status');
  return data;
}
