import { useState, useEffect } from 'react';
import { WebsiteSettings } from '../../types.ts';
import {
  adminGetSettings,
  adminUpdateSettings,
  adminChangePassword
} from '../../services/api.ts';
import {
  Save,
  Lock,
  Globe,
  Phone,
  MessageCircle,
  MapPin,
  Mail,
  Facebook,
  ShieldCheck,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';

export default function AdminSettings() {
  const [settings, setSettings] = useState<WebsiteSettings | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [successMsg, setSuccessMsg] = useState('');

  // Form Fields
  const [siteNameBn, setSiteNameBn] = useState('');
  const [siteNameEn, setSiteNameEn] = useState('');
  const [sloganBn, setSloganBn] = useState('');
  const [phonePrimary, setPhonePrimary] = useState('');
  const [phoneSecondary, setPhoneSecondary] = useState('');
  const [whatsappNumber, setWhatsappNumber] = useState('');
  const [email, setEmail] = useState('');
  const [addressBn, setAddressBn] = useState('');
  const [addressEn, setAddressEn] = useState('');
  const [facebookUrl, setFacebookUrl] = useState('');
  const [footerTextBn, setFooterTextBn] = useState('');
  const [seoTitle, setSeoTitle] = useState('');
  const [seoDescription, setSeoDescription] = useState('');
  const [currencySymbol, setCurrencySymbol] = useState('৳');
  const [warrantyPolicyBn, setWarrantyPolicyBn] = useState('');

  // Password Change State
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [passwordLoading, setPasswordLoading] = useState(false);
  const [passwordSuccess, setPasswordSuccess] = useState('');
  const [passwordError, setPasswordError] = useState('');

  const loadSettings = async () => {
    try {
      setLoading(true);
      const data = await adminGetSettings();
      setSettings(data);
      setSiteNameBn(data.site_name_bn || 'জয়নাল ফার্নিচার মার্ট');
      setSiteNameEn(data.site_name_en || 'Joynal Furniture Mart');
      setSloganBn(data.slogan_bn || '');
      setPhonePrimary(data.phone_primary || '');
      setPhoneSecondary(data.phone_secondary || '');
      setWhatsappNumber(data.whatsapp_number || '');
      setEmail(data.email || '');
      setAddressBn(data.address_bn || '');
      setAddressEn(data.address_en || '');
      setFacebookUrl(data.facebook_url || '');
      setFooterTextBn(data.footer_text_bn || '');
      setSeoTitle(data.seo_title || '');
      setSeoDescription(data.seo_description || '');
      setCurrencySymbol(data.currency_symbol || '৳');
      setWarrantyPolicyBn(data.warranty_policy_bn || '');
    } catch (err: any) {
      console.error('Failed to load settings:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadSettings();
  }, []);

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      setSaving(true);
      await adminUpdateSettings({
        site_name_bn: siteNameBn.trim(),
        site_name_en: siteNameEn.trim(),
        slogan_bn: sloganBn.trim(),
        phone_primary: phonePrimary.trim(),
        phone_secondary: phoneSecondary.trim(),
        whatsapp_number: whatsappNumber.trim(),
        email: email.trim(),
        address_bn: addressBn.trim(),
        address_en: addressEn.trim(),
        facebook_url: facebookUrl.trim(),
        footer_text_bn: footerTextBn.trim(),
        seo_title: seoTitle.trim(),
        seo_description: seoDescription.trim(),
        currency_symbol: currencySymbol.trim(),
        warranty_policy_bn: warrantyPolicyBn.trim()
      });
      setSuccessMsg('ওয়েবসাইট সেটিংস সফলভাবে আপডেট করা হয়েছে!');
      setTimeout(() => setSuccessMsg(''), 3000);
    } catch (err: any) {
      alert(err.message || 'সেটিংস আপডেট ব্যর্থ হয়েছে।');
    } finally {
      setSaving(false);
    }
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newPassword !== confirmPassword) {
      setPasswordError('নতুন পাসওয়ার্ড দুটি মিলছে না।');
      return;
    }
    if (newPassword.length < 12) {
      setPasswordError('পাসওয়ার্ড কমপক্ষে ১২ অক্ষরের হতে হবে।');
      return;
    }

    try {
      setPasswordLoading(true);
      setPasswordError('');
      await adminChangePassword(currentPassword, newPassword);
      setPasswordSuccess('অ্যাডমিন পাসওয়ার্ড সফলভাবে পরিবর্তিত হয়েছে।');
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
      setTimeout(() => setPasswordSuccess(''), 4000);
    } catch (err: any) {
      setPasswordError(err.message || 'পাসওয়ার্ড পরিবর্তন ব্যর্থ হয়েছে।');
    } finally {
      setPasswordLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="py-20 text-center text-xs font-semibold text-[#8B4513]">
        সেটিংস লোড হচ্ছে...
      </div>
    );
  }

  return (
    <div className="space-y-8 max-w-5xl">
      {/* Top Header */}
      <div className="pb-4 border-b border-[#E5DACD]">
        <h2 className="text-xl font-bold text-[#2C1810]">ওয়েবসাইট সেটিংস ও ব্র্যান্ডিং</h2>
        <p className="text-xs text-[#7A695C]">
          ব্যবসার নাম, যোগাযোগের হটলাইন, শো-রুমের ঠিকানা, এসইও তথ্য ও অ্যাডমিন পাসওয়ার্ড ব্যবস্থাপনা করুন।
        </p>
      </div>

      {successMsg && (
        <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-semibold animate-fadeIn">
          {successMsg}
        </div>
      )}

      {/* Main Settings Form */}
      <form onSubmit={handleSaveSettings} className="space-y-6">
        {/* Brand Information */}
        <div className="bg-white rounded-2xl p-5 sm:p-6 border border-[#E5DACD] shadow-xs space-y-4">
          <div className="flex items-center gap-2 pb-2 border-b border-[#F0EAE1]">
            <Globe className="w-4 h-4 text-[#B45309]" />
            <h3 className="text-sm font-bold text-[#2C1810] uppercase tracking-wider">
              ১. সাধারণ ব্র্যান্ড তথ্য
            </h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-[#2C1810] mb-1">
                ওয়েবসাইট নাম (বাংলা) *
              </label>
              <input
                type="text"
                required
                value={siteNameBn}
                onChange={e => setSiteNameBn(e.target.value)}
                placeholder="জয়নাল ফার্নিচার মার্ট"
                className="w-full px-3 py-2 text-xs sm:text-sm bg-[#FAF7F2] border border-[#D8CEBF] rounded-xl text-[#2C1810]"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-[#2C1810] mb-1">
                ইংরেজি ব্র্যান্ড নাম *
              </label>
              <input
                type="text"
                required
                value={siteNameEn}
                onChange={e => setSiteNameEn(e.target.value)}
                placeholder="Joynal Furniture Mart"
                className="w-full px-3 py-2 text-xs sm:text-sm bg-[#FAF7F2] border border-[#D8CEBF] rounded-xl text-[#2C1810]"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="sm:col-span-2">
              <label className="block text-xs font-bold text-[#2C1810] mb-1">
                স্লোগান / ট্যাগলাইন
              </label>
              <input
                type="text"
                value={sloganBn}
                onChange={e => setSloganBn(e.target.value)}
                placeholder="অভিজাত ও আধুনিক টেকসই কাঠের ফার্নিচার সম্ভার"
                className="w-full px-3 py-2 text-xs sm:text-sm bg-[#FAF7F2] border border-[#D8CEBF] rounded-xl text-[#2C1810]"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-[#2C1810] mb-1">
                কারেন্সি প্রতীক
              </label>
              <input
                type="text"
                value={currencySymbol}
                onChange={e => setCurrencySymbol(e.target.value)}
                placeholder="৳"
                className="w-full px-3 py-2 text-xs sm:text-sm bg-[#FAF7F2] border border-[#D8CEBF] rounded-xl text-[#2C1810] font-bold"
              />
            </div>
          </div>
        </div>

        {/* Contact Information */}
        <div className="bg-white rounded-2xl p-5 sm:p-6 border border-[#E5DACD] shadow-xs space-y-4">
          <div className="flex items-center gap-2 pb-2 border-b border-[#F0EAE1]">
            <Phone className="w-4 h-4 text-[#B45309]" />
            <h3 className="text-sm font-bold text-[#2C1810] uppercase tracking-wider">
              ২. যোগাযোগ ও শো-রুমের বিবরণ
            </h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-bold text-[#2C1810] mb-1">
                প্রধান মোবাইল নম্বর (হটলাইন) *
              </label>
              <input
                type="text"
                required
                value={phonePrimary}
                onChange={e => setPhonePrimary(e.target.value)}
                placeholder="+880 1712-345678"
                className="w-full px-3 py-2 text-xs bg-[#FAF7F2] border border-[#D8CEBF] rounded-xl text-[#2C1810]"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-[#2C1810] mb-1">
                দ্বিতীয় মোবাইল নম্বর (ঐচ্ছিক)
              </label>
              <input
                type="text"
                value={phoneSecondary}
                onChange={e => setPhoneSecondary(e.target.value)}
                placeholder="+880 1812-987654"
                className="w-full px-3 py-2 text-xs bg-[#FAF7F2] border border-[#D8CEBF] rounded-xl text-[#2C1810]"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-[#2C1810] mb-1">
                হোয়াটসঅ্যাপ নম্বর (কান্ট্রি কোড সহ) *
              </label>
              <input
                type="text"
                required
                value={whatsappNumber}
                onChange={e => setWhatsappNumber(e.target.value)}
                placeholder="8801712345678"
                className="w-full px-3 py-2 text-xs bg-[#FAF7F2] border border-[#D8CEBF] rounded-xl text-[#2C1810]"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-[#2C1810] mb-1">
                শো-রুমের ঠিকানা (বাংলা) *
              </label>
              <textarea
                rows={2}
                required
                value={addressBn}
                onChange={e => setAddressBn(e.target.value)}
                placeholder="দোকান নং ১২-১৫, প্রধান সড়ক, মিরপুর-১০ গোলচত্বর, ঢাকা-১২১৬"
                className="w-full px-3 py-2 text-xs bg-[#FAF7F2] border border-[#D8CEBF] rounded-xl text-[#2C1810] resize-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-[#2C1810] mb-1">
                শো-রুমের ঠিকানা (ইংরেজি)
              </label>
              <textarea
                rows={2}
                value={addressEn}
                onChange={e => setAddressEn(e.target.value)}
                placeholder="Shop 12-15, Main Road, Mirpur-10 Circle, Dhaka-1216, Bangladesh"
                className="w-full px-3 py-2 text-xs bg-[#FAF7F2] border border-[#D8CEBF] rounded-xl text-[#2C1810] resize-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-[#2C1810] mb-1">
                ইমেইল ঠিকানা
              </label>
              <input
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="info@joynalfurniture.com"
                className="w-full px-3 py-2 text-xs bg-[#FAF7F2] border border-[#D8CEBF] rounded-xl text-[#2C1810]"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-[#2C1810] mb-1">
                ফেসবুক পেজ লিংক
              </label>
              <input
                type="text"
                value={facebookUrl}
                onChange={e => setFacebookUrl(e.target.value)}
                placeholder="https://facebook.com/joynalfurnituremart"
                className="w-full px-3 py-2 text-xs bg-[#FAF7F2] border border-[#D8CEBF] rounded-xl text-[#2C1810]"
              />
            </div>
          </div>
        </div>

        {/* SEO & Warranty */}
        <div className="bg-white rounded-2xl p-5 sm:p-6 border border-[#E5DACD] shadow-xs space-y-4">
          <div className="flex items-center gap-2 pb-2 border-b border-[#F0EAE1]">
            <ShieldCheck className="w-4 h-4 text-[#B45309]" />
            <h3 className="text-sm font-bold text-[#2C1810] uppercase tracking-wider">
              ৩. সার্চ ইঞ্জিন (SEO) ও ওয়ারেন্টি প্রতিশ্রুতি
            </h3>
          </div>

          <div>
            <label className="block text-xs font-bold text-[#2C1810] mb-1">
              এসইও মেটা শিরোনাম (SEO Title)
            </label>
            <input
              type="text"
              value={seoTitle}
              onChange={e => setSeoTitle(e.target.value)}
              placeholder="জয়নাল ফার্নিচার মার্ট - আধুনিক ও ঐতিহ্যবাহী টেকসই কাঠের ফার্নিচার"
              className="w-full px-3 py-2 text-xs bg-[#FAF7F2] border border-[#D8CEBF] rounded-xl text-[#2C1810]"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-[#2C1810] mb-1">
              এসইও মেটা বর্ণনা (SEO Meta Description)
            </label>
            <textarea
              rows={2}
              value={seoDescription}
              onChange={e => setSeoDescription(e.target.value)}
              placeholder="চিটাগাং সেগুন ও সিজনড মেহগনি কাঠে তৈরি শৈল্পিক কারুকার্যখচিত খাট, সোফা, ডাইনিং ও গৃহসজ্জা সামগ্রী..."
              className="w-full px-3 py-2 text-xs bg-[#FAF7F2] border border-[#D8CEBF] rounded-xl text-[#2C1810] resize-none"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-[#2C1810] mb-1">
              ওয়ারেন্টি ও ঘুণের গ্যারান্টি পলিসি
            </label>
            <input
              type="text"
              value={warrantyPolicyBn}
              onChange={e => setWarrantyPolicyBn(e.target.value)}
              placeholder="কাঠের ঘুণের বিরুদ্ধে ১৫ বছরের গ্যারান্টি এবং ফিনিশিং সার্ভিসের জন্য ১ বছরের ফ্রি ওয়ারেন্টি।"
              className="w-full px-3 py-2 text-xs bg-[#FAF7F2] border border-[#D8CEBF] rounded-xl text-[#2C1810]"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-[#2C1810] mb-1">
              ফুটার কপিরাইট নোট
            </label>
            <input
              type="text"
              value={footerTextBn}
              onChange={e => setFooterTextBn(e.target.value)}
              placeholder="১০০% খাঁটি সিজনড সেগুন ও মেহগনি কাঠ দিয়ে নির্মিত হস্তশিল্প ফার্নিচার।"
              className="w-full px-3 py-2 text-xs bg-[#FAF7F2] border border-[#D8CEBF] rounded-xl text-[#2C1810]"
            />
          </div>
        </div>

        <div className="flex justify-end">
          <button
            type="submit"
            disabled={saving}
            className="flex items-center gap-2 px-6 py-3 rounded-xl bg-[#B45309] text-white font-bold text-sm hover:bg-[#92400E] shadow-sm disabled:opacity-50"
          >
            <Save className="w-4 h-4" />
            <span>{saving ? 'সংরক্ষণ হচ্ছে...' : 'সেটিংস সংরক্ষণ করুন'}</span>
          </button>
        </div>
      </form>

      {/* Admin Change Password Card */}
      <div className="bg-white rounded-2xl p-5 sm:p-6 border border-[#E5DACD] shadow-xs">
        <div className="flex items-center gap-2 pb-2 border-b border-[#F0EAE1] mb-4">
          <Lock className="w-4 h-4 text-[#B45309]" />
          <h3 className="text-sm font-bold text-[#2C1810] uppercase tracking-wider">
            ৪. অ্যাডমিন পাসওয়ার্ড পরিবর্তন
          </h3>
        </div>

        {passwordSuccess && (
          <div className="p-3 mb-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-semibold flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{passwordSuccess}</span>
          </div>
        )}

        {passwordError && (
          <div className="p-3 mb-4 rounded-xl bg-red-50 border border-red-200 text-red-800 text-xs font-semibold flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
            <span>{passwordError}</span>
          </div>
        )}

        <form onSubmit={handleChangePassword} className="space-y-4 max-w-md">
          <div>
            <label className="block text-xs font-bold text-[#2C1810] mb-1">
              বর্তমান পাসওয়ার্ড *
            </label>
            <input
              type="password"
              required
              value={currentPassword}
              onChange={e => setCurrentPassword(e.target.value)}
              placeholder="বর্তমান পাসওয়ার্ড দিন"
              className="w-full px-3 py-2 text-xs bg-[#FAF7F2] border border-[#D8CEBF] rounded-lg text-[#2C1810]"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-[#2C1810] mb-1">
              নতুন পাসওয়ার্ড (কমপক্ষে ১২ অক্ষর) *
            </label>
            <input
              type="password"
              required
              minLength={12}
              value={newPassword}
              onChange={e => setNewPassword(e.target.value)}
              placeholder="নতুন পাসওয়ার্ড দিন"
              className="w-full px-3 py-2 text-xs bg-[#FAF7F2] border border-[#D8CEBF] rounded-lg text-[#2C1810]"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-[#2C1810] mb-1">
              নতুন পাসওয়ার্ড নিশ্চিত করুন *
            </label>
            <input
              type="password"
              required
              minLength={12}
              value={confirmPassword}
              onChange={e => setConfirmPassword(e.target.value)}
              placeholder="আবার লিখুন"
              className="w-full px-3 py-2 text-xs bg-[#FAF7F2] border border-[#D8CEBF] rounded-lg text-[#2C1810]"
            />
          </div>

          <button
            type="submit"
            disabled={passwordLoading}
            className="px-5 py-2.5 rounded-xl bg-[#2C1810] text-amber-200 font-bold text-xs hover:bg-[#3D2316] transition-colors disabled:opacity-50"
          >
            {passwordLoading ? 'পরিবর্তন হচ্ছে...' : 'পাসওয়ার্ড আপডেট করুন'}
          </button>
        </form>
      </div>
    </div>
  );
}
