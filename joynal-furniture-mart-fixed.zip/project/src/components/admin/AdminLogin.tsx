import { useState } from 'react';
import { adminLogin, adminRecoverPassword } from '../../services/api.ts';
import { AdminUser } from '../../types.ts';
import { Armchair, Eye, EyeOff, Lock, User, AlertCircle, CheckCircle2, KeyRound } from 'lucide-react';

interface AdminLoginProps {
  onLoginSuccess: (user: AdminUser) => void;
  onNavigateHome: () => void;
}

export default function AdminLogin({ onLoginSuccess, onNavigateHome }: AdminLoginProps) {
  const [usernameOrEmail, setUsernameOrEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  // Recovery modal
  const [showRecovery, setShowRecovery] = useState(false);
  const [recoveryCode, setRecoveryCode] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [recoveryLoading, setRecoveryLoading] = useState(false);
  const [recoverySuccess, setRecoverySuccess] = useState('');
  const [recoveryError, setRecoveryError] = useState('');

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!usernameOrEmail.trim() || !password.trim()) {
      setErrorMessage('ইউজারনেম/ইমেইল এবং পাসওয়ার্ড আবশ্যক।');
      return;
    }

    try {
      setLoading(true);
      setErrorMessage('');
      const data = await adminLogin(usernameOrEmail.trim(), password);
      onLoginSuccess(data.user);
    } catch (err: any) {
      setErrorMessage(err.message || 'লগইন ব্যর্থ হয়েছে। তথ্য যাচাই করুন।');
    } finally {
      setLoading(false);
    }
  };

  const handleRecover = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!recoveryCode.trim() || !newPassword.trim()) {
      setRecoveryError('রিকভারি কোড ও নতুন পাসওয়ার্ড আবশ্যক।');
      return;
    }
    try {
      setRecoveryLoading(true);
      setRecoveryError('');
      const msg = await adminRecoverPassword(recoveryCode.trim(), newPassword);
      setRecoverySuccess(msg);
      setPassword(newPassword);
      setTimeout(() => {
        setShowRecovery(false);
        setRecoverySuccess('');
      }, 2000);
    } catch (err: any) {
      setRecoveryError(err.message || 'রিকভারি কোড সঠিক নয়।');
    } finally {
      setRecoveryLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#1F140E] flex flex-col justify-center items-center p-4">
      <div className="w-full max-w-md bg-[#2A1B14] rounded-2xl border border-[#442B1F] shadow-2xl p-6 sm:p-8">
        {/* Brand Header */}
        <div className="text-center mb-8">
          <div className="inline-flex w-14 h-14 rounded-2xl bg-gradient-to-br from-[#B45309] to-[#78350F] items-center justify-center text-amber-100 shadow-md mb-3">
            <Armchair className="w-8 h-8" />
          </div>
          <h1 className="text-2xl font-bold text-white tracking-tight">
            জয়নাল ফার্নিচার মার্ট
          </h1>
          <p className="text-xs font-semibold text-amber-400 uppercase tracking-wider mt-1">
            ম্যানেজমেন্ট অ্যাডমিন প্যানেল
          </p>
        </div>

        {/* Error Message */}
        {errorMessage && (
          <div className="mb-5 p-3 rounded-xl bg-red-950/80 border border-red-800/80 text-red-200 text-xs flex items-start gap-2.5">
            <AlertCircle className="w-4 h-4 shrink-0 text-red-400 mt-0.5" />
            <span>{errorMessage}</span>
          </div>
        )}

        {/* Login Form */}
        <form onSubmit={handleLogin} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-amber-200/90 mb-1.5">
              ইউজারনেম অথবা ইমেইল
            </label>
            <div className="relative">
              <User className="w-4 h-4 text-[#8C6B56] absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                required
                value={usernameOrEmail}
                onChange={e => setUsernameOrEmail(e.target.value)}
                placeholder="admin অথবা admin@joynalfurniture.com"
                className="w-full pl-10 pr-3.5 py-2.5 text-sm bg-[#1A0E08] border border-[#4A3224] rounded-xl text-white placeholder-[#785E4E] focus:outline-none focus:border-[#B45309] transition-colors"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-amber-200/90 mb-1.5">
              অ্যাডমিন পাসওয়ার্ড
            </label>
            <div className="relative">
              <Lock className="w-4 h-4 text-[#8C6B56] absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type={showPassword ? 'text' : 'password'}
                required
                value={password}
                onChange={e => setPassword(e.target.value)}
                placeholder="পাসওয়ার্ড লিখুন"
                className="w-full pl-10 pr-10 py-2.5 text-sm bg-[#1A0E08] border border-[#4A3224] rounded-xl text-white placeholder-[#785E4E] focus:outline-none focus:border-[#B45309] transition-colors"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-[#8C6B56] hover:text-amber-300 p-1"
                aria-label={showPassword ? 'পাসওয়ার্ড লুকান' : 'পাসওয়ার্ড দেখুন'}
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-[#B45309] to-[#92400E] text-white font-bold text-sm hover:from-[#C25E0A] hover:to-[#A3470E] shadow-lg transition-all disabled:opacity-50 mt-2"
          >
            {loading ? 'যাচাই করা হচ্ছে...' : 'লগইন করুন'}
          </button>
        </form>

        {/* Quick Recovery & Links */}
        <div className="mt-6 pt-5 border-t border-[#3D2619] flex items-center justify-between text-xs text-[#9E8372]">
          <button
            onClick={() => setShowRecovery(true)}
            className="hover:text-amber-300 transition-colors flex items-center gap-1"
          >
            <KeyRound className="w-3.5 h-3.5" />
            <span>পাসওয়ার্ড রিকভারি?</span>
          </button>
          <button
            onClick={onNavigateHome}
            className="hover:text-amber-300 transition-colors"
          >
            ← ওয়েবসাইটে ফিরে যান
          </button>
        </div>

      </div>

      {/* Recovery Modal */}
      {showRecovery && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
          <div className="w-full max-w-md bg-[#2A1B14] rounded-2xl border border-[#442B1F] p-6 shadow-2xl">
            <h3 className="text-base font-bold text-white mb-2">অ্যাডমিন পাসওয়ার্ড রিকভারি</h3>
            <p className="text-xs text-[#A68F80] mb-4">
              আপনার সার্ভারে সেট করা সিক্রেট রিকভারি কোড দিয়ে অ্যাডমিন পাসওয়ার্ড রিসেট করুন।
            </p>

            {recoverySuccess ? (
              <div className="p-4 rounded-xl bg-emerald-950/80 border border-emerald-800 text-emerald-200 text-xs flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>{recoverySuccess}</span>
              </div>
            ) : (
              <form onSubmit={handleRecover} className="space-y-3">
                {recoveryError && (
                  <div className="p-2.5 rounded-lg bg-red-950/80 border border-red-800 text-red-200 text-xs">
                    {recoveryError}
                  </div>
                )}
                <div>
                  <label className="block text-xs font-semibold text-amber-200/90 mb-1">
                    রিকভারি কোড
                  </label>
                  <input
                    type="text"
                    required
                    value={recoveryCode}
                    onChange={e => setRecoveryCode(e.target.value)}
                    placeholder="রিকভারি কোড লিখুন"
                    className="w-full px-3 py-2 text-xs bg-[#1A0E08] border border-[#4A3224] rounded-lg text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-amber-200/90 mb-1">
                    নতুন পাসওয়ার্ড (কমপক্ষে ১২ অক্ষর)
                  </label>
                  <input
                    type="password"
                    required
                    minLength={12}
                    value={newPassword}
                    onChange={e => setNewPassword(e.target.value)}
                    placeholder="নতুন পাসওয়ার্ড দিন"
                    className="w-full px-3 py-2 text-xs bg-[#1A0E08] border border-[#4A3224] rounded-lg text-white"
                  />
                </div>
                <div className="flex items-center justify-end gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setShowRecovery(false)}
                    className="px-3.5 py-2 text-xs text-[#A68F80] hover:text-white"
                  >
                    বাতিল
                  </button>
                  <button
                    type="submit"
                    disabled={recoveryLoading}
                    className="px-4 py-2 text-xs font-bold rounded-lg bg-[#B45309] text-white hover:bg-[#92400E]"
                  >
                    {recoveryLoading ? 'রিসেট হচ্ছে...' : 'পাসওয়ার্ড রিসেট করুন'}
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
