import { useEffect, useState } from 'react';
import { DashboardStats } from '../../types.ts';
import { adminGetStats, adminUpdateInquiryStatus } from '../../services/api.ts';
import {
  Package,
  Layers,
  Megaphone,
  MessageCircle,
  Plus,
  Home,
  Clock,
  ArrowRight,
  Phone,
  RefreshCw
} from 'lucide-react';

interface AdminDashboardProps {
  onNavigateTab: (tab: string) => void;
  onOpenAddProduct?: () => void;
  onOpenAddCategory?: () => void;
  onOpenAddAd?: () => void;
}

export default function AdminDashboard({
  onNavigateTab,
  onOpenAddProduct,
  onOpenAddCategory,
  onOpenAddAd
}: AdminDashboardProps) {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const loadStats = async () => {
    try {
      setLoading(true);
      setError('');
      const data = await adminGetStats();
      setStats(data);
    } catch (err: any) {
      setError(err.message || 'পরিসংখ্যান লোড করতে ব্যর্থ হয়েছে');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadStats();
  }, []);

  const handleInquiryStatus = async (id: string, status: 'read' | 'contacted') => {
    try {
      await adminUpdateInquiryStatus(id, status);
      loadStats();
    } catch (err) {}
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-24">
        <div className="w-9 h-9 border-3 border-[#B45309] border-t-transparent rounded-full animate-spin mb-3" />
        <p className="text-xs font-semibold text-[#8B4513]">ড্যাশবোর্ড ডাটা লোড হচ্ছে...</p>
      </div>
    );
  }

  if (error || !stats) {
    return (
      <div className="p-8 text-center bg-white rounded-2xl border border-red-200">
        <p className="text-sm font-bold text-red-700 mb-3">{error || 'কোনো ডাটা পাওয়া যায়নি।'}</p>
        <button
          onClick={loadStats}
          className="px-4 py-2 text-xs font-semibold rounded-lg bg-[#B45309] text-white hover:bg-[#92400E]"
        >
          পুনরায় লোড করুন
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-6 sm:space-y-8">
      {/* Quick Action Ribbon */}
      <div className="bg-white p-4 sm:p-5 rounded-2xl border border-[#E5DACD] shadow-xs flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-base sm:text-lg font-bold text-[#2C1810]">
            স্বাগতম! জয়নাল ফার্নিচার মার্ট অ্যাডমিন প্যানেলে
          </h2>
          <p className="text-xs text-[#7A695C]">
            পণ্য, ক্যাটাগরি, বিজ্ঞাপন ও ওয়েবসাইটের যাবতীয় তথ্য এখান থেকে সরাসরি পরিচালনা করুন।
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => {
              onNavigateTab('products');
              onOpenAddProduct?.();
            }}
            className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold rounded-xl bg-[#B45309] text-white hover:bg-[#92400E] shadow-xs transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>নতুন পণ্য</span>
          </button>

          <button
            onClick={() => {
              onNavigateTab('categories');
              onOpenAddCategory?.();
            }}
            className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold rounded-xl bg-[#FAF7F2] border border-[#D5C2B1] text-[#2C1810] hover:bg-[#EFE7DE] transition-colors"
          >
            <Plus className="w-3.5 h-3.5 text-[#B45309]" />
            <span>নতুন ক্যাটাগরি</span>
          </button>

          <button
            onClick={() => {
              onNavigateTab('advertisements');
              onOpenAddAd?.();
            }}
            className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold rounded-xl bg-[#FAF7F2] border border-[#D5C2B1] text-[#2C1810] hover:bg-[#EFE7DE] transition-colors"
          >
            <Megaphone className="w-3.5 h-3.5 text-[#B45309]" />
            <span>নতুন বিজ্ঞাপন</span>
          </button>

          <button
            onClick={() => onNavigateTab('homepage')}
            className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold rounded-xl bg-[#FAF7F2] border border-[#D5C2B1] text-[#2C1810] hover:bg-[#EFE7DE] transition-colors"
          >
            <Home className="w-3.5 h-3.5 text-[#B45309]" />
            <span>হোমপেজ এডিট</span>
          </button>

          <button
            onClick={loadStats}
            className="p-2 rounded-xl text-[#7A695C] hover:bg-[#FAF7F2] transition-colors"
            title="রিফ্রেশ করুন"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Summary Stat Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
        {/* Total Products */}
        <div
          onClick={() => onNavigateTab('products')}
          className="bg-white p-4 sm:p-5 rounded-2xl border border-[#E5DACD] shadow-xs cursor-pointer hover:border-[#B45309] transition-all group"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-[#7A695C] uppercase tracking-wider">
              মোট পণ্য
            </span>
            <div className="w-9 h-9 rounded-xl bg-[#FAF7F2] border border-[#E5DACD] flex items-center justify-center text-[#B45309] group-hover:scale-105 transition-transform">
              <Package className="w-5 h-5" />
            </div>
          </div>
          <p className="text-2xl sm:text-3xl font-bold text-[#2C1810] tabular-nums">
            {stats.totalProducts}
          </p>
          <p className="text-[11px] text-[#8B7363] mt-1 flex items-center justify-between">
            <span>ক্যাটালগে সক্রিয় পণ্যসমূহ</span>
            <ArrowRight className="w-3 h-3 text-[#B45309]" />
          </p>
        </div>

        {/* Total Categories */}
        <div
          onClick={() => onNavigateTab('categories')}
          className="bg-white p-4 sm:p-5 rounded-2xl border border-[#E5DACD] shadow-xs cursor-pointer hover:border-[#B45309] transition-all group"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-[#7A695C] uppercase tracking-wider">
              মোট ক্যাটাগরি
            </span>
            <div className="w-9 h-9 rounded-xl bg-[#FAF7F2] border border-[#E5DACD] flex items-center justify-center text-[#B45309] group-hover:scale-105 transition-transform">
              <Layers className="w-5 h-5" />
            </div>
          </div>
          <p className="text-2xl sm:text-3xl font-bold text-[#2C1810] tabular-nums">
            {stats.totalCategories}
          </p>
          <p className="text-[11px] text-[#8B7363] mt-1 flex items-center justify-between">
            <span>খাট, সোফা, ডাইনিং ইত্যাদি</span>
            <ArrowRight className="w-3 h-3 text-[#B45309]" />
          </p>
        </div>

        {/* Advertisements */}
        <div
          onClick={() => onNavigateTab('advertisements')}
          className="bg-white p-4 sm:p-5 rounded-2xl border border-[#E5DACD] shadow-xs cursor-pointer hover:border-[#B45309] transition-all group"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-[#7A695C] uppercase tracking-wider">
              সক্রিয় বিজ্ঞাপন
            </span>
            <div className="w-9 h-9 rounded-xl bg-[#FAF7F2] border border-[#E5DACD] flex items-center justify-center text-[#B45309] group-hover:scale-105 transition-transform">
              <Megaphone className="w-5 h-5" />
            </div>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-bold text-emerald-700 tabular-nums">
              {stats.activeAds}
            </span>
            <span className="text-xs text-[#7A695C]">/ {stats.activeAds + stats.inactiveAds} মোট</span>
          </div>
          <p className="text-[11px] text-[#8B7363] mt-1 flex items-center justify-between">
            <span>{stats.inactiveAds} টি ড্রাফট/নিষ্ক্রিয়</span>
            <ArrowRight className="w-3 h-3 text-[#B45309]" />
          </p>
        </div>

        {/* Customer Inquiries */}
        <div className="bg-white p-4 sm:p-5 rounded-2xl border border-[#E5DACD] shadow-xs">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-[#7A695C] uppercase tracking-wider">
              গ্রাহক ইনকোয়ারি
            </span>
            <div className="w-9 h-9 rounded-xl bg-[#FAF7F2] border border-[#E5DACD] flex items-center justify-center text-[#B45309]">
              <MessageCircle className="w-5 h-5" />
            </div>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-bold text-[#B45309] tabular-nums">
              {stats.unreadInquiries}
            </span>
            <span className="text-xs text-[#7A695C]">নতুন অপঠিত</span>
          </div>
          <p className="text-[11px] text-[#8B7363] mt-1">
            মোট বার্তা: {stats.totalInquiries} টি
          </p>
        </div>
      </div>

      {/* Two Column Section: Recent Products & Inquiries */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 sm:gap-8">
        {/* Recent Products (7 Cols) */}
        <div className="lg:col-span-7 bg-white rounded-2xl p-5 sm:p-6 border border-[#E5DACD] shadow-xs">
          <div className="flex items-center justify-between pb-3 border-b border-[#F0EAE1] mb-4">
            <h3 className="text-base font-bold text-[#2C1810]">সম্প্রতি যুক্ত পণ্যসমূহ</h3>
            <button
              onClick={() => onNavigateTab('products')}
              className="text-xs font-bold text-[#B45309] hover:underline"
            >
              সকল পণ্য দেখুন →
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-[#F0EAE1] text-[#7A695C]">
                  <th className="pb-2 font-semibold">ছবি ও নাম</th>
                  <th className="pb-2 font-semibold">ক্যাটাগরি</th>
                  <th className="pb-2 font-semibold">মূল্য</th>
                  <th className="pb-2 font-semibold">স্ট্যাটাস</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#F5EFE6]">
                {stats.recentProducts.map(p => (
                  <tr key={p.id} className="hover:bg-[#FAF7F2] transition-colors">
                    <td className="py-2.5 flex items-center gap-2.5">
                      <img
                        src={p.main_image}
                        alt={p.name_bn}
                        className="w-10 h-8 rounded object-cover bg-[#F0EAE1]"
                        referrerPolicy="no-referrer"
                      />
                      <span className="font-bold text-[#2C1810] line-clamp-1">{p.name_bn}</span>
                    </td>
                    <td className="py-2.5 text-[#6B5A4E] uppercase">{p.category_slug}</td>
                    <td className="py-2.5 font-bold text-[#8B4513] tabular-nums">
                      ৳{(p.discount_price || p.price).toLocaleString()}
                    </td>
                    <td className="py-2.5">
                      {p.in_stock ? (
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                          ইন স্টক
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-50 text-amber-800 border border-amber-200">
                          অর্ডারে তৈরি
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Customer Inquiries (5 Cols) */}
        <div className="lg:col-span-5 bg-white rounded-2xl p-5 sm:p-6 border border-[#E5DACD] shadow-xs">
          <div className="flex items-center justify-between pb-3 border-b border-[#F0EAE1] mb-4">
            <h3 className="text-base font-bold text-[#2C1810]">সাম্প্রতিক গ্রাহক ইনকোয়ারি</h3>
            <span className="text-xs text-[#7A695C]">{stats.recentInquiries.length} টি বার্তা</span>
          </div>

          {stats.recentInquiries.length === 0 ? (
            <div className="py-12 text-center text-xs text-[#7A695C]">
              কোনো সাম্প্রতিক ইনকোয়ারি নেই।
            </div>
          ) : (
            <div className="space-y-3">
              {stats.recentInquiries.map(inq => (
                <div
                  key={inq.id}
                  className={`p-3 rounded-xl border transition-colors ${
                    inq.status === 'unread'
                      ? 'bg-amber-50/50 border-amber-200'
                      : 'bg-[#FAF7F2] border-[#E8DFD3]'
                  }`}
                >
                  <div className="flex items-center justify-between text-xs mb-1">
                    <span className="font-bold text-[#2C1810]">{inq.customer_name}</span>
                    <span className="text-[10px] text-[#8B7363]">
                      {new Date(inq.created_at || Date.now()).toLocaleDateString('bn-BD')}
                    </span>
                  </div>

                  <a
                    href={`tel:${inq.phone}`}
                    className="inline-flex items-center gap-1 text-xs font-semibold text-[#8B4513] hover:underline mb-1"
                  >
                    <Phone className="w-3 h-3 text-[#B45309]" />
                    <span>{inq.phone}</span>
                  </a>

                  {inq.product_name && (
                    <p className="text-[11px] font-semibold text-[#4A3224]">
                      পণ্য: <span className="text-[#B45309]">{inq.product_name}</span>
                    </p>
                  )}

                  {inq.message && (
                    <p className="text-xs text-[#5A483C] mt-1 line-clamp-2 leading-relaxed">
                      "{inq.message}"
                    </p>
                  )}

                  <div className="mt-2 pt-2 border-t border-[#E5DACD] flex items-center justify-between text-[11px]">
                    <span className="text-[#7A695C]">
                      স্ট্যাটাস: {inq.status === 'read' ? 'পড়া হয়েছে' : inq.status === 'contacted' ? 'কথা হয়েছে' : 'নতুন'}
                    </span>
                    {inq.status !== 'contacted' && (
                      <button
                        onClick={() => handleInquiryStatus(inq.id!, 'contacted')}
                        className="px-2 py-0.5 rounded bg-white border border-[#D5C2B1] text-[#2C1810] hover:bg-[#EFE7DE]"
                      >
                        যোগাযোগ সম্পন্ন চিহ্নিত করুন
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
