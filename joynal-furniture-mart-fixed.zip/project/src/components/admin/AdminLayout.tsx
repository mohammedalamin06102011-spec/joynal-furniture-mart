import { useState } from 'react';
import { AdminUser } from '../../types.ts';
import {
  Armchair,
  LayoutDashboard,
  Layers,
  Package,
  Megaphone,
  Home,
  Image as ImageIcon,
  Settings,
  ExternalLink,
  LogOut,
  Menu,
  X,
  UserCheck
} from 'lucide-react';

interface AdminLayoutProps {
  user: AdminUser;
  activeTab: string;
  onNavigateTab: (tab: string) => void;
  onLogout: () => void;
  onViewWebsite: () => void;
  children: React.ReactNode;
}

export default function AdminLayout({
  user,
  activeTab,
  onNavigateTab,
  onLogout,
  onViewWebsite,
  children
}: AdminLayoutProps) {
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);

  const navItems = [
    { id: 'dashboard', label: 'ড্যাশবোর্ড', icon: LayoutDashboard },
    { id: 'categories', label: 'ক্যাটাগরি ম্যানেজমেন্ট', icon: Layers },
    { id: 'products', label: 'পণ্য ম্যানেজমেন্ট', icon: Package },
    { id: 'advertisements', label: 'বিজ্ঞাপন ম্যানেজমেন্ট', icon: Megaphone },
    { id: 'homepage', label: 'হোমপেজ এডিটর', icon: Home },
    { id: 'media', label: 'মিডিয়া লাইব্রেরি', icon: ImageIcon },
    { id: 'settings', label: 'ওয়েবসাইট সেটিংস', icon: Settings }
  ];

  const handleSelectTab = (tabId: string) => {
    onNavigateTab(tabId);
    setMobileSidebarOpen(false);
  };

  return (
    <div className="min-h-screen bg-[#F5EFE6] text-[#2C1810] flex">
      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex lg:flex-col w-64 bg-[#20120B] text-[#D8C9BB] border-r border-[#362013] shrink-0">
        {/* Brand Block */}
        <div className="p-5 border-b border-[#362013] flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#B45309] to-[#78350F] flex items-center justify-center text-amber-100 shadow-md">
            <Armchair className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-white tracking-tight line-clamp-1">
              জয়নাল ফার্নিচার মার্ট
            </h2>
            <span className="text-[10px] uppercase tracking-wider text-amber-400 font-bold">
              অ্যাডমিন পোর্টাল
            </span>
          </div>
        </div>

        {/* Navigation Links */}
        <nav className="p-3 space-y-1 flex-1 overflow-y-auto">
          {navItems.map(item => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleSelectTab(item.id)}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all ${
                  isActive
                    ? 'bg-[#B45309] text-white shadow-sm'
                    : 'text-[#C4B2A2] hover:bg-[#2C1910] hover:text-white'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-amber-400/80'}`} />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        {/* User Badge & Bottom Actions */}
        <div className="p-4 border-t border-[#362013] bg-[#1A0E08]/60 space-y-3">
          <div className="flex items-center gap-2.5 text-xs">
            <div className="w-8 h-8 rounded-full bg-[#3B2215] flex items-center justify-center text-amber-400 border border-[#4F2F1E]">
              <UserCheck className="w-4 h-4" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-bold text-white text-xs truncate">{user.username}</p>
              <p className="text-[10px] text-[#9E8574] truncate">{user.email}</p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2 pt-2 border-t border-[#362013]">
            <button
              onClick={onViewWebsite}
              className="flex items-center justify-center gap-1.5 py-2 px-2 text-[11px] font-semibold rounded-lg bg-[#2D1B11] text-[#E0D5C7] hover:bg-[#3D2517] hover:text-white transition-colors"
              title="পাবলিক ওয়েবসাইট দেখুন"
            >
              <ExternalLink className="w-3.5 h-3.5 text-amber-400" />
              <span>ওয়েবসাইট</span>
            </button>

            <button
              onClick={onLogout}
              className="flex items-center justify-center gap-1.5 py-2 px-2 text-[11px] font-semibold rounded-lg bg-red-950/60 border border-red-900/50 text-red-200 hover:bg-red-900/80 transition-colors"
              title="লগআউট"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>লগআউট</span>
            </button>
          </div>
        </div>
      </aside>

      {/* Mobile Drawer Overlay */}
      {mobileSidebarOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div
            className="fixed inset-0 bg-black/70 backdrop-blur-xs"
            onClick={() => setMobileSidebarOpen(false)}
          />
          <div className="relative w-72 max-w-[80vw] bg-[#20120B] text-[#D8C9BB] flex flex-col h-full shadow-2xl z-10">
            <div className="p-4 border-b border-[#362013] flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-[#B45309] flex items-center justify-center text-white">
                  <Armchair className="w-4 h-4" />
                </div>
                <span className="text-xs font-bold text-white">অ্যাডমিন পোর্টাল</span>
              </div>
              <button
                onClick={() => setMobileSidebarOpen(false)}
                className="p-1 rounded-lg text-[#9E8574] hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <nav className="p-3 space-y-1 flex-1 overflow-y-auto">
              {navItems.map(item => {
                const Icon = item.icon;
                const isActive = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => handleSelectTab(item.id)}
                    className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all ${
                      isActive
                        ? 'bg-[#B45309] text-white'
                        : 'text-[#C4B2A2] hover:bg-[#2C1910]'
                    }`}
                  >
                    <Icon className="w-4 h-4 text-amber-400" />
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </nav>

            <div className="p-4 border-t border-[#362013] space-y-2">
              <button
                onClick={onViewWebsite}
                className="w-full flex items-center justify-center gap-2 py-2 px-3 text-xs font-semibold rounded-lg bg-[#2D1B11] text-white"
              >
                <ExternalLink className="w-4 h-4 text-amber-400" />
                <span>পাবলিক ওয়েবসাইটে যান</span>
              </button>
              <button
                onClick={onLogout}
                className="w-full flex items-center justify-center gap-2 py-2 px-3 text-xs font-semibold rounded-lg bg-red-950 text-red-200"
              >
                <LogOut className="w-4 h-4" />
                <span>লগআউট করুন</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Top Header Bar */}
        <header className="h-16 bg-white border-b border-[#E5DACD] flex items-center justify-between px-4 sm:px-6 lg:px-8 shrink-0">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setMobileSidebarOpen(true)}
              className="lg:hidden p-2 rounded-lg text-[#4A3224] hover:bg-[#F5EFE6]"
              aria-label="মেনু খুলুন"
            >
              <Menu className="w-5 h-5" />
            </button>
            <h1 className="text-base sm:text-lg font-bold text-[#2C1810]">
              {navItems.find(i => i.id === activeTab)?.label || 'অ্যাডমিন ড্যাশবোর্ড'}
            </h1>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={onViewWebsite}
              className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg bg-[#FAF7F2] border border-[#D5C2B1] text-[#2C1810] hover:bg-[#EFE7DE] transition-colors"
            >
              <ExternalLink className="w-3.5 h-3.5 text-[#B45309]" />
              <span>ওয়েবসাইট দেখুন</span>
            </button>

            <div className="flex items-center gap-2 pl-3 border-l border-[#E5DACD]">
              <div className="w-7 h-7 rounded-full bg-[#B45309] text-white flex items-center justify-center text-xs font-bold">
                {user.username.charAt(0).toUpperCase()}
              </div>
              <span className="text-xs font-bold text-[#2C1810] hidden md:inline">
                {user.username}
              </span>
            </div>
          </div>
        </header>

        {/* Main Tab Content */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8">
          {children}
        </main>
      </div>
    </div>
  );
}
