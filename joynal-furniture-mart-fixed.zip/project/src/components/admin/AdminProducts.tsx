import { useState, useEffect } from 'react';
import { Product, Category, MediaItem } from '../../types.ts';
import {
  adminGetProducts,
  adminGetCategories,
  adminCreateProduct,
  adminUpdateProduct,
  adminDeleteProduct,
  adminGetMedia,
  adminUploadMedia
} from '../../services/api.ts';
import {
  Plus,
  Edit2,
  Trash2,
  Search,
  CheckCircle2,
  Clock,
  Star,
  Sparkles,
  X,
  Upload,
  RefreshCw,
  Image as ImageIcon
} from 'lucide-react';

export default function AdminProducts() {
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [mediaList, setMediaList] = useState<MediaItem[]>([]);
  const [loading, setLoading] = useState(true);

  // Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCatFilter, setSelectedCatFilter] = useState('all');
  const [stockFilter, setStockFilter] = useState('all');

  // Modal State
  const [modalOpen, setModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);

  // Form Fields
  const [nameBn, setNameBn] = useState('');
  const [nameEn, setNameEn] = useState('');
  const [categorySlug, setCategorySlug] = useState('');
  const [price, setPrice] = useState<number | ''>('');
  const [discountPrice, setDiscountPrice] = useState<number | ''>('');
  const [shortDescBn, setShortDescBn] = useState('');
  const [fullDescBn, setFullDescBn] = useState('');
  const [mainImage, setMainImage] = useState('');
  const [additionalImages, setAdditionalImages] = useState<string[]>([]);
  const [dimensions, setDimensions] = useState('');
  const [materials, setMaterials] = useState('');
  const [colorsText, setColorsText] = useState('');
  const [inStock, setInStock] = useState(true);
  const [isPopular, setIsPopular] = useState(false);
  const [isFeatured, setIsFeatured] = useState(false);
  const [saving, setSaving] = useState(false);

  // Media Picker in Form
  const [showMediaPicker, setShowMediaPicker] = useState(false);

  // Delete Prompt
  const [productToDelete, setProductToDelete] = useState<Product | null>(null);
  const [deleting, setDeleting] = useState(false);
  const [successMsg, setSuccessMsg] = useState('');

  const loadData = async () => {
    try {
      setLoading(true);
      const [prods, cats, media] = await Promise.all([
        adminGetProducts({
          category: selectedCatFilter !== 'all' ? selectedCatFilter : undefined,
          search: searchQuery.trim() || undefined,
          stock: stockFilter !== 'all' ? stockFilter : undefined
        }),
        adminGetCategories(),
        adminGetMedia()
      ]);
      setProducts(prods);
      setCategories(cats);
      setMediaList(media);
    } catch (err: any) {
      console.error('Failed to load products:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [selectedCatFilter, stockFilter]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    loadData();
  };

  const openAddModal = () => {
    setEditingProduct(null);
    setNameBn('');
    setNameEn('');
    setCategorySlug(categories[0]?.slug || 'bed');
    setPrice('');
    setDiscountPrice('');
    setShortDescBn('');
    setFullDescBn('');
    setMainImage(mediaList[0]?.url || '/images/category_bed_teak_1793102993462.jpg');
    setAdditionalImages([]);
    setDimensions('৬ ফুট × ৭ ফুট');
    setMaterials('১০০% অরিজিনাল চিটাগাং সেগুন কাঠ');
    setColorsText('ন্যাচারাল সেগুন বার্নিশ, অ্যান্টিক ব্রাউন');
    setInStock(true);
    setIsPopular(false);
    setIsFeatured(false);
    setModalOpen(true);
  };

  const openEditModal = (p: Product) => {
    setEditingProduct(p);
    setNameBn(p.name_bn);
    setNameEn(p.name_en || '');
    setCategorySlug(p.category_slug);
    setPrice(p.price);
    setDiscountPrice(p.discount_price || '');
    setShortDescBn(p.short_desc_bn || '');
    setFullDescBn(p.full_desc_bn || '');
    setMainImage(p.main_image);
    setAdditionalImages(p.additional_images || []);
    setDimensions(p.dimensions || '');
    setMaterials(p.materials || '');
    setColorsText((p.colors || []).join(', '));
    setInStock(p.in_stock);
    setIsPopular(p.is_popular);
    setIsFeatured(p.is_featured);
    setModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!nameBn.trim() || !categorySlug || !price) {
      alert('পণ্যের নাম, ক্যাটাগরি এবং মূল্য পূরণ করা বাধ্যতামূলক।');
      return;
    }

    try {
      setSaving(true);
      const colorsArray = colorsText
        .split(',')
        .map(c => c.trim())
        .filter(Boolean);

      const payload = {
        name_bn: nameBn.trim(),
        name_en: nameEn.trim(),
        category_slug: categorySlug,
        price: Number(price),
        discount_price: discountPrice ? Number(discountPrice) : undefined,
        short_desc_bn: shortDescBn.trim(),
        full_desc_bn: fullDescBn.trim(),
        main_image: mainImage,
        additional_images: additionalImages,
        dimensions: dimensions.trim(),
        materials: materials.trim(),
        colors: colorsArray,
        in_stock: inStock,
        is_popular: isPopular,
        is_featured: isFeatured
      };

      if (editingProduct) {
        await adminUpdateProduct(editingProduct.id, payload);
        setSuccessMsg('পণ্য সফলভাবে আপডেট করা হয়েছে।');
      } else {
        await adminCreateProduct(payload);
        setSuccessMsg('নতুন পণ্য সফলভাবে যুক্ত করা হয়েছে।');
      }

      setModalOpen(false);
      loadData();
      setTimeout(() => setSuccessMsg(''), 3000);
    } catch (err: any) {
      alert(err.message || 'সংরক্ষণ ব্যর্থ হয়েছে।');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!productToDelete) return;
    try {
      setDeleting(true);
      await adminDeleteProduct(productToDelete.id);
      setProductToDelete(null);
      setSuccessMsg('পণ্যটি সফলভাবে মুছে ফেলা হয়েছে।');
      loadData();
      setTimeout(() => setSuccessMsg(''), 3000);
    } catch (err: any) {
      alert(err.message || 'ডিলিট করতে ব্যর্থ হয়েছে।');
    } finally {
      setDeleting(false);
    }
  };

  const handleToggleStock = async (product: Product) => {
    try {
      await adminUpdateProduct(product.id, { in_stock: !product.in_stock });
      loadData();
    } catch (err) {}
  };

  const handleTogglePopular = async (product: Product) => {
    try {
      await adminUpdateProduct(product.id, { is_popular: !product.is_popular });
      loadData();
    } catch (err) {}
  };

  const handleToggleFeatured = async (product: Product) => {
    try {
      await adminUpdateProduct(product.id, { is_featured: !product.is_featured });
      loadData();
    } catch (err) {}
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>, isExtra = false) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async () => {
      try {
        const base64 = reader.result as string;
        const uploaded = await adminUploadMedia(file.name, base64, file.type);
        setMediaList(prev => [uploaded, ...prev]);
        if (isExtra) {
          setAdditionalImages(prev => [...prev, uploaded.url]);
        } else {
          setMainImage(uploaded.url);
        }
      } catch (err: any) {
        alert(err.message || 'ছবি আপলোড করতে ব্যর্থ হয়েছে।');
      }
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-[#E5DACD] gap-3">
        <div>
          <h2 className="text-xl font-bold text-[#2C1810]">পণ্য কালেকশন ম্যানেজমেন্ট</h2>
          <p className="text-xs text-[#7A695C]">
            ওয়েবসাইটের সকল ফার্নিচার পণ্য যোগ, সম্পাদন, মূল্য নির্ধারণ ও ছবি আপলোড করুন।
          </p>
        </div>

        <button
          onClick={openAddModal}
          className="flex items-center gap-1.5 px-4 py-2.5 text-xs font-bold rounded-xl bg-[#B45309] text-white hover:bg-[#92400E] shadow-sm transition-all"
        >
          <Plus className="w-4 h-4" />
          <span>নতুন ফার্নিচার পণ্য যোগ করুন</span>
        </button>
      </div>

      {successMsg && (
        <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-semibold animate-fadeIn">
          {successMsg}
        </div>
      )}

      {/* Filter Toolbar */}
      <div className="bg-white p-4 rounded-2xl border border-[#E5DACD] shadow-xs flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
        {/* Search */}
        <form onSubmit={handleSearch} className="flex-1 max-w-md relative">
          <Search className="w-4 h-4 text-[#8B7363] absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="নাম বা কাঠের বিবরণ দিয়ে খুঁজুন..."
            className="w-full pl-9 pr-3 py-2 text-xs bg-[#FAF7F2] border border-[#D8CEBF] rounded-xl text-[#2C1810] focus:outline-none focus:border-[#B45309]"
          />
        </form>

        <div className="flex items-center gap-2">
          {/* Category Filter */}
          <select
            value={selectedCatFilter}
            onChange={e => setSelectedCatFilter(e.target.value)}
            className="px-3 py-2 text-xs bg-[#FAF7F2] border border-[#D8CEBF] rounded-xl text-[#2C1810] focus:border-[#B45309]"
          >
            <option value="all">সকল ক্যাটাগরি</option>
            {categories.map(c => (
              <option key={c.id} value={c.slug}>
                {c.name_bn}
              </option>
            ))}
          </select>

          {/* Stock Filter */}
          <select
            value={stockFilter}
            onChange={e => setStockFilter(e.target.value)}
            className="px-3 py-2 text-xs bg-[#FAF7F2] border border-[#D8CEBF] rounded-xl text-[#2C1810] focus:border-[#B45309]"
          >
            <option value="all">সকল প্রাপ্যতা</option>
            <option value="in_stock">ইন স্টক (In Stock)</option>
            <option value="out_of_stock">অর্ডারে তৈরি (Made to Order)</option>
          </select>

          <button
            onClick={loadData}
            className="p-2 rounded-xl bg-[#FAF7F2] border border-[#D8CEBF] text-[#7A695C] hover:bg-[#EFE7DE]"
            title="রিফ্রেশ"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Products Table */}
      {loading ? (
        <div className="py-20 text-center text-xs font-semibold text-[#8B4513]">
          পণ্যসমূহ লোড হচ্ছে...
        </div>
      ) : products.length === 0 ? (
        <div className="bg-white rounded-2xl border border-[#E5DACD] p-12 text-center">
          <p className="text-sm font-bold text-[#2C1810]">কোনো পণ্য পাওয়া যায়নি</p>
          <p className="text-xs text-[#7A695C] mt-1">ফিল্টার পরিবর্তন করুন অথবা নতুন পণ্য যুক্ত করুন।</p>
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-[#E5DACD] shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#FAF7F2] border-b border-[#E5DACD] text-[#7A695C]">
                <tr>
                  <th className="py-3 px-4 font-bold">ছবি</th>
                  <th className="py-3 px-4 font-bold">পণ্যের নাম ও কোড</th>
                  <th className="py-3 px-4 font-bold">ক্যাটাগরি</th>
                  <th className="py-3 px-4 font-bold">মূল্য</th>
                  <th className="py-3 px-4 font-bold">স্ট্যাটাস</th>
                  <th className="py-3 px-4 font-bold text-center">হাইলাইটস</th>
                  <th className="py-3 px-4 font-bold text-right">অ্যাকশন</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#F5EFE6]">
                {products.map(p => (
                  <tr key={p.id} className="hover:bg-[#FAF7F2] transition-colors">
                    <td className="py-3 px-4">
                      <img
                        src={p.main_image}
                        alt={p.name_bn}
                        className="w-14 h-11 rounded-lg object-cover bg-[#F0EAE1] border border-[#E5DACD]"
                        referrerPolicy="no-referrer"
                      />
                    </td>
                    <td className="py-3 px-4">
                      <p className="font-bold text-[#2C1810] text-sm line-clamp-1">{p.name_bn}</p>
                      <p className="text-[11px] text-[#8B7363] uppercase">{p.name_en || '-'}</p>
                      <p className="text-[10px] text-[#A68F80] font-mono mt-0.5">{p.id}</p>
                    </td>
                    <td className="py-3 px-4">
                      <span className="px-2 py-0.5 rounded-md bg-[#FAF7F2] border border-[#E5DACD] text-[#8B4513] font-semibold uppercase">
                        {p.category_slug}
                      </span>
                    </td>
                    <td className="py-3 px-4 tabular-nums">
                      <div className="font-bold text-sm text-[#8B4513]">
                        ৳{(p.discount_price || p.price).toLocaleString()}
                      </div>
                      {p.discount_price && (
                        <div className="text-[11px] text-[#9CA3AF] line-through">
                          ৳{p.price.toLocaleString()}
                        </div>
                      )}
                    </td>
                    <td className="py-3 px-4">
                      <button
                        onClick={() => handleToggleStock(p)}
                        className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-bold cursor-pointer transition-colors ${
                          p.in_stock
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200 hover:bg-emerald-100'
                            : 'bg-amber-50 text-amber-800 border border-amber-200 hover:bg-amber-100'
                        }`}
                        title="ক্লিক করে প্রাপ্যতা পরিবর্তন করুন"
                      >
                        {p.in_stock ? <CheckCircle2 className="w-3 h-3 text-emerald-600" /> : <Clock className="w-3 h-3 text-amber-600" />}
                        <span>{p.in_stock ? 'ইন স্টক' : 'অর্ডারে তৈরি'}</span>
                      </button>
                    </td>
                    <td className="py-3 px-4 text-center">
                      <div className="inline-flex items-center gap-1.5">
                        <button
                          onClick={() => handleTogglePopular(p)}
                          className={`p-1.5 rounded-lg border transition-colors ${
                            p.is_popular
                              ? 'bg-amber-100 border-amber-300 text-amber-800'
                              : 'bg-white border-[#E5DACD] text-[#9E8574] hover:bg-[#FAF7F2]'
                          }`}
                          title={p.is_popular ? 'জনপ্রিয় হিসেবে চিহ্নিত' : 'জনপ্রিয় করতে ক্লিক করুন'}
                        >
                          <Star className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleToggleFeatured(p)}
                          className={`p-1.5 rounded-lg border transition-colors ${
                            p.is_featured
                              ? 'bg-purple-100 border-purple-300 text-purple-800'
                              : 'bg-white border-[#E5DACD] text-[#9E8574] hover:bg-[#FAF7F2]'
                          }`}
                          title={p.is_featured ? 'ফিচার্ড হিসেবে চিহ্নিত' : 'ফিচার্ড করতে ক্লিক করুন'}
                        >
                          <Sparkles className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                    <td className="py-3 px-4 text-right space-x-2">
                      <button
                        onClick={() => openEditModal(p)}
                        className="p-1.5 rounded-lg bg-[#FAF7F2] border border-[#D5C2B1] text-[#2C1810] hover:bg-[#EFE7DE] transition-colors"
                        title="সম্পাদনা করুন"
                      >
                        <Edit2 className="w-3.5 h-3.5 text-[#8B4513]" />
                      </button>
                      <button
                        onClick={() => setProductToDelete(p)}
                        className="p-1.5 rounded-lg bg-red-50 border border-red-200 text-red-600 hover:bg-red-100 transition-colors"
                        title="মুছে ফেলুন"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Add / Edit Product Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="w-full max-w-2xl bg-white rounded-2xl border border-[#E5DACD] shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
            <div className="p-4 sm:p-5 border-b border-[#F0EAE1] bg-[#FAF7F2] flex items-center justify-between">
              <h3 className="text-base font-bold text-[#2C1810]">
                {editingProduct ? 'ফার্নিচার পণ্য সম্পাদনা' : 'নতুন ফার্নিচার পণ্য যুক্ত করুন'}
              </h3>
              <button onClick={() => setModalOpen(false)} className="p-1 text-[#8B7363] hover:text-[#2C1810]">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSave} className="p-5 sm:p-6 space-y-4 overflow-y-auto">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-[#2C1810] mb-1">
                    পণ্যের নাম (বাংলা) *
                  </label>
                  <input
                    type="text"
                    required
                    value={nameBn}
                    onChange={e => setNameBn(e.target.value)}
                    placeholder="যেমন: রয়্যাল সেগুন কিং খাট"
                    className="w-full px-3 py-2 text-xs bg-[#FAF7F2] border border-[#D8CEBF] rounded-lg text-[#2C1810] focus:border-[#B45309]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#2C1810] mb-1">
                    ইংরেজি নাম (ঐচ্ছিক)
                  </label>
                  <input
                    type="text"
                    value={nameEn}
                    onChange={e => setNameEn(e.target.value)}
                    placeholder="যেমন: Royal Teak King Bed"
                    className="w-full px-3 py-2 text-xs bg-[#FAF7F2] border border-[#D8CEBF] rounded-lg text-[#2C1810]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-bold text-[#2C1810] mb-1">
                    ক্যাটাগরি *
                  </label>
                  <select
                    value={categorySlug}
                    onChange={e => setCategorySlug(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-[#FAF7F2] border border-[#D8CEBF] rounded-lg text-[#2C1810]"
                  >
                    {categories.map(c => (
                      <option key={c.id} value={c.slug}>
                        {c.name_bn} ({c.name_en || c.slug})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#2C1810] mb-1">
                    মূল্য (টাকা ৳) *
                  </label>
                  <input
                    type="number"
                    required
                    value={price}
                    onChange={e => setPrice(Number(e.target.value))}
                    placeholder="যেমন: 65000"
                    className="w-full px-3 py-2 text-xs bg-[#FAF7F2] border border-[#D8CEBF] rounded-lg text-[#2C1810]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#2C1810] mb-1">
                    ছাড় মূল্য (ঐচ্ছিক)
                  </label>
                  <input
                    type="number"
                    value={discountPrice}
                    onChange={e => setDiscountPrice(e.target.value ? Number(e.target.value) : '')}
                    placeholder="যেমন: 60000"
                    className="w-full px-3 py-2 text-xs bg-[#FAF7F2] border border-[#D8CEBF] rounded-lg text-[#2C1810]"
                  />
                </div>
              </div>

              {/* Main Image */}
              <div>
                <label className="block text-xs font-bold text-[#2C1810] mb-1">
                  প্রধান ছবি (Main Image) *
                </label>
                <div className="flex gap-2 mb-2">
                  <input
                    type="text"
                    required
                    value={mainImage}
                    onChange={e => setMainImage(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-[#FAF7F2] border border-[#D8CEBF] rounded-lg text-[#2C1810]"
                  />
                  <label className="px-3 py-2 text-xs font-bold rounded-lg bg-[#FAF7F2] border border-[#D8CEBF] text-[#2C1810] hover:bg-[#EFE7DE] cursor-pointer shrink-0 flex items-center gap-1">
                    <Upload className="w-3.5 h-3.5 text-[#B45309]" />
                    <span>আপলোড</span>
                    <input type="file" accept="image/*" onChange={e => handleFileUpload(e, false)} className="hidden" />
                  </label>
                </div>

                {mainImage && (
                  <div className="w-24 h-16 rounded-lg overflow-hidden border border-[#E5DACD] bg-[#FAF7F2] mb-2">
                    <img src={mainImage} alt="প্রধান ছবি" className="w-full h-full object-cover" />
                  </div>
                )}
              </div>

              {/* Additional Images */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-bold text-[#2C1810]">
                    অতিরিক্ত ছবি (গ্যালারির জন্য)
                  </label>
                  <label className="text-[11px] font-bold text-[#B45309] hover:underline cursor-pointer flex items-center gap-1">
                    <Upload className="w-3 h-3" />
                    <span>আরো ছবি যোগ করুন</span>
                    <input type="file" accept="image/*" onChange={e => handleFileUpload(e, true)} className="hidden" />
                  </label>
                </div>

                {additionalImages.length > 0 && (
                  <div className="flex flex-wrap gap-2 p-2 bg-[#FAF7F2] rounded-lg border border-[#E5DACD]">
                    {additionalImages.map((img, idx) => (
                      <div key={idx} className="relative w-16 h-12 rounded border border-[#D8CEBF] overflow-hidden group">
                        <img src={img} alt="গ্যালারি" className="w-full h-full object-cover" />
                        <button
                          type="button"
                          onClick={() => setAdditionalImages(prev => prev.filter((_, i) => i !== idx))}
                          className="absolute inset-0 bg-red-900/80 text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Specs */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-bold text-[#2C1810] mb-1">
                    পরিমাপ (Dimensions)
                  </label>
                  <input
                    type="text"
                    value={dimensions}
                    onChange={e => setDimensions(e.target.value)}
                    placeholder="৬ ফুট × ৭ ফুট"
                    className="w-full px-3 py-2 text-xs bg-[#FAF7F2] border border-[#D8CEBF] rounded-lg text-[#2C1810]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#2C1810] mb-1">
                    কাঠ ও মেটেরিয়ালস
                  </label>
                  <input
                    type="text"
                    value={materials}
                    onChange={e => setMaterials(e.target.value)}
                    placeholder="চিটাগাং সেগুন কাঠ"
                    className="w-full px-3 py-2 text-xs bg-[#FAF7F2] border border-[#D8CEBF] rounded-lg text-[#2C1810]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#2C1810] mb-1">
                    কালার অপশন (কমা দিয়ে লিখুন)
                  </label>
                  <input
                    type="text"
                    value={colorsText}
                    onChange={e => setColorsText(e.target.value)}
                    placeholder="ন্যাচারাল কাঠ, অ্যান্টিক ব্রাউন"
                    className="w-full px-3 py-2 text-xs bg-[#FAF7F2] border border-[#D8CEBF] rounded-lg text-[#2C1810]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-[#2C1810] mb-1">
                  সংক্ষিপ্ত বর্ণনা
                </label>
                <input
                  type="text"
                  value={shortDescBn}
                  onChange={e => setShortDescBn(e.target.value)}
                  placeholder="যেমন: ১০০% খাটি চিটাগাং সেগুন কাঠে হাতে খোদাই করা রাজকীয় খাট।"
                  className="w-full px-3 py-2 text-xs bg-[#FAF7F2] border border-[#D8CEBF] rounded-lg text-[#2C1810]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#2C1810] mb-1">
                  বিস্তারিত বিবরণ
                </label>
                <textarea
                  rows={4}
                  value={fullDescBn}
                  onChange={e => setFullDescBn(e.target.value)}
                  placeholder="কাঠের সিজনিং, পলিশিং, হেডবোর্ড কারুকাজ ইত্যাদির পূর্ণ বিবরণ..."
                  className="w-full px-3 py-2 text-xs bg-[#FAF7F2] border border-[#D8CEBF] rounded-lg text-[#2C1810] resize-none"
                />
              </div>

              {/* Toggles */}
              <div className="grid grid-cols-3 gap-3 pt-3 border-t border-[#F0EAE1]">
                <label className="flex items-center gap-2 cursor-pointer text-xs font-bold text-[#2C1810]">
                  <input
                    type="checkbox"
                    checked={inStock}
                    onChange={e => setInStock(e.target.checked)}
                    className="w-4 h-4 text-[#B45309] rounded"
                  />
                  <span>ইন স্টক (In Stock)</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer text-xs font-bold text-[#2C1810]">
                  <input
                    type="checkbox"
                    checked={isPopular}
                    onChange={e => setIsPopular(e.target.checked)}
                    className="w-4 h-4 text-[#B45309] rounded"
                  />
                  <span>জনপ্রিয় পণ্য (Popular)</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer text-xs font-bold text-[#2C1810]">
                  <input
                    type="checkbox"
                    checked={isFeatured}
                    onChange={e => setIsFeatured(e.target.checked)}
                    className="w-4 h-4 text-[#B45309] rounded"
                  />
                  <span>সেরা কালেকশন (Featured)</span>
                </label>
              </div>

              <div className="flex items-center justify-end gap-2 pt-4 border-t border-[#F0EAE1]">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2 text-xs text-[#7A695C] hover:text-[#2C1810]"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  disabled={saving}
                  className="px-5 py-2 text-xs font-bold rounded-lg bg-[#B45309] text-white hover:bg-[#92400E] shadow-sm disabled:opacity-50"
                >
                  {saving ? 'সংরক্ষণ হচ্ছে...' : editingProduct ? 'আপডেট করুন' : 'পণ্য যোগ করুন'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {productToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="w-full max-w-md bg-white rounded-2xl border border-red-200 p-6 shadow-2xl text-center">
            <h3 className="text-base font-bold text-[#2C1810] mb-2">
              আপনি কি নিশ্চিতভাবে এই পণ্যটি মুছে ফেলতে চান?
            </h3>
            <p className="text-xs text-[#7A695C] mb-4">
              "{productToDelete.name_bn}" পণ্যটি ওয়েবসাইট এবং ক্যাটালগ থেকে সম্পূর্ণ অপসারণ করা হবে।
            </p>
            <div className="flex items-center justify-center gap-3">
              <button
                onClick={() => setProductToDelete(null)}
                className="px-4 py-2 text-xs font-semibold text-[#7A695C] hover:bg-[#FAF7F2] rounded-lg"
              >
                বাতিল
              </button>
              <button
                onClick={handleDelete}
                disabled={deleting}
                className="px-5 py-2 text-xs font-bold rounded-lg bg-red-600 text-white hover:bg-red-700 shadow-xs"
              >
                {deleting ? 'মুছে ফেলা হচ্ছে...' : 'হ্যাঁ, মুছে ফেলুন'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
