import { useState, useEffect } from 'react';
import { MediaItem } from '../../types.ts';
import { adminGetMedia, adminUploadMedia, adminDeleteMedia } from '../../services/api.ts';
import {
  Upload,
  Image as ImageIcon,
  Copy,
  Check,
  Trash2,
  AlertTriangle,
  RefreshCw,
  HardDrive
} from 'lucide-react';

export default function AdminMedia() {
  const [mediaList, setMediaList] = useState<MediaItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  // Delete Prompt
  const [mediaToDelete, setMediaToDelete] = useState<MediaItem | null>(null);
  const [deleting, setDeleting] = useState(false);

  const loadMedia = async () => {
    try {
      setLoading(true);
      setErrorMessage('');
      const data = await adminGetMedia();
      setMediaList(data);
    } catch (err: any) {
      setErrorMessage(err.message || 'মিডিয়া ফাইল লোড করতে ব্যর্থ হয়েছে');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadMedia();
  }, []);

  const handleUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    Array.from(files).forEach(file => {
      // Validate type
      const allowed = ['image/jpeg', 'image/png', 'image/webp', 'image/jpg'];
      if (!allowed.includes(file.type)) {
        alert(`${file.name}: শুধুমাত্র JPG, PNG, বা WebP ছবি গ্রহণযোগ্য।`);
        return;
      }
      // Validate size 5MB
      if (file.size > 5 * 1024 * 1024) {
        alert(`${file.name}: ফাইলের আকার ৫ মেগাবাইটের কম হতে হবে।`);
        return;
      }

      const reader = new FileReader();
      reader.onload = async () => {
        try {
          setUploading(true);
          const base64 = reader.result as string;
          const uploaded = await adminUploadMedia(file.name, base64, file.type);
          setMediaList(prev => [uploaded, ...prev]);
          setSuccessMsg(`"${file.name}" সফলভাবে আপলোড হয়েছে।`);
          setTimeout(() => setSuccessMsg(''), 3000);
        } catch (err: any) {
          alert(err.message || 'ছবি আপলোড করতে ব্যর্থ হয়েছে।');
        } finally {
          setUploading(false);
        }
      };
      reader.readAsDataURL(file);
    });
  };

  const handleCopyUrl = (url: string, id: string) => {
    const fullUrl = url.startsWith('http') ? url : window.location.origin + url;
    navigator.clipboard.writeText(url);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleDelete = async () => {
    if (!mediaToDelete) return;
    try {
      setDeleting(true);
      await adminDeleteMedia(mediaToDelete.id);
      setMediaToDelete(null);
      setSuccessMsg('ছবিটি সফলভাবে মুছে ফেলা হয়েছে।');
      loadMedia();
      setTimeout(() => setSuccessMsg(''), 3000);
    } catch (err: any) {
      alert(err.message || 'ছবি ডিলিট করতে ব্যর্থ হয়েছে।');
      setMediaToDelete(null);
    } finally {
      setDeleting(false);
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-[#E5DACD] gap-3">
        <div>
          <h2 className="text-xl font-bold text-[#2C1810]">মিডিয়া লাইব্রেরি (Media Management)</h2>
          <p className="text-xs text-[#7A695C]">
            ক্যাটাগরি, ফার্নিচার পণ্য ও বিজ্ঞাপনে ব্যবহারের জন্য স্থায়ী স্টোরেজে ছবি আপলোড ও ম্যানেজ করুন।
          </p>
        </div>

        <div className="flex items-center gap-2">
          <label className="flex items-center gap-1.5 px-4 py-2.5 text-xs font-bold rounded-xl bg-[#B45309] text-white hover:bg-[#92400E] shadow-sm transition-all cursor-pointer">
            <Upload className="w-4 h-4" />
            <span>{uploading ? 'আপলোড হচ্ছে...' : 'নতুন ছবি আপলোড'}</span>
            <input
              type="file"
              multiple
              accept="image/jpeg,image/png,image/webp"
              onChange={handleUpload}
              className="hidden"
              disabled={uploading}
            />
          </label>
          <button
            onClick={loadMedia}
            className="p-2.5 rounded-xl bg-white border border-[#D5C2B1] text-[#7A695C] hover:bg-[#FAF7F2]"
            title="রিফ্রেশ করুন"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {successMsg && (
        <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-semibold animate-fadeIn">
          {successMsg}
        </div>
      )}

      {errorMessage && (
        <div className="p-3.5 rounded-xl bg-red-50 border border-red-200 text-red-800 text-xs font-semibold">
          {errorMessage}
        </div>
      )}

      {/* Drag & Drop Upload Dropzone */}
      <div className="border-2 border-dashed border-[#D8CEBF] rounded-2xl p-6 sm:p-8 text-center bg-white/70 hover:bg-white hover:border-[#B45309] transition-all">
        <div className="w-12 h-12 rounded-2xl bg-[#FAF7F2] border border-[#E5DACD] flex items-center justify-center text-[#B45309] mx-auto mb-3">
          <Upload className="w-6 h-6" />
        </div>
        <h3 className="text-sm font-bold text-[#2C1810]">ছবি ড্রপ করুন অথবা নির্বাচন করুন</h3>
        <p className="text-xs text-[#7A695C] mt-1 max-w-md mx-auto">
          JPG, JPEG, PNG, এবং WebP ফরম্যাট সমর্থিত। প্রতিটি ছবির আকার সর্বোচ্চ ৫ মেগাবাইট (5MB)।
        </p>

        <label className="mt-4 inline-flex items-center gap-2 px-4 py-2 text-xs font-bold rounded-xl bg-[#FAF7F2] border border-[#D5C2B1] text-[#2C1810] hover:bg-[#EFE7DE] cursor-pointer">
          <span>কম্পিউটার/ডিভাইস থেকে ফাইল বাছুন</span>
          <input
            type="file"
            multiple
            accept="image/jpeg,image/png,image/webp"
            onChange={handleUpload}
            className="hidden"
            disabled={uploading}
          />
        </label>
      </div>

      {/* Media Grid */}
      {loading ? (
        <div className="py-20 text-center text-xs font-semibold text-[#8B4513]">
          মিডিয়া ফাইল লোড হচ্ছে...
        </div>
      ) : mediaList.length === 0 ? (
        <div className="bg-white rounded-2xl border border-[#E5DACD] p-12 text-center">
          <ImageIcon className="w-12 h-12 text-[#BCAAA4] mx-auto mb-3" />
          <p className="text-sm font-bold text-[#2C1810]">মিডিয়া লাইব্রেরি খালি</p>
          <p className="text-xs text-[#7A695C] mt-1">উপরে ক্লিক করে ছবি আপলোড করুন।</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
          {mediaList.map(item => (
            <div
              key={item.id}
              className="bg-white rounded-xl border border-[#E5DACD] overflow-hidden shadow-xs hover:shadow-md transition-all flex flex-col justify-between group"
            >
              {/* Image Preview */}
              <div className="relative aspect-[4/3] bg-[#FAF7F2] overflow-hidden">
                <img
                  src={item.url}
                  alt={item.original_name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  referrerPolicy="no-referrer"
                />
              </div>

              {/* Details & Actions */}
              <div className="p-3">
                <p className="font-bold text-xs text-[#2C1810] line-clamp-1" title={item.original_name}>
                  {item.original_name || item.filename}
                </p>
                <div className="flex items-center justify-between text-[10px] text-[#8B7363] mt-1">
                  <span>{formatFileSize(item.file_size)}</span>
                  <span>{new Date(item.uploaded_at).toLocaleDateString('bn-BD')}</span>
                </div>

                <div className="mt-3 pt-2 border-t border-[#F0EAE1] flex items-center justify-between gap-1">
                  <button
                    onClick={() => handleCopyUrl(item.url, item.id)}
                    className="flex-1 flex items-center justify-center gap-1 py-1.5 px-2 rounded-lg bg-[#FAF7F2] border border-[#D5C2B1] text-[11px] font-semibold text-[#2C1810] hover:bg-[#EFE7DE] transition-colors"
                  >
                    {copiedId === item.id ? (
                      <>
                        <Check className="w-3 h-3 text-emerald-600" />
                        <span className="text-emerald-700">কপি হয়েছে</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3 h-3 text-[#8B4513]" />
                        <span>URL কপি</span>
                      </>
                    )}
                  </button>

                  <button
                    onClick={() => setMediaToDelete(item)}
                    className="p-1.5 rounded-lg bg-red-50 text-red-600 border border-red-200 hover:bg-red-100 transition-colors"
                    title="ছবি মুছে ফেলুন"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {mediaToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="w-full max-w-md bg-white rounded-2xl border border-red-200 p-6 shadow-2xl text-center">
            <div className="w-12 h-12 rounded-full bg-red-100 flex items-center justify-center text-red-600 mx-auto mb-3">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-[#2C1810] mb-2">
              আপনি কি এই ছবিটি মুছে ফেলতে চান?
            </h3>
            <p className="text-xs text-[#7A695C] mb-4">
              ফাইল: <span className="font-bold text-[#2C1810]">{mediaToDelete.original_name}</span>
            </p>
            <p className="text-[11px] text-[#A68F80] mb-4">
              ছবিটি যদি কোনো পণ্য, ক্যাটাগরি বা বিজ্ঞাপনে ব্যবহৃত থাকে তবে সিস্টেম স্বয়ংক্রিয়ভাবে মুছে ফেলা বন্ধ রাখবে।
            </p>
            <div className="flex items-center justify-center gap-3">
              <button
                onClick={() => setMediaToDelete(null)}
                className="px-4 py-2 text-xs font-semibold text-[#7A695C] hover:bg-[#FAF7F2] rounded-lg"
              >
                বাতিল
              </button>
              <button
                onClick={handleDelete}
                disabled={deleting}
                className="px-5 py-2 text-xs font-bold rounded-lg bg-red-600 text-white hover:bg-red-700 shadow-xs"
              >
                {deleting ? 'মুছে ফেলা হচ্ছে...' : 'হ্যাঁ, মুছুন'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
