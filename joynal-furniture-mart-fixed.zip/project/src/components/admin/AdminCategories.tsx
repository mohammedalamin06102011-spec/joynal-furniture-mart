import { useState, useEffect } from 'react';
import { Category, MediaItem } from '../../types.ts';
import {
  adminGetCategories,
  adminCreateCategory,
  adminUpdateCategory,
  adminDeleteCategory,
  adminGetMedia,
  adminUploadMedia
} from '../../services/api.ts';
import {
  Plus,
  Edit2,
  Trash2,
  Check,
  X,
  Layers,
  Upload,
  AlertTriangle,
  RefreshCw
} from 'lucide-react';

export default function AdminCategories() {
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [successMsg, setSuccessMsg] = useState('');

  // Modal State
  const [modalOpen, setModalOpen] = useState(false);
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);

  // Form Fields
  const [nameBn, setNameBn] = useState('');
  const [nameEn, setNameEn] = useState('');
  const [slug, setSlug] = useState('');
  const [descriptionBn, setDescriptionBn] = useState('');
  const [coverImage, setCoverImage] = useState('');
  const [isActive, setIsActive] = useState(true);
  const [displayOrder, setDisplayOrder] = useState<number>(1);
  const [saving, setSaving] = useState(false);

  // Delete Safeguard Modal
  const [deleteModalOpen, setDeleteModalOpen] = useState(false);
  const [categoryToDelete, setCategoryToDelete] = useState<Category | null>(null);
  const [deleteSafeguardData, setDeleteSafeguardData] = useState<{ hasProducts: boolean; productCount: number } | null>(null);
  const [deleting, setDeleting] = useState(false);

  // Media Selector
  const [mediaList, setMediaList] = useState<MediaItem[]>([]);
  const [showMediaPicker, setShowMediaPicker] = useState(false);

  const loadCategories = async () => {
    try {
      setLoading(true);
      const data = await adminGetCategories();
      setCategories(data);
    } catch (err: any) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadCategories();
    adminGetMedia().then(setMediaList).catch(() => {});
  }, []);

  const openAddModal = () => {
    setEditingCategory(null);
    setNameBn('');
    setNameEn('');
    setSlug('');
    setDescriptionBn('');
    setCoverImage(mediaList[0]?.url || '/images/hero_furniture_cover_1793102992976.jpg');
    setIsActive(true);
    setDisplayOrder(categories.length + 1);
    setModalOpen(true);
  };

  const openEditModal = (cat: Category) => {
    setEditingCategory(cat);
    setNameBn(cat.name_bn);
    setNameEn(cat.name_en || '');
    setSlug(cat.slug);
    setDescriptionBn(cat.description_bn || '');
    setCoverImage(cat.cover_image);
    setIsActive(cat.is_active);
    setDisplayOrder(cat.display_order);
    setModalOpen(true);
  };

  const handleNameChange = (val: string) => {
    setNameBn(val);
    if (!editingCategory && !slug) {
      const autoSlug = val
        .replace(/খাট/g, 'bed')
        .replace(/সোফা/g, 'sofa')
        .replace(/আলমারি/g, 'almirah')
        .replace(/ডাইনিং/g, 'dining-table')
        .replace(/ড্রেসিং/g, 'dressing-table')
        .replace(/শোকেস/g, 'showcase')
        .replace(/অন্যান্য/g, 'other')
        .toLowerCase()
        .replace(/[^a-z0-9]/g, '-')
        .replace(/-+/g, '-');
      if (autoSlug && autoSlug !== '-') setSlug(autoSlug);
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!nameBn.trim() || !slug.trim()) {
      alert('ক্যাটাগরির বাংলা নাম এবং স্লাগ অবশ্যই পূরণ করতে হবে।');
      return;
    }

    try {
      setSaving(true);
      if (editingCategory) {
        await adminUpdateCategory(editingCategory.id, {
          name_bn: nameBn.trim(),
          name_en: nameEn.trim(),
          slug: slug.trim(),
          description_bn: descriptionBn.trim(),
          cover_image: coverImage,
          is_active: isActive,
          display_order: Number(displayOrder)
        });
        setSuccessMsg('ক্যাটাগরি সফলভাবে আপডেট করা হয়েছে।');
      } else {
        await adminCreateCategory({
          name_bn: nameBn.trim(),
          name_en: nameEn.trim(),
          slug: slug.trim(),
          description_bn: descriptionBn.trim(),
          cover_image: coverImage,
          is_active: isActive,
          display_order: Number(displayOrder)
        });
        setSuccessMsg('নতুন ক্যাটাগরি সফলভাবে তৈরি করা হয়েছে।');
      }

      setModalOpen(false);
      loadCategories();
      setTimeout(() => setSuccessMsg(''), 3000);
    } catch (err: any) {
      alert(err.message || 'ক্যাটাগরি সংরক্ষণে ত্রুটি হয়েছে।');
    } finally {
      setSaving(false);
    }
  };

  const promptDelete = (cat: Category) => {
    setCategoryToDelete(cat);
    setDeleteSafeguardData(null);
    setDeleteModalOpen(true);
  };

  const confirmDelete = async (force = false) => {
    if (!categoryToDelete) return;
    try {
      setDeleting(true);
      await adminDeleteCategory(categoryToDelete.id, force);
      setDeleteModalOpen(false);
      setCategoryToDelete(null);
      setDeleteSafeguardData(null);
      setSuccessMsg('ক্যাটাগরি সফলভাবে মুছে ফেলা হয়েছে।');
      loadCategories();
      setTimeout(() => setSuccessMsg(''), 3000);
    } catch (err: any) {
      if (err.hasProducts) {
        setDeleteSafeguardData({
          hasProducts: true,
          productCount: err.productCount
        });
      } else {
        alert(err.message || 'ডিলিট করতে ব্যর্থ হয়েছে।');
      }
    } finally {
      setDeleting(false);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async () => {
      try {
        const base64 = reader.result as string;
        const uploaded = await adminUploadMedia(file.name, base64, file.type);
        setCoverImage(uploaded.url);
        setMediaList(prev => [uploaded, ...prev]);
      } catch (err: any) {
        alert(err.message || 'ছবি আপলোড করতে ব্যর্থ হয়েছে।');
      }
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="space-y-6">
      {/* Action Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-[#E5DACD] gap-3">
        <div>
          <h2 className="text-xl font-bold text-[#2C1810]">ফার্নিচার ক্যাটাগরি ম্যানেজমেন্ট</h2>
          <p className="text-xs text-[#7A695C]">
            পাবলিক ওয়েবসাইটে প্রদর্শিত সকল ক্যাটাগরি তৈরি, সম্পাদনা ও প্রকাশনা নিয়ন্ত্রণ করুন।
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={openAddModal}
            className="flex items-center gap-1.5 px-4 py-2.5 text-xs font-bold rounded-xl bg-[#B45309] text-white hover:bg-[#92400E] shadow-sm transition-all"
          >
            <Plus className="w-4 h-4" />
            <span>নতুন ক্যাটাগরি যুক্ত করুন</span>
          </button>
          <button
            onClick={loadCategories}
            className="p-2.5 rounded-xl bg-white border border-[#D5C2B1] text-[#7A695C] hover:bg-[#FAF7F2]"
            title="রিফ্রেশ করুন"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {successMsg && (
        <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-semibold animate-fadeIn">
          {successMsg}
        </div>
      )}

      {loading ? (
        <div className="py-20 text-center text-xs font-semibold text-[#8B4513]">
          ক্যাটাগরি ডাটা লোড হচ্ছে...
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-[#E5DACD] shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#FAF7F2] border-b border-[#E5DACD] text-[#7A695C]">
                <tr>
                  <th className="py-3 px-4 font-bold">ক্রম</th>
                  <th className="py-3 px-4 font-bold">কভার ছবি</th>
                  <th className="py-3 px-4 font-bold">নাম (বাংলা ও ইংরেজি)</th>
                  <th className="py-3 px-4 font-bold">স্লাগ</th>
                  <th className="py-3 px-4 font-bold">মোট পণ্য</th>
                  <th className="py-3 px-4 font-bold">অবস্থা</th>
                  <th className="py-3 px-4 font-bold text-right">অ্যাকশন</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#F5EFE6]">
                {categories.map((cat, idx) => (
                  <tr key={cat.id} className="hover:bg-[#FAF7F2] transition-colors">
                    <td className="py-3 px-4 font-bold text-[#8B4513] tabular-nums">
                      {cat.display_order || idx + 1}
                    </td>
                    <td className="py-3 px-4">
                      <img
                        src={cat.cover_image}
                        alt={cat.name_bn}
                        className="w-14 h-10 rounded-lg object-cover bg-[#F0EAE1] border border-[#E5DACD]"
                        referrerPolicy="no-referrer"
                      />
                    </td>
                    <td className="py-3 px-4">
                      <p className="font-bold text-[#2C1810] text-sm">{cat.name_bn}</p>
                      <p className="text-[11px] text-[#8B7363] uppercase">{cat.name_en || '-'}</p>
                    </td>
                    <td className="py-3 px-4 font-mono text-[#6B5A4E]">
                      /category/{cat.slug}
                    </td>
                    <td className="py-3 px-4 font-bold text-[#2C1810] tabular-nums">
                      {cat.product_count || 0} টি
                    </td>
                    <td className="py-3 px-4">
                      {cat.is_active ? (
                        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                          <Check className="w-3 h-3 text-emerald-600" />
                          প্রকাশিত
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-gray-100 text-gray-600 border border-gray-200">
                          <X className="w-3 h-3" />
                          অপ্রকাশিত
                        </span>
                      )}
                    </td>
                    <td className="py-3 px-4 text-right space-x-2">
                      <button
                        onClick={() => openEditModal(cat)}
                        className="p-1.5 rounded-lg bg-[#FAF7F2] border border-[#D5C2B1] text-[#2C1810] hover:bg-[#EFE7DE] transition-colors"
                        title="সম্পাদনা করুন"
                      >
                        <Edit2 className="w-3.5 h-3.5 text-[#8B4513]" />
                      </button>
                      <button
                        onClick={() => promptDelete(cat)}
                        className="p-1.5 rounded-lg bg-red-50 border border-red-200 text-red-600 hover:bg-red-100 transition-colors"
                        title="মুছে ফেলুন"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Add / Edit Category Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="w-full max-w-lg bg-white rounded-2xl border border-[#E5DACD] shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
            <div className="p-4 sm:p-5 border-b border-[#F0EAE1] bg-[#FAF7F2] flex items-center justify-between">
              <h3 className="text-base font-bold text-[#2C1810]">
                {editingCategory ? 'ক্যাটাগরি সম্পাদনা করুন' : 'নতুন ক্যাটাগরি তৈরি করুন'}
              </h3>
              <button onClick={() => setModalOpen(false)} className="p-1 text-[#8B7363] hover:text-[#2C1810]">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSave} className="p-5 sm:p-6 space-y-4 overflow-y-auto">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-[#2C1810] mb-1">
                    ক্যাটাগরি নাম (বাংলা) *
                  </label>
                  <input
                    type="text"
                    required
                    value={nameBn}
                    onChange={e => handleNameChange(e.target.value)}
                    placeholder="যেমন: খাট"
                    className="w-full px-3 py-2 text-xs bg-[#FAF7F2] border border-[#D8CEBF] rounded-lg text-[#2C1810] focus:border-[#B45309]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#2C1810] mb-1">
                    ইংরেজি নাম (ঐচ্ছিক)
                  </label>
                  <input
                    type="text"
                    value={nameEn}
                    onChange={e => setNameEn(e.target.value)}
                    placeholder="যেমন: Bed"
                    className="w-full px-3 py-2 text-xs bg-[#FAF7F2] border border-[#D8CEBF] rounded-lg text-[#2C1810]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-[#2C1810] mb-1">
                  স্লাগ (URL Slug) *
                </label>
                <input
                  type="text"
                  required
                  value={slug}
                  onChange={e => setSlug(e.target.value.toLowerCase().replace(/[^a-z0-9_-]/g, '-'))}
                  placeholder="যেমন: bed"
                  className="w-full px-3 py-2 text-xs font-mono bg-[#FAF7F2] border border-[#D8CEBF] rounded-lg text-[#2C1810]"
                />
                <span className="text-[10px] text-[#8B7363]">ইউআরএল হবে: /category/{slug || 'example'}</span>
              </div>

              <div>
                <label className="block text-xs font-bold text-[#2C1810] mb-1">
                  কভার ইমেজ URL *
                </label>
                <div className="flex gap-2 mb-2">
                  <input
                    type="text"
                    required
                    value={coverImage}
                    onChange={e => setCoverImage(e.target.value)}
                    placeholder="/images/... অথবা /uploads/..."
                    className="w-full px-3 py-2 text-xs bg-[#FAF7F2] border border-[#D8CEBF] rounded-lg text-[#2C1810]"
                  />
                  <label className="px-3 py-2 text-xs font-bold rounded-lg bg-[#FAF7F2] border border-[#D8CEBF] text-[#2C1810] hover:bg-[#EFE7DE] cursor-pointer shrink-0 flex items-center gap-1">
                    <Upload className="w-3.5 h-3.5 text-[#B45309]" />
                    <span>আপলোড</span>
                    <input type="file" accept="image/*" onChange={handleFileUpload} className="hidden" />
                  </label>
                  <button
                    type="button"
                    onClick={() => setShowMediaPicker(!showMediaPicker)}
                    className="px-3 py-2 text-xs font-bold rounded-lg bg-[#FAF7F2] border border-[#D8CEBF] text-[#2C1810] hover:bg-[#EFE7DE] shrink-0"
                  >
                    গ্যালারি
                  </button>
                </div>

                {coverImage && (
                  <div className="relative w-full h-28 rounded-lg overflow-hidden border border-[#E5DACD] bg-[#FAF7F2] mb-2">
                    <img src={coverImage} alt="প্রিভিউ" className="w-full h-full object-cover" />
                  </div>
                )}

                {showMediaPicker && (
                  <div className="p-3 bg-[#FAF7F2] rounded-lg border border-[#E5DACD] mb-2">
                    <p className="text-[11px] font-bold text-[#2C1810] mb-2">মিডিয়া লাইব্রেরি থেকে ছবি পছন্দ করুন:</p>
                    <div className="grid grid-cols-4 gap-2 max-h-36 overflow-y-auto">
                      {mediaList.map(m => (
                        <img
                          key={m.id}
                          src={m.url}
                          alt={m.filename}
                          onClick={() => {
                            setCoverImage(m.url);
                            setShowMediaPicker(false);
                          }}
                          className="h-16 w-full object-cover rounded border border-[#D8CEBF] cursor-pointer hover:border-[#B45309]"
                        />
                      ))}
                    </div>
                  </div>
                )}
              </div>

              <div>
                <label className="block text-xs font-bold text-[#2C1810] mb-1">
                  সংক্ষিপ্ত বিবরণ
                </label>
                <textarea
                  rows={2}
                  value={descriptionBn}
                  onChange={e => setDescriptionBn(e.target.value)}
                  placeholder="এই ক্যাটাগরির আসবাবপত্রের বিশেষত্ব লিখুন..."
                  className="w-full px-3 py-2 text-xs bg-[#FAF7F2] border border-[#D8CEBF] rounded-lg text-[#2C1810] resize-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3 pt-2 border-t border-[#F0EAE1]">
                <div>
                  <label className="block text-xs font-bold text-[#2C1810] mb-1">
                    ডিসপ্লে ক্রম
                  </label>
                  <input
                    type="number"
                    min={1}
                    value={displayOrder}
                    onChange={e => setDisplayOrder(Number(e.target.value))}
                    className="w-full px-3 py-2 text-xs bg-[#FAF7F2] border border-[#D8CEBF] rounded-lg text-[#2C1810]"
                  />
                </div>

                <div className="flex items-center gap-2 pt-5">
                  <input
                    type="checkbox"
                    id="isActiveToggle"
                    checked={isActive}
                    onChange={e => setIsActive(e.target.checked)}
                    className="w-4 h-4 text-[#B45309] rounded"
                  />
                  <label htmlFor="isActiveToggle" className="text-xs font-bold text-[#2C1810] cursor-pointer">
                    ক্যাটাগরি সক্রিয় / প্রদর্শিত
                  </label>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-4 border-t border-[#F0EAE1]">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2 text-xs text-[#7A695C] hover:text-[#2C1810]"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  disabled={saving}
                  className="px-5 py-2 text-xs font-bold rounded-lg bg-[#B45309] text-white hover:bg-[#92400E] shadow-sm disabled:opacity-50"
                >
                  {saving ? 'সংরক্ষণ হচ্ছে...' : editingCategory ? 'আপডেট করুন' : 'তৈরি করুন'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Safeguard Modal */}
      {deleteModalOpen && categoryToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="w-full max-w-md bg-white rounded-2xl border border-red-200 p-6 shadow-2xl">
            <div className="w-12 h-12 rounded-full bg-red-100 flex items-center justify-center text-red-600 mb-3 mx-auto">
              <AlertTriangle className="w-6 h-6" />
            </div>

            <h3 className="text-base font-bold text-center text-[#2C1810] mb-2">
              আপনি কি নিশ্চিতভাবে এই ক্যাটাগরি ডিলিট করতে চান?
            </h3>
            <p className="text-xs text-center text-[#7A695C] mb-4">
              ক্যাটাগরি: <span className="font-bold text-[#2C1810]">{categoryToDelete.name_bn}</span> (/category/{categoryToDelete.slug})
            </p>

            {deleteSafeguardData?.hasProducts ? (
              <div className="p-3 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-xs mb-4">
                <p className="font-bold mb-1">সতর্কবার্তা!</p>
                <p>
                  এই ক্যাটাগরিতে বর্তমানে <strong>{deleteSafeguardData.productCount}টি পণ্য</strong> যুক্ত রয়েছে।
                  আপনি যদি ক্যাটাগরি ডিলিট করতে চান, তবে ফোর্স ডিলিট চাপলে এর ভেতরের পণ্যগুলোও মুছে যাবে।
                </p>
                <div className="mt-3 flex justify-center gap-2">
                  <button
                    onClick={() => setDeleteModalOpen(false)}
                    className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-white border border-amber-300 text-[#2C1810]"
                  >
                    ফিরে যান
                  </button>
                  <button
                    onClick={() => confirmDelete(true)}
                    disabled={deleting}
                    className="px-3.5 py-1.5 text-xs font-bold rounded-lg bg-red-600 text-white hover:bg-red-700"
                  >
                    {deleting ? 'মুছে ফেলা হচ্ছে...' : 'সব পণ্য সহ ফোর্স ডিলিট করুন'}
                  </button>
                </div>
              </div>
            ) : (
              <div className="flex items-center justify-center gap-3">
                <button
                  onClick={() => setDeleteModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-[#7A695C] hover:bg-[#FAF7F2] rounded-lg"
                >
                  বাতিল
                </button>
                <button
                  onClick={() => confirmDelete(false)}
                  disabled={deleting}
                  className="px-5 py-2 text-xs font-bold rounded-lg bg-red-600 text-white hover:bg-red-700 shadow-xs"
                >
                  {deleting ? 'মুছে ফেলা হচ্ছে...' : 'হ্যাঁ, ডিলিট করুন'}
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
