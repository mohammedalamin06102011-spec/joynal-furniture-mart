import { useState, useEffect } from 'react';
import { Advertisement, MediaItem } from '../../types.ts';
import {
  adminGetAdvertisements,
  adminCreateAdvertisement,
  adminUpdateAdvertisement,
  adminDeleteAdvertisement,
  adminGetMedia,
  adminUploadMedia
} from '../../services/api.ts';
import {
  Plus,
  Edit2,
  Trash2,
  Megaphone,
  Check,
  X,
  Upload,
  Eye,
  MousePointerClick,
  Calendar,
  RefreshCw
} from 'lucide-react';

export default function AdminAdvertisements() {
  const [ads, setAds] = useState<Advertisement[]>([]);
  const [mediaList, setMediaList] = useState<MediaItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [successMsg, setSuccessMsg] = useState('');

  // Modal
  const [modalOpen, setModalOpen] = useState(false);
  const [editingAd, setEditingAd] = useState<Advertisement | null>(null);

  // Form
  const [title, setTitle] = useState('');
  const [placement, setPlacement] = useState<Advertisement['placement']>('homepage_top');
  const [imageUrl, setImageUrl] = useState('');
  const [destinationUrl, setDestinationUrl] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [isEnabled, setIsEnabled] = useState(true);
  const [rowInterval, setRowInterval] = useState(2);
  const [displayOrder, setDisplayOrder] = useState(1);
  const [thirdPartyCode, setThirdPartyCode] = useState('');
  const [saving, setSaving] = useState(false);

  // Delete Prompt
  const [adToDelete, setAdToDelete] = useState<Advertisement | null>(null);
  const [deleting, setDeleting] = useState(false);

  const placementLabels: Record<Advertisement['placement'], string> = {
    homepage_top: 'হোমপেজ: শীর্ষ ব্যানার (Top Banner)',
    homepage_between_sections: 'হোমপেজ: সেকশন মধ্যবর্তী (Between Sections)',
    homepage_below_featured: 'হোমপেজ: সেরা কালেকশনের নিচে (Below Featured)',
    homepage_above_footer: 'হোমপেজ: ফুটারের উপরে (Above Footer)',
    category_top: 'ক্যাটাগরি পেজ: পণ্য তালিকার শীর্ষে (Category Top)',
    category_grid: 'ক্যাটাগরি পেজ: গ্রিডের মাঝে রো বিরতি (Between Rows)',
    category_bottom: 'ক্যাটাগরি পেজ: তালিকার নিচে (Category Bottom)',
    product_below_info: 'প্রোডাক্ট ডিটেইলস: বিবরণের নিচে (Below Product Info)',
    product_below_related: 'প্রোডাক্ট ডিটেইলস: সম্পর্কিত পণ্যের নিচে (Below Related)'
  };

  const loadData = async () => {
    try {
      setLoading(true);
      const [adsData, mediaData] = await Promise.all([
        adminGetAdvertisements(),
        adminGetMedia()
      ]);
      setAds(adsData);
      setMediaList(mediaData);
    } catch (err: any) {
      console.error('Failed to load ads:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const openAddModal = () => {
    setEditingAd(null);
    setTitle('');
    setPlacement('homepage_top');
    setImageUrl(mediaList[0]?.url || '/images/ad_banner_discount_1793103050698.jpg');
    setDestinationUrl('/category/bed');
    setStartDate(new Date().toISOString().split('T')[0]);
    setEndDate('2027-12-31');
    setIsEnabled(true);
    setRowInterval(2);
    setDisplayOrder(ads.length + 1);
    setThirdPartyCode('');
    setModalOpen(true);
  };

  const openEditModal = (ad: Advertisement) => {
    setEditingAd(ad);
    setTitle(ad.title);
    setPlacement(ad.placement);
    setImageUrl(ad.image_url || '');
    setDestinationUrl(ad.destination_url || '');
    setStartDate(ad.start_date || '');
    setEndDate(ad.end_date || '');
    setIsEnabled(ad.is_enabled);
    setRowInterval(ad.row_interval || 2);
    setDisplayOrder(ad.display_order || 1);
    setThirdPartyCode(ad.third_party_code || '');
    setModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      alert('বিজ্ঞাপনের শিরোনাম আবশ্যক।');
      return;
    }

    try {
      setSaving(true);
      const payload: Partial<Advertisement> = {
        title: title.trim(),
        placement,
        image_url: imageUrl,
        destination_url: destinationUrl.trim(),
        start_date: startDate,
        end_date: endDate,
        is_enabled: isEnabled,
        row_interval: Number(rowInterval),
        display_order: Number(displayOrder),
        third_party_code: thirdPartyCode.trim() || undefined
      };

      if (editingAd) {
        await adminUpdateAdvertisement(editingAd.id, payload);
        setSuccessMsg('বিজ্ঞাপন সফলভাবে আপডেট করা হয়েছে।');
      } else {
        await adminCreateAdvertisement(payload);
        setSuccessMsg('নতুন বিজ্ঞাপন সফলভাবে তৈরি করা হয়েছে।');
      }

      setModalOpen(false);
      loadData();
      setTimeout(() => setSuccessMsg(''), 3000);
    } catch (err: any) {
      alert(err.message || 'সংরক্ষণ ব্যর্থ হয়েছে।');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!adToDelete) return;
    try {
      setDeleting(true);
      await adminDeleteAdvertisement(adToDelete.id);
      setAdToDelete(null);
      setSuccessMsg('বিজ্ঞাপন মুছে ফেলা হয়েছে।');
      loadData();
      setTimeout(() => setSuccessMsg(''), 3000);
    } catch (err: any) {
      alert(err.message || 'ডিলিট করতে ব্যর্থ হয়েছে।');
    } finally {
      setDeleting(false);
    }
  };

  const handleToggleEnabled = async (ad: Advertisement) => {
    try {
      await adminUpdateAdvertisement(ad.id, { is_enabled: !ad.is_enabled });
      loadData();
    } catch (err) {}
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async () => {
      try {
        const base64 = reader.result as string;
        const uploaded = await adminUploadMedia(file.name, base64, file.type);
        setImageUrl(uploaded.url);
        setMediaList(prev => [uploaded, ...prev]);
      } catch (err: any) {
        alert(err.message || 'ব্যানার আপলোড ব্যর্থ হয়েছে।');
      }
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="space-y-6">
      {/* Action Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-[#E5DACD] gap-3">
        <div>
          <h2 className="text-xl font-bold text-[#2C1810]">বিজ্ঞাপন ব্যানার ও স্পন্সরশিপ ম্যানেজমেন্ট</h2>
          <p className="text-xs text-[#7A695C]">
            হোমপেজ, ক্যাটাগরি গ্রিড এবং প্রোডাক্ট পেজের ব্যানার বিজ্ঞাপন ও রো বিরতি নিয়ন্ত্রণ করুন।
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={openAddModal}
            className="flex items-center gap-1.5 px-4 py-2.5 text-xs font-bold rounded-xl bg-[#B45309] text-white hover:bg-[#92400E] shadow-sm transition-all"
          >
            <Plus className="w-4 h-4" />
            <span>নতুন বিজ্ঞাপন যোগ করুন</span>
          </button>
          <button
            onClick={loadData}
            className="p-2.5 rounded-xl bg-white border border-[#D5C2B1] text-[#7A695C] hover:bg-[#FAF7F2]"
            title="রিফ্রেশ করুন"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {successMsg && (
        <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-semibold animate-fadeIn">
          {successMsg}
        </div>
      )}

      {/* Advertisements List */}
      {loading ? (
        <div className="py-20 text-center text-xs font-semibold text-[#8B4513]">
          বিজ্ঞাপন লোড হচ্ছে...
        </div>
      ) : ads.length === 0 ? (
        <div className="bg-white rounded-2xl border border-[#E5DACD] p-12 text-center">
          <Megaphone className="w-12 h-12 text-[#BCAAA4] mx-auto mb-3" />
          <p className="text-sm font-bold text-[#2C1810]">কোনো বিজ্ঞাপন তৈরি করা নেই</p>
          <p className="text-xs text-[#7A695C] mt-1">পণ্য বিক্রয় বাড়াতে নতুন অফার ব্যানার যোগ করুন।</p>
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-[#E5DACD] shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#FAF7F2] border-b border-[#E5DACD] text-[#7A695C]">
                <tr>
                  <th className="py-3 px-4 font-bold">ব্যানার প্রিভিউ</th>
                  <th className="py-3 px-4 font-bold">শিরোনাম ও গন্তব্য</th>
                  <th className="py-3 px-4 font-bold">প্লেসমেন্ট অবস্থান</th>
                  <th className="py-3 px-4 font-bold">মেয়াদকাল</th>
                  <th className="py-3 px-4 font-bold">পারফর্ম্যান্স</th>
                  <th className="py-3 px-4 font-bold">অবস্থা</th>
                  <th className="py-3 px-4 font-bold text-right">অ্যাকশন</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#F5EFE6]">
                {ads.map(ad => (
                  <tr key={ad.id} className="hover:bg-[#FAF7F2] transition-colors">
                    <td className="py-3 px-4">
                      {ad.image_url ? (
                        <img
                          src={ad.image_url}
                          alt={ad.title}
                          className="w-20 h-10 rounded-md object-cover bg-[#F0EAE1] border border-[#E5DACD]"
                          referrerPolicy="no-referrer"
                        />
                      ) : (
                        <div className="w-20 h-10 rounded-md bg-[#2C1810] text-amber-200 flex items-center justify-center text-[10px] font-bold">
                          টেক্সট ব্যানার
                        </div>
                      )}
                    </td>
                    <td className="py-3 px-4">
                      <p className="font-bold text-[#2C1810] text-sm line-clamp-1">{ad.title}</p>
                      <p className="text-[11px] text-[#8B7363] truncate max-w-xs">{ad.destination_url || 'কোনো লিংক নেই'}</p>
                    </td>
                    <td className="py-3 px-4">
                      <span className="px-2 py-0.5 rounded bg-[#FAF7F2] border border-[#E5DACD] text-[#8B4513] font-semibold text-[11px]">
                        {placementLabels[ad.placement] || ad.placement}
                      </span>
                      {ad.placement === 'category_grid' && (
                        <p className="text-[10px] text-[#7A695C] mt-0.5">
                          প্রতি {ad.row_interval || 2} রো পর পর
                        </p>
                      )}
                    </td>
                    <td className="py-3 px-4 text-[#6B5A4E]">
                      <div className="flex items-center gap-1 text-[11px]">
                        <Calendar className="w-3 h-3 text-[#A68F80]" />
                        <span>{ad.start_date || 'শুরু'}</span> থেকে <span>{ad.end_date || 'চলমান'}</span>
                      </div>
                    </td>
                    <td className="py-3 px-4 tabular-nums">
                      <div className="flex items-center gap-3 text-[11px]">
                        <span className="flex items-center gap-1 text-[#4A3224]" title="ইমপ্রেশন (দেখা হয়েছে)">
                          <Eye className="w-3 h-3 text-[#8B7363]" /> {ad.impressions || 0}
                        </span>
                        <span className="flex items-center gap-1 text-emerald-800 font-bold" title="ক্লিক">
                          <MousePointerClick className="w-3 h-3 text-emerald-600" /> {ad.clicks || 0}
                        </span>
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <button
                        onClick={() => handleToggleEnabled(ad)}
                        className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold cursor-pointer transition-colors ${
                          ad.is_enabled
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200 hover:bg-emerald-100'
                            : 'bg-gray-100 text-gray-600 border border-gray-200 hover:bg-gray-200'
                        }`}
                      >
                        {ad.is_enabled ? <Check className="w-3 h-3" /> : <X className="w-3 h-3" />}
                        <span>{ad.is_enabled ? 'সক্রিয়' : 'বন্ধ'}</span>
                      </button>
                    </td>
                    <td className="py-3 px-4 text-right space-x-2">
                      <button
                        onClick={() => openEditModal(ad)}
                        className="p-1.5 rounded-lg bg-[#FAF7F2] border border-[#D5C2B1] text-[#2C1810] hover:bg-[#EFE7DE]"
                        title="সম্পাদনা করুন"
                      >
                        <Edit2 className="w-3.5 h-3.5 text-[#8B4513]" />
                      </button>
                      <button
                        onClick={() => setAdToDelete(ad)}
                        className="p-1.5 rounded-lg bg-red-50 border border-red-200 text-red-600 hover:bg-red-100"
                        title="মুছে ফেলুন"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Add / Edit Advertisement Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="w-full max-w-lg bg-white rounded-2xl border border-[#E5DACD] shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
            <div className="p-4 sm:p-5 border-b border-[#F0EAE1] bg-[#FAF7F2] flex items-center justify-between">
              <h3 className="text-base font-bold text-[#2C1810]">
                {editingAd ? 'বিজ্ঞাপন সম্পাদনা করুন' : 'নতুন বিজ্ঞাপন তৈরি করুন'}
              </h3>
              <button onClick={() => setModalOpen(false)} className="p-1 text-[#8B7363] hover:text-[#2C1810]">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSave} className="p-5 sm:p-6 space-y-4 overflow-y-auto">
              <div>
                <label className="block text-xs font-bold text-[#2C1810] mb-1">
                  বিজ্ঞাপনের শিরোনাম *
                </label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={e => setTitle(e.target.value)}
                  placeholder="যেমন: ঈদ স্পেশাল ফার্নিচার মেলা - ২০% পর্যন্ত ছাড়"
                  className="w-full px-3 py-2 text-xs bg-[#FAF7F2] border border-[#D8CEBF] rounded-lg text-[#2C1810] focus:border-[#B45309]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#2C1810] mb-1">
                  প্লেসমেন্ট অবস্থান (Placement) *
                </label>
                <select
                  value={placement}
                  onChange={e => setPlacement(e.target.value as any)}
                  className="w-full px-3 py-2 text-xs bg-[#FAF7F2] border border-[#D8CEBF] rounded-lg text-[#2C1810]"
                >
                  {Object.entries(placementLabels).map(([key, label]) => (
                    <option key={key} value={key}>
                      {label}
                    </option>
                  ))}
                </select>
              </div>

              {/* Row Interval for Category Grid */}
              {placement === 'category_grid' && (
                <div className="p-3 bg-amber-50 rounded-xl border border-amber-200">
                  <label className="block text-xs font-bold text-amber-950 mb-1">
                    ক্যাটাগরি গ্রিডে রো বিরতি (Row Interval)
                  </label>
                  <select
                    value={rowInterval}
                    onChange={e => setRowInterval(Number(e.target.value))}
                    className="w-full px-3 py-2 text-xs bg-white border border-amber-300 rounded-lg text-[#2C1810]"
                  >
                    <option value={2}>প্রতি ২ রো পর পর (Every 2 rows)</option>
                    <option value={3}>প্রতি ৩ রো পর পর (Every 3 rows)</option>
                    <option value={4}>প্রতি ৪ রো পর পর (Every 4 rows)</option>
                  </select>
                  <p className="text-[10px] text-amber-800 mt-1">
                    ক্যাটাগরি পেজে পণ্যের নির্দিষ্ট সারি অতিক্রমের পর স্বয়ংক্রিয়ভাবে ব্যানারটি প্রদর্শিত হবে।
                  </p>
                </div>
              )}

              {/* Banner Image */}
              <div>
                <label className="block text-xs font-bold text-[#2C1810] mb-1">
                  ব্যানার ছবি URL
                </label>
                <div className="flex gap-2 mb-2">
                  <input
                    type="text"
                    value={imageUrl}
                    onChange={e => setImageUrl(e.target.value)}
                    placeholder="/images/... অথবা /uploads/..."
                    className="w-full px-3 py-2 text-xs bg-[#FAF7F2] border border-[#D8CEBF] rounded-lg text-[#2C1810]"
                  />
                  <label className="px-3 py-2 text-xs font-bold rounded-lg bg-[#FAF7F2] border border-[#D8CEBF] text-[#2C1810] hover:bg-[#EFE7DE] cursor-pointer shrink-0 flex items-center gap-1">
                    <Upload className="w-3.5 h-3.5 text-[#B45309]" />
                    <span>আপলোড</span>
                    <input type="file" accept="image/*" onChange={handleFileUpload} className="hidden" />
                  </label>
                </div>

                {imageUrl && (
                  <div className="w-full h-24 rounded-lg overflow-hidden border border-[#E5DACD] bg-[#FAF7F2] mb-2">
                    <img src={imageUrl} alt="ব্যানার" className="w-full h-full object-cover" />
                  </div>
                )}
              </div>

              <div>
                <label className="block text-xs font-bold text-[#2C1810] mb-1">
                  গন্তব্য URL (Destination URL)
                </label>
                <input
                  type="text"
                  value={destinationUrl}
                  onChange={e => setDestinationUrl(e.target.value)}
                  placeholder="যেমন: /category/bed অথবা https://facebook.com/..."
                  className="w-full px-3 py-2 text-xs bg-[#FAF7F2] border border-[#D8CEBF] rounded-lg text-[#2C1810]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-[#2C1810] mb-1">
                    শুরুর তারিখ
                  </label>
                  <input
                    type="date"
                    value={startDate}
                    onChange={e => setStartDate(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-[#FAF7F2] border border-[#D8CEBF] rounded-lg text-[#2C1810]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#2C1810] mb-1">
                    সমাপ্তির তারিখ
                  </label>
                  <input
                    type="date"
                    value={endDate}
                    onChange={e => setEndDate(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-[#FAF7F2] border border-[#D8CEBF] rounded-lg text-[#2C1810]"
                  />
                </div>
              </div>

              {/* Third party ad integration */}
              <div>
                <label className="block text-xs font-bold text-[#2C1810] mb-1">
                  তৃতীয় পক্ষ বিজ্ঞাপন স্ক্রিপ্ট / Adsterra কোড (ঐচ্ছিক)
                </label>
                <textarea
                  rows={2}
                  value={thirdPartyCode}
                  onChange={e => setThirdPartyCode(e.target.value)}
                  placeholder="সরাসরি বিজ্ঞাপন স্ক্রিপ্ট বা Ad Network ট্যাগ..."
                  className="w-full px-3 py-2 text-xs font-mono bg-[#FAF7F2] border border-[#D8CEBF] rounded-lg text-[#2C1810] resize-none"
                />
              </div>

              <div className="flex items-center gap-2 pt-2 border-t border-[#F0EAE1]">
                <input
                  type="checkbox"
                  id="adEnabled"
                  checked={isEnabled}
                  onChange={e => setIsEnabled(e.target.checked)}
                  className="w-4 h-4 text-[#B45309] rounded"
                />
                <label htmlFor="adEnabled" className="text-xs font-bold text-[#2C1810] cursor-pointer">
                  বিজ্ঞাপনটি সক্রিয় রাখুন
                </label>
              </div>

              <div className="flex items-center justify-end gap-2 pt-4 border-t border-[#F0EAE1]">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2 text-xs text-[#7A695C] hover:text-[#2C1810]"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  disabled={saving}
                  className="px-5 py-2 text-xs font-bold rounded-lg bg-[#B45309] text-white hover:bg-[#92400E] shadow-sm disabled:opacity-50"
                >
                  {saving ? 'সংরক্ষণ হচ্ছে...' : editingAd ? 'আপডেট করুন' : 'তৈরি করুন'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {adToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="w-full max-w-md bg-white rounded-2xl border border-red-200 p-6 shadow-2xl text-center">
            <h3 className="text-base font-bold text-[#2C1810] mb-2">
              আপনি কি নিশ্চিতভাবে এই বিজ্ঞাপনটি মুছে ফেলতে চান?
            </h3>
            <p className="text-xs text-[#7A695C] mb-4">
              "{adToDelete.title}" বিজ্ঞাপনটি ওয়েবসাইট থেকে অপসারণ করা হবে।
            </p>
            <div className="flex items-center justify-center gap-3">
              <button
                onClick={() => setAdToDelete(null)}
                className="px-4 py-2 text-xs font-semibold text-[#7A695C] hover:bg-[#FAF7F2] rounded-lg"
              >
                বাতিল
              </button>
              <button
                onClick={handleDelete}
                disabled={deleting}
                className="px-5 py-2 text-xs font-bold rounded-lg bg-red-600 text-white hover:bg-red-700 shadow-xs"
              >
                {deleting ? 'মুছে ফেলা হচ্ছে...' : 'হ্যাঁ, ডিলিট করুন'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
