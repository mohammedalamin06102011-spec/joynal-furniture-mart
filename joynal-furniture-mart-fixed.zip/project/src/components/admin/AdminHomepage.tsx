import { useState, useEffect } from 'react';
import { HomepageConfig, Product, MediaItem, HomepageSectionConfig } from '../../types.ts';
import {
  adminGetHomepageConfig,
  adminUpdateHomepageConfig,
  adminGetProducts,
  adminGetMedia,
  adminUploadMedia
} from '../../services/api.ts';
import {
  Save,
  Home,
  Upload,
  Layers,
  ArrowUp,
  ArrowDown,
  Check,
  X,
  Star,
  Sparkles,
  RefreshCw
} from 'lucide-react';

export default function AdminHomepage() {
  const [config, setConfig] = useState<HomepageConfig | null>(null);
  const [products, setProducts] = useState<Product[]>([]);
  const [mediaList, setMediaList] = useState<MediaItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [successMsg, setSuccessMsg] = useState('');

  // Form Fields
  const [heroTitle, setHeroTitle] = useState('');
  const [heroSubtitle, setHeroSubtitle] = useState('');
  const [heroImage, setHeroImage] = useState('');
  const [heroCtaText, setHeroCtaText] = useState('');
  const [heroCtaLink, setHeroCtaLink] = useState('');
  const [announcementText, setAnnouncementText] = useState('');
  const [sections, setSections] = useState<HomepageSectionConfig[]>([]);
  const [featuredProductIds, setFeaturedProductIds] = useState<string[]>([]);
  const [popularProductIds, setPopularProductIds] = useState<string[]>([]);

  const loadData = async () => {
    try {
      setLoading(true);
      const [cfg, prods, media] = await Promise.all([
        adminGetHomepageConfig(),
        adminGetProducts(),
        adminGetMedia()
      ]);
      setConfig(cfg);
      setProducts(prods);
      setMediaList(media);

      setHeroTitle(cfg.hero_title || '');
      setHeroSubtitle(cfg.hero_subtitle || '');
      setHeroImage(cfg.hero_image || '');
      setHeroCtaText(cfg.hero_cta_text || 'ফার্নিচার কালেকশন দেখুন');
      setHeroCtaLink(cfg.hero_cta_link || '#categories-section');
      setAnnouncementText(cfg.announcement_text || '');
      setSections(cfg.sections || []);
      setFeaturedProductIds(cfg.featured_product_ids || []);
      setPopularProductIds(cfg.popular_product_ids || []);
    } catch (err: any) {
      console.error('Failed to load homepage config:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      setSaving(true);
      await adminUpdateHomepageConfig({
        hero_title: heroTitle.trim(),
        hero_subtitle: heroSubtitle.trim(),
        hero_image: heroImage,
        hero_cta_text: heroCtaText.trim(),
        hero_cta_link: heroCtaLink.trim(),
        announcement_text: announcementText.trim(),
        sections,
        featured_product_ids: featuredProductIds,
        popular_product_ids: popularProductIds
      });
      setSuccessMsg('হোমপেজের সকল পরিবর্তন সফলভাবে সংরক্ষিত ও প্রকাশিত হয়েছে!');
      setTimeout(() => setSuccessMsg(''), 3000);
    } catch (err: any) {
      alert(err.message || 'হোমপেজ আপডেট ব্যর্থ হয়েছে।');
    } finally {
      setSaving(false);
    }
  };

  const handleMoveSection = (index: number, direction: 'up' | 'down') => {
    const newSections = [...sections];
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= newSections.length) return;

    const temp = newSections[index];
    newSections[index] = newSections[targetIndex];
    newSections[targetIndex] = temp;

    // Update order values
    newSections.forEach((s, idx) => (s.order = idx + 1));
    setSections(newSections);
  };

  const handleToggleSection = (id: string) => {
    setSections(prev =>
      prev.map(s => (s.id === id ? { ...s, is_enabled: !s.is_enabled } : s))
    );
  };

  const handleToggleFeaturedProduct = (id: string) => {
    setFeaturedProductIds(prev =>
      prev.includes(id) ? prev.filter(pId => pId !== id) : [...prev, id]
    );
  };

  const handleTogglePopularProduct = (id: string) => {
    setPopularProductIds(prev =>
      prev.includes(id) ? prev.filter(pId => pId !== id) : [...prev, id]
    );
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async () => {
      try {
        const base64 = reader.result as string;
        const uploaded = await adminUploadMedia(file.name, base64, file.type);
        setHeroImage(uploaded.url);
        setMediaList(prev => [uploaded, ...prev]);
      } catch (err: any) {
        alert(err.message || 'ছবি আপলোড ব্যর্থ হয়েছে।');
      }
    };
    reader.readAsDataURL(file);
  };

  if (loading) {
    return (
      <div className="py-20 text-center text-xs font-semibold text-[#8B4513]">
        হোমপেজ ডাটা লোড হচ্ছে...
      </div>
    );
  }

  return (
    <form onSubmit={handleSave} className="space-y-8">
      {/* Action Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-[#E5DACD] gap-3">
        <div>
          <h2 className="text-xl font-bold text-[#2C1810]">হোমপেজ এডিটর ও সেকশন বিন্যাস</h2>
          <p className="text-xs text-[#7A695C]">
            হিরো ব্যানার, অ্যানাউন্সমেন্ট টেক্সট, সেকশন সাজানো ও ফিচার্ড পণ্য নির্বাচন করুন।
          </p>
        </div>

        <button
          type="submit"
          disabled={saving}
          className="flex items-center gap-2 px-5 py-2.5 text-xs font-bold rounded-xl bg-[#B45309] text-white hover:bg-[#92400E] shadow-sm disabled:opacity-50"
        >
          <Save className="w-4 h-4" />
          <span>{saving ? 'সংরক্ষণ হচ্ছে...' : 'পরিবর্তনসমূহ সংরক্ষণ ও প্রকাশ করুন'}</span>
        </button>
      </div>

      {successMsg && (
        <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-semibold animate-fadeIn">
          {successMsg}
        </div>
      )}

      {/* Announcement Bar Settings */}
      <div className="bg-white rounded-2xl p-5 sm:p-6 border border-[#E5DACD] shadow-xs">
        <h3 className="text-sm font-bold text-[#2C1810] uppercase tracking-wider mb-3">
          ১. শীর্ষ অ্যানাউন্সমেন্ট বার (Announcement Bar)
        </h3>
        <div>
          <label className="block text-xs font-semibold text-[#7A695C] mb-1">
            ব্যানারের বার্তা (সবার উপরে প্রদর্শিত হবে)
          </label>
          <input
            type="text"
            value={announcementText}
            onChange={e => setAnnouncementText(e.target.value)}
            placeholder="✨ জয়নাল ফার্নিচার মার্ট — সারা বাংলাদেশে নিরাপদ হোম ডেলিভারি ও আধুনিক কাঠে তৈরি আসবাবপত্র..."
            className="w-full px-3.5 py-2.5 text-xs sm:text-sm bg-[#FAF7F2] border border-[#D8CEBF] rounded-xl text-[#2C1810]"
          />
        </div>
      </div>

      {/* Hero Section Settings */}
      <div className="bg-white rounded-2xl p-5 sm:p-6 border border-[#E5DACD] shadow-xs space-y-4">
        <h3 className="text-sm font-bold text-[#2C1810] uppercase tracking-wider mb-2">
          ২. হিরো কভার সেকশন (Hero Section)
        </h3>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-8 space-y-4">
            <div>
              <label className="block text-xs font-bold text-[#2C1810] mb-1">
                প্রধান শিরোনাম (Hero Heading) *
              </label>
              <input
                type="text"
                required
                value={heroTitle}
                onChange={e => setHeroTitle(e.target.value)}
                placeholder="আপনার স্বপ্নের গৃহসজ্জায় ঐতিহ্যের সেরা কাঠের ফার্নিচার"
                className="w-full px-3.5 py-2.5 text-xs sm:text-sm bg-[#FAF7F2] border border-[#D8CEBF] rounded-xl text-[#2C1810] focus:border-[#B45309]"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-[#2C1810] mb-1">
                উপ-শিরোনাম / বিবরণ (Hero Subtitle) *
              </label>
              <textarea
                rows={3}
                required
                value={heroSubtitle}
                onChange={e => setHeroSubtitle(e.target.value)}
                placeholder="চিটাগাং সেগুন ও সিজনড মেহগনি কাঠে তৈরি শৈল্পিক কারুকার্যখচিত খাট, সোফা, ডাইনিং ও গৃহসজ্জা সামগ্রী..."
                className="w-full px-3.5 py-2.5 text-xs sm:text-sm bg-[#FAF7F2] border border-[#D8CEBF] rounded-xl text-[#2C1810] resize-none"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-[#2C1810] mb-1">
                  বাটন লেখা (CTA Button Text)
                </label>
                <input
                  type="text"
                  value={heroCtaText}
                  onChange={e => setHeroCtaText(e.target.value)}
                  placeholder="ফার্নিচার কালেকশন দেখুন"
                  className="w-full px-3 py-2 text-xs bg-[#FAF7F2] border border-[#D8CEBF] rounded-lg text-[#2C1810]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#2C1810] mb-1">
                  বাটন লিংক (CTA Link)
                </label>
                <input
                  type="text"
                  value={heroCtaLink}
                  onChange={e => setHeroCtaLink(e.target.value)}
                  placeholder="#categories-section অথবা /category/bed"
                  className="w-full px-3 py-2 text-xs bg-[#FAF7F2] border border-[#D8CEBF] rounded-lg text-[#2C1810]"
                />
              </div>
            </div>
          </div>

          {/* Hero Cover Image Preview & Upload */}
          <div className="lg:col-span-4 flex flex-col justify-between">
            <div>
              <label className="block text-xs font-bold text-[#2C1810] mb-1">
                হিরো কভার ছবি (Hero Cover Image)
              </label>
              <div className="w-full h-40 rounded-xl overflow-hidden border border-[#E5DACD] bg-[#FAF7F2] mb-2">
                {heroImage ? (
                  <img src={heroImage} alt="হিরো কভার" className="w-full h-full object-cover" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-xs text-[#8B7363]">
                    ছবি নির্বাচন করুন
                  </div>
                )}
              </div>
            </div>

            <div className="space-y-2">
              <input
                type="text"
                value={heroImage}
                onChange={e => setHeroImage(e.target.value)}
                placeholder="/images/... অথবা /uploads/..."
                className="w-full px-2.5 py-1.5 text-xs bg-[#FAF7F2] border border-[#D8CEBF] rounded-lg text-[#2C1810]"
              />

              <label className="w-full flex items-center justify-center gap-2 py-2 px-3 text-xs font-bold rounded-lg bg-[#FAF7F2] border border-[#D8CEBF] text-[#2C1810] hover:bg-[#EFE7DE] cursor-pointer">
                <Upload className="w-3.5 h-3.5 text-[#B45309]" />
                <span>নতুন হিরো ছবি আপলোড করুন</span>
                <input type="file" accept="image/*" onChange={handleFileUpload} className="hidden" />
              </label>
            </div>
          </div>
        </div>
      </div>

      {/* Sections Ordering & Toggling */}
      <div className="bg-white rounded-2xl p-5 sm:p-6 border border-[#E5DACD] shadow-xs">
        <h3 className="text-sm font-bold text-[#2C1810] uppercase tracking-wider mb-2">
          ৩. হোমপেজ সেকশন সমূহের ক্রম ও দৃশ্যমানতা (Sections Order & Toggles)
        </h3>
        <p className="text-xs text-[#7A695C] mb-4">
          তীর চিহ্নে ক্লিক করে সেকশনের ক্রম পরিবর্তন করতে পারেন এবং চেকবাক্স দিয়ে অন/অফ করতে পারেন।
        </p>

        <div className="space-y-2">
          {sections.map((sec, idx) => (
            <div
              key={sec.id}
              className={`flex items-center justify-between p-3 rounded-xl border transition-colors ${
                sec.is_enabled ? 'bg-white border-[#E5DACD]' : 'bg-gray-50 border-gray-200 opacity-60'
              }`}
            >
              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={() => handleToggleSection(sec.id)}
                  className={`w-6 h-6 rounded-md flex items-center justify-center text-xs font-bold border ${
                    sec.is_enabled
                      ? 'bg-[#B45309] text-white border-[#B45309]'
                      : 'bg-white text-gray-400 border-gray-300'
                  }`}
                >
                  {sec.is_enabled && <Check className="w-4 h-4" />}
                </button>

                <span className="text-xs font-mono text-[#8B7363] tabular-nums">#{idx + 1}</span>
                <span className="text-xs sm:text-sm font-bold text-[#2C1810]">{sec.name_bn}</span>
              </div>

              <div className="flex items-center gap-1">
                <button
                  type="button"
                  disabled={idx === 0}
                  onClick={() => handleMoveSection(idx, 'up')}
                  className="p-1 rounded bg-[#FAF7F2] border border-[#D5C2B1] text-[#2C1810] hover:bg-[#EFE7DE] disabled:opacity-30"
                  title="উপরে নিন"
                >
                  <ArrowUp className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  disabled={idx === sections.length - 1}
                  onClick={() => handleMoveSection(idx, 'down')}
                  className="p-1 rounded bg-[#FAF7F2] border border-[#D5C2B1] text-[#2C1810] hover:bg-[#EFE7DE] disabled:opacity-30"
                  title="নিচে নিন"
                >
                  <ArrowDown className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Featured & Popular Products Selector */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Popular Products Selection */}
        <div className="bg-white rounded-2xl p-5 sm:p-6 border border-[#E5DACD] shadow-xs">
          <div className="flex items-center gap-2 mb-3">
            <Star className="w-4 h-4 text-[#B45309]" />
            <h3 className="text-sm font-bold text-[#2C1810] uppercase tracking-wider">
              জনপ্রিয় পণ্য নির্বাচন (Popular Products)
            </h3>
          </div>
          <p className="text-xs text-[#7A695C] mb-3">
            হোমপেজের 'জনপ্রিয় ফার্নিচার পণ্য' সেকশনে প্রদর্শনের জন্য টিক দিন:
          </p>
          <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
            {products.map(p => {
              const isChecked = popularProductIds.includes(p.id) || p.is_popular;
              return (
                <label
                  key={p.id}
                  className="flex items-center justify-between p-2 rounded-lg bg-[#FAF7F2] border border-[#E5DACD] cursor-pointer hover:bg-[#F3ECE0]"
                >
                  <div className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      checked={isChecked}
                      onChange={() => handleTogglePopularProduct(p.id)}
                      className="w-4 h-4 text-[#B45309] rounded"
                    />
                    <span className="text-xs font-semibold text-[#2C1810] line-clamp-1">{p.name_bn}</span>
                  </div>
                  <span className="text-[11px] font-bold text-[#8B4513] tabular-nums">
                    ৳{p.price.toLocaleString()}
                  </span>
                </label>
              );
            })}
          </div>
        </div>

        {/* Featured Products Selection */}
        <div className="bg-white rounded-2xl p-5 sm:p-6 border border-[#E5DACD] shadow-xs">
          <div className="flex items-center gap-2 mb-3">
            <Sparkles className="w-4 h-4 text-[#B45309]" />
            <h3 className="text-sm font-bold text-[#2C1810] uppercase tracking-wider">
              সেরা কালেকশন নির্বাচন (Featured Products)
            </h3>
          </div>
          <p className="text-xs text-[#7A695C] mb-3">
            হোমপেজের 'সেরা কালেকশন ও স্পেশাল ডিজাইন' সেকশনের জন্য পণ্য নির্বাচন করুন:
          </p>
          <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
            {products.map(p => {
              const isChecked = featuredProductIds.includes(p.id) || p.is_featured;
              return (
                <label
                  key={p.id}
                  className="flex items-center justify-between p-2 rounded-lg bg-[#FAF7F2] border border-[#E5DACD] cursor-pointer hover:bg-[#F3ECE0]"
                >
                  <div className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      checked={isChecked}
                      onChange={() => handleToggleFeaturedProduct(p.id)}
                      className="w-4 h-4 text-[#B45309] rounded"
                    />
                    <span className="text-xs font-semibold text-[#2C1810] line-clamp-1">{p.name_bn}</span>
                  </div>
                  <span className="text-[11px] font-bold text-[#8B4513] tabular-nums">
                    ৳{p.price.toLocaleString()}
                  </span>
                </label>
              );
            })}
          </div>
        </div>
      </div>
    </form>
  );
}
