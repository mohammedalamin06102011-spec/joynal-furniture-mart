import { useState } from 'react';
import { Armchair } from 'lucide-react';

interface SafeImageProps {
  src: string;
  alt: string;
  className?: string;
  aspectRatioClass?: string;
}

export default function SafeImage({
  src,
  alt,
  className = '',
  aspectRatioClass = 'aspect-[4/3]'
}: SafeImageProps) {
  const [hasError, setHasError] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  if (hasError || !src) {
    return (
      <div
        className={`w-full ${aspectRatioClass} bg-[#F0EAE1] flex flex-col items-center justify-center p-4 text-center border border-[#E6DFD5] ${className}`}
      >
        <div className="w-10 h-10 rounded-full bg-[#E2D7C8] flex items-center justify-center text-[#8B4513] mb-2">
          <Armchair className="w-5 h-5" />
        </div>
        <span className="text-xs font-medium text-[#78350F] line-clamp-1">{alt}</span>
        <span className="text-[10px] text-[#A28B78] mt-0.5">জয়নাল ফার্নিচার মার্ট</span>
      </div>
    );
  }

  return (
    <div className={`relative overflow-hidden ${aspectRatioClass} ${className} bg-[#F0EAE1]`}>
      {isLoading && (
        <div className="absolute inset-0 bg-[#EFE9DF] animate-pulse flex items-center justify-center">
          <div className="w-6 h-6 border-2 border-[#8B4513] border-t-transparent rounded-full animate-spin" />
        </div>
      )}
      <img
        src={src}
        alt={alt}
        referrerPolicy="no-referrer"
        onLoad={() => setIsLoading(false)}
        onError={() => setHasError(true)}
        className={`w-full h-full object-cover transition-transform duration-500 hover:scale-105 ${
          isLoading ? 'opacity-0' : 'opacity-100'
        }`}
      />
    </div>
  );
}
