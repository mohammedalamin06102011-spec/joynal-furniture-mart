import { useState, useMemo } from 'react';
import { Category, Product, Advertisement, WebsiteSettings } from '../types.ts';
import ProductCard from './ProductCard.tsx';
import SafeImage from './SafeImage.tsx';
import AdvertisementBanner from './AdvertisementBanner.tsx';
import { Search, SlidersHorizontal, ArrowUpDown, ChevronRight, Armchair } from 'lucide-react';

interface CategoryPageProps {
  category: Category;
  products: Product[];
  advertisements: Advertisement[];
  settings?: WebsiteSettings;
  onViewProduct: (product: Product) => void;
  onNavigateHome: () => void;
  onNavigateCategories: () => void;
  onSelectCategory: (slug: string) => void;
  allCategories?: Category[];
}

export default function CategoryPage({
  category,
  products,
  advertisements,
  settings,
  onViewProduct,
  onNavigateHome,
  onNavigateCategories,
  onSelectCategory,
  allCategories = []
}: CategoryPageProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [sortBy, setSortBy] = useState<'default' | 'price_asc' | 'price_desc' | 'newest'>('default');

  // Filter and sort products
  const filteredProducts = useMemo(() => {
    let result = products.filter(p => p.category_slug === category.slug);

    if (searchTerm.trim()) {
      const q = searchTerm.toLowerCase().trim();
      result = result.filter(
        p =>
          p.name_bn.toLowerCase().includes(q) ||
          p.name_en.toLowerCase().includes(q) ||
          p.short_desc_bn.toLowerCase().includes(q) ||
          p.materials.toLowerCase().includes(q)
      );
    }

    if (sortBy === 'price_asc') {
      result.sort((a, b) => (a.discount_price || a.price) - (b.discount_price || b.price));
    } else if (sortBy === 'price_desc') {
      result.sort((a, b) => (b.discount_price || b.price) - (a.discount_price || a.price));
    } else if (sortBy === 'newest') {
      result.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
    }

    return result;
  }, [products, category.slug, searchTerm, sortBy]);

  // Ads for category page
  const topAd = advertisements.find(a => a.placement === 'category_top');
  const bottomAd = advertisements.find(a => a.placement === 'category_bottom');
  const gridAd = advertisements.find(a => a.placement === 'category_grid');

  // Row interval for ad insertion (e.g. 2 or 3 rows, in desktop 4 cols means 8 items)
  const itemsBeforeGridAd = (gridAd?.row_interval || 2) * 4;

  return (
    <div className="min-h-screen bg-[#FAF7F2] pb-16">
      {/* Category Cover Banner */}
      <div className="relative bg-[#2C1810] text-white overflow-hidden">
        <div className="absolute inset-0 opacity-30 mix-blend-overlay">
          <SafeImage
            src={category.cover_image}
            alt={category.name_bn}
            aspectRatioClass="h-full w-full"
            className="object-cover h-full w-full"
          />
        </div>
        <div className="absolute inset-0 bg-gradient-to-r from-[#2C1810] via-[#2C1810]/90 to-transparent" />

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-14">
          {/* Breadcrumb */}
          <nav className="flex items-center gap-1.5 text-xs text-amber-200/80 mb-3">
            <button onClick={onNavigateHome} className="hover:underline">
              হোম
            </button>
            <ChevronRight className="w-3.5 h-3.5" />
            <button onClick={onNavigateCategories} className="hover:underline">
              ক্যাটাগরি
            </button>
            <ChevronRight className="w-3.5 h-3.5" />
            <span className="text-white font-semibold">{category.name_bn}</span>
          </nav>

          <div className="max-w-2xl">
            <h1 className="text-3xl sm:text-4xl font-bold tracking-tight text-white mb-2">
              {category.name_bn} কালেকশন
            </h1>
            <p className="text-sm sm:text-base text-amber-100/90 leading-relaxed">
              {category.description_bn ||
                'জয়নাল ফার্নিচার মার্টের প্রিমিয়াম কোয়ালিটি কাঠের আধুনিক ও ঐতিহ্যবাহী আসবাব।'}
            </p>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8">
        {/* Top Ad Banner Placement */}
        {topAd && (
          <div className="mb-8">
            <AdvertisementBanner ad={topAd} />
          </div>
        )}

        {/* Category Quick Chips / Tabs */}
        {allCategories.length > 0 && (
          <div className="flex items-center gap-2 overflow-x-auto pb-3 mb-6 scrollbar-none">
            <span className="text-xs font-semibold text-[#8B7363] uppercase tracking-wider shrink-0 mr-1">
              অন্যান্য ক্যাটাগরি:
            </span>
            {allCategories.map(cat => {
              const isActive = cat.slug === category.slug;
              return (
                <button
                  key={cat.id}
                  onClick={() => onSelectCategory(cat.slug)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
                    isActive
                      ? 'bg-[#B45309] text-white shadow-xs'
                      : 'bg-white text-[#4A3B32] border border-[#E0D5C7] hover:border-[#8B4513]'
                  }`}
                >
                  {cat.name_bn}
                </button>
              );
            })}
          </div>
        )}

        {/* Toolbar: Search, Total Count, and Sorting */}
        <div className="bg-white p-4 rounded-xl border border-[#E8DFD3] shadow-xs mb-6 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
          {/* Total Product Count */}
          <div className="flex items-center gap-2 text-sm font-bold text-[#2C1810]">
            <Armchair className="w-4 h-4 text-[#8B4513]" />
            <span>
              মোট পণ্য: <span className="text-[#B45309]">{filteredProducts.length}</span> টি
            </span>
          </div>

          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
            {/* Search Input */}
            <div className="relative min-w-[220px]">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-[#8B7363]" />
              <input
                type="text"
                placeholder={`${category.name_bn} খুঁজুন...`}
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
                className="w-full pl-9 pr-3 py-2 text-xs sm:text-sm bg-[#FAF7F2] border border-[#D8CEBF] rounded-lg text-[#2C1810] focus:outline-none focus:border-[#8B4513] transition-colors"
              />
            </div>

            {/* Sorting Select */}
            <div className="flex items-center gap-2">
              <ArrowUpDown className="w-4 h-4 text-[#8B7363] shrink-0" />
              <select
                value={sortBy}
                onChange={e => setSortBy(e.target.value as any)}
                className="w-full sm:w-auto py-2 px-3 text-xs sm:text-sm bg-[#FAF7F2] border border-[#D8CEBF] rounded-lg text-[#2C1810] focus:outline-none focus:border-[#8B4513] transition-colors font-medium cursor-pointer"
              >
                <option value="default">ডিফল্ট ক্রমানুসার</option>
                <option value="price_asc">মূল্য: কম থেকে বেশি</option>
                <option value="price_desc">মূল্য: বেশি থেকে কম</option>
                <option value="newest">নতুন আগমন (Newest)</option>
              </select>
            </div>
          </div>
        </div>

        {/* Products Grid */}
        {filteredProducts.length === 0 ? (
          <div className="bg-white rounded-2xl border border-[#E8DFD3] p-12 text-center my-8">
            <Armchair className="w-12 h-12 text-[#BCAAA4] mx-auto mb-3" />
            <h3 className="text-lg font-bold text-[#2C1810]">কোনো পণ্য পাওয়া যায়নি</h3>
            <p className="text-sm text-[#7A695C] mt-1 max-w-md mx-auto">
              অনুসন্ধানের সাথে মিল রেখে কোনো ফার্নিচার পাওয়া যায়নি। দয়া করে অন্য কোনো নাম দিয়ে সার্চ করুন অথবা কাস্টম অর্ডারের জন্য আমাদের সাথে যোগাযোগ করুন।
            </p>
            {searchTerm && (
              <button
                onClick={() => setSearchTerm('')}
                className="mt-4 px-4 py-2 text-xs font-semibold rounded-lg bg-[#FAF7F2] text-[#8B4513] border border-[#D8CEBF] hover:bg-[#EFE7DE]"
              >
                সার্চ ফিল্টার রিসেট করুন
              </button>
            )}
          </div>
        ) : (
          <div>
            {/* First chunk of products before mid-grid ad */}
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-6">
              {filteredProducts.slice(0, itemsBeforeGridAd).map(product => (
                <ProductCard
                  key={product.id}
                  product={product}
                  settings={settings}
                  onViewDetails={onViewProduct}
                />
              ))}
            </div>

            {/* Mid-Grid Advertisement Placement after configurable rows */}
            {gridAd && filteredProducts.length > itemsBeforeGridAd && (
              <div className="my-8">
                <AdvertisementBanner ad={gridAd} />
              </div>
            )}

            {/* Remaining products */}
            {filteredProducts.length > itemsBeforeGridAd && (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-6 mt-6">
                {filteredProducts.slice(itemsBeforeGridAd).map(product => (
                  <ProductCard
                    key={product.id}
                    product={product}
                    settings={settings}
                    onViewDetails={onViewProduct}
                  />
                ))}
              </div>
            )}
          </div>
        )}

        {/* Bottom Ad Banner Placement */}
        {bottomAd && (
          <div className="mt-12">
            <AdvertisementBanner ad={bottomAd} />
          </div>
        )}
      </div>
    </div>
  );
}
