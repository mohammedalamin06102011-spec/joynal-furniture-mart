import { useState } from 'react';
import { WebsiteSettings } from '../types.ts';
import { Menu, X, Phone, MessageCircle, Armchair, ChevronRight } from 'lucide-react';

interface HeaderProps {
  settings?: WebsiteSettings;
  currentView: string;
  onNavigate: (view: string, param?: string) => void;
}

export default function Header({ settings, currentView, onNavigate }: HeaderProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { id: 'home', label: 'হোম' },
    { id: 'categories', label: 'ক্যাটাগরি' },
    { id: 'popular', label: 'জনপ্রিয় পণ্য' },
    { id: 'about', label: 'আমাদের সম্পর্কে' },
    { id: 'contact', label: 'যোগাযোগ' }
  ];

  const handleLinkClick = (id: string) => {
    onNavigate(id);
    setMobileMenuOpen(false);
  };

  const whatsappNumber = settings?.whatsapp_number?.replace(/[^0-9]/g, '') || '8801712345678';
  const phonePrimary = settings?.phone_primary || '+880 1712-345678';

  return (
    <header className="sticky top-0 z-50 w-full bg-[#FAF7F2]/95 backdrop-blur-md border-b border-[#E8DFD3] shadow-xs">
      {/* Top Announcement Bar */}
      <div className="bg-[#2C1810] text-[#EFE7DE] text-xs py-1.5 px-4">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-1 text-center sm:text-left">
          <p className="line-clamp-1 font-medium text-[11px] sm:text-xs">
            {settings?.announcement_text || '✨ জয়নাল ফার্নিচার মার্ট — সারা বাংলাদেশে নিরাপদ ডেলিভারি ও অরিজিনাল কাঠের আসবাব'}
          </p>
          <div className="flex items-center gap-4 text-[11px] text-amber-200/90 shrink-0">
            <a
              href={`tel:${phonePrimary.replace(/[^0-9+]/g, '')}`}
              className="flex items-center gap-1 hover:text-white transition-colors"
            >
              <Phone className="w-3 h-3 text-amber-400" />
              <span>{phonePrimary}</span>
            </a>
            <span className="hidden md:inline text-amber-500/50">|</span>
            <span className="hidden md:inline text-[#D5C2B1]">মিরপুর-১০, ঢাকা</span>
          </div>
        </div>
      </div>

      {/* Main Header Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-18 sm:h-20 gap-4">
          {/* Brand Logo & Name */}
          <div
            onClick={() => handleLinkClick('home')}
            className="flex items-center gap-3 cursor-pointer group shrink-0"
          >
            <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-xl bg-gradient-to-br from-[#8B4513] to-[#4A2818] flex items-center justify-center text-amber-100 shadow-sm group-hover:scale-105 transition-transform">
              <Armchair className="w-6 h-6" />
            </div>
            <div className="flex flex-col">
              <span className="text-xl sm:text-2xl font-bold tracking-tight text-[#2C1810] group-hover:text-[#8B4513] transition-colors leading-tight">
                {settings?.site_name_bn || 'জয়নাল ফার্নিচার মার্ট'}
              </span>
              <span className="text-[11px] sm:text-xs font-semibold tracking-wider text-[#A28B78] uppercase">
                {settings?.site_name_en || 'Joynal Furniture Mart'}
              </span>
            </div>
          </div>

          {/* Desktop Navigation Links */}
          <nav className="hidden md:flex items-center gap-8 text-sm font-semibold text-[#4A3B32]">
            {navLinks.map(link => {
              const isActive = currentView === link.id;
              return (
                <button
                  key={link.id}
                  onClick={() => handleLinkClick(link.id)}
                  className={`relative py-1 transition-colors hover:text-[#B45309] ${
                    isActive ? 'text-[#B45309]' : ''
                  }`}
                >
                  {link.label}
                  {isActive && (
                    <span className="absolute bottom-0 left-0 w-full h-0.5 bg-[#B45309] rounded-full" />
                  )}
                </button>
              );
            })}
          </nav>

          {/* Right Action Buttons */}
          <div className="hidden sm:flex items-center gap-3 shrink-0">
            <a
              href={`https://wa.me/${whatsappNumber}?text=${encodeURIComponent('আসসালামু আলাইকুম, আমি জয়নাল ফার্নিচার মার্ট থেকে ফার্নিচার সম্পর্কে জানতে চাচ্ছি।')}`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-lg bg-[#25D366]/15 text-[#128C7E] hover:bg-[#25D366]/25 border border-[#25D366]/30 transition-colors"
            >
              <MessageCircle className="w-4 h-4 text-[#128C7E]" />
              <span>হোয়াটসঅ্যাপ</span>
            </a>

            <button
              onClick={() => handleLinkClick('contact')}
              className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold rounded-lg bg-[#B45309] text-white hover:bg-[#92400E] shadow-sm transition-all"
            >
              <Phone className="w-3.5 h-3.5" />
              <span>যোগাযোগ করুন</span>
            </button>
          </div>

          {/* Mobile Menu Button */}
          <div className="flex md:hidden items-center gap-2">
            <a
              href={`https://wa.me/${whatsappNumber}`}
              target="_blank"
              rel="noopener noreferrer"
              aria-label="WhatsApp"
              className="p-2 rounded-lg bg-[#25D366]/15 text-[#128C7E]"
            >
              <MessageCircle className="w-5 h-5" />
            </a>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg text-[#2C1810] hover:bg-[#EFE7DE] transition-colors"
              aria-label="মেনু খুলুন"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-[#FAF7F2] border-b border-[#E5DACD] px-4 pt-3 pb-6 animate-fadeIn">
          <div className="space-y-1 mb-4">
            {navLinks.map(link => {
              const isActive = currentView === link.id;
              return (
                <button
                  key={link.id}
                  onClick={() => handleLinkClick(link.id)}
                  className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-sm font-semibold text-left transition-colors ${
                    isActive
                      ? 'bg-[#EFE7DE] text-[#B45309]'
                      : 'text-[#2C1810] hover:bg-[#F5EFE6]'
                  }`}
                >
                  <span>{link.label}</span>
                  <ChevronRight className="w-4 h-4 text-[#A28B78]" />
                </button>
              );
            })}
          </div>

          <div className="pt-3 border-t border-[#E8DFD3] flex flex-col gap-2">
            <a
              href={`tel:${phonePrimary.replace(/[^0-9+]/g, '')}`}
              className="flex items-center justify-center gap-2 py-2.5 px-4 rounded-lg bg-white border border-[#D8CEBF] text-sm font-bold text-[#2C1810]"
            >
              <Phone className="w-4 h-4 text-[#8B4513]" />
              <span>কল করুন: {phonePrimary}</span>
            </a>
            <a
              href={`https://wa.me/${whatsappNumber}?text=${encodeURIComponent('আসসালামু আলাইকুম, আমি ফার্নিচার সম্পর্কে জানতে চাচ্ছি।')}`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 py-2.5 px-4 rounded-lg bg-[#25D366] text-white text-sm font-bold shadow-xs"
            >
              <MessageCircle className="w-4 h-4" />
              <span>হোয়াটসঅ্যাপে মেসেজ পাঠান</span>
            </a>
          </div>
        </div>
      )}
    </header>
  );
}
