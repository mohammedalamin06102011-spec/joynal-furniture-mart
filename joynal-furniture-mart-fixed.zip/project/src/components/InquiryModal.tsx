import { useState } from 'react';
import { Product, WebsiteSettings } from '../types.ts';
import { submitInquiry } from '../services/api.ts';
import { X, Send, CheckCircle2, MessageCircle, Phone, AlertCircle } from 'lucide-react';

interface InquiryModalProps {
  product: Product;
  settings?: WebsiteSettings;
  onClose: () => void;
}

export default function InquiryModal({ product, settings, onClose }: InquiryModalProps) {
  const [customerName, setCustomerName] = useState('');
  const [phone, setPhone] = useState('');
  const [message, setMessage] = useState(
    `আমি "${product.name_bn}" পণ্যটি সম্পর্কে জানতে এবং অর্ডার করতে আগ্রহী।`
  );
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const currentPrice = product.discount_price || product.price;
  const formattedPrice = `৳ ${currentPrice.toLocaleString('en-US')}`;
  const whatsappNumber = settings?.whatsapp_number?.replace(/[^0-9]/g, '') || '8801712345678';
  const whatsappUrl = `https://wa.me/${whatsappNumber}?text=${encodeURIComponent(
    `আসসালামু আলাইকুম, আমি জয়নাল ফার্নিচার মার্ট থেকে "${product.name_bn}" (মূল্য: ${formattedPrice}) সম্পর্কে জানতে চাই।`
  )}`;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName.trim() || !phone.trim()) {
      setErrorMsg('দয়া করে আপনার নাম এবং মোবাইল নম্বর দিন।');
      return;
    }

    try {
      setIsSubmitting(true);
      setErrorMsg('');
      await submitInquiry({
        customer_name: customerName,
        phone,
        message,
        product_id: product.id,
        product_name: product.name_bn
      });
      setIsSuccess(true);
    } catch (err: any) {
      setErrorMsg(err.message || 'মেসেজ পাঠানো সম্ভব হয়নি।');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fadeIn">
      <div className="relative w-full max-w-lg bg-white rounded-2xl shadow-2xl border border-[#E8DFD3] overflow-hidden">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-[#F0EAE1] bg-[#FAF7F2]">
          <div>
            <h3 className="text-base sm:text-lg font-bold text-[#2C1810]">
              পণ্য অর্ডার ও তথ্যের জন্য যোগাযোগ
            </h3>
            <p className="text-xs text-[#7A695C] line-clamp-1">
              {product.name_bn} · {formattedPrice}
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-[#8B7363] hover:text-[#2C1810] hover:bg-[#EFE7DE] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 sm:p-6">
          {isSuccess ? (
            <div className="text-center py-6">
              <CheckCircle2 className="w-14 h-14 text-emerald-600 mx-auto mb-3" />
              <h4 className="text-lg font-bold text-[#2C1810]">আপনার তথ্য গৃহীত হয়েছে!</h4>
              <p className="text-xs sm:text-sm text-[#5A483C] mt-2">
                জয়নাল ফার্নিচার মার্ট থেকে অতি শীঘ্রই আপনার সাথে যোগাযোগ করা হবে।
              </p>
              <button
                onClick={onClose}
                className="mt-6 px-6 py-2.5 rounded-xl bg-[#B45309] text-white font-semibold text-xs sm:text-sm hover:bg-[#92400E]"
              >
                ঠিক আছে
              </button>
            </div>
          ) : (
            <div>
              <div className="flex items-center gap-2 p-2.5 rounded-lg bg-[#FAF7F2] border border-[#E8DFD3] mb-4">
                <img
                  src={product.main_image}
                  alt={product.name_bn}
                  className="w-12 h-12 rounded object-cover"
                />
                <div className="text-xs leading-tight">
                  <p className="font-bold text-[#2C1810] line-clamp-1">{product.name_bn}</p>
                  <p className="text-[#8B4513] font-semibold">{formattedPrice}</p>
                </div>
              </div>

              {errorMsg && (
                <div className="p-2.5 rounded-lg bg-red-50 border border-red-200 flex items-center gap-2 text-xs text-red-800 mb-3">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{errorMsg}</span>
                </div>
              )}

              <form onSubmit={handleSubmit} className="space-y-3.5">
                <div>
                  <label className="block text-xs font-bold text-[#2C1810] mb-1">
                    আপনার নাম *
                  </label>
                  <input
                    type="text"
                    required
                    value={customerName}
                    onChange={e => setCustomerName(e.target.value)}
                    placeholder="আপনার নাম লিখুন"
                    className="w-full px-3 py-2 text-xs sm:text-sm bg-[#FAF7F2] border border-[#D8CEBF] rounded-lg text-[#2C1810] focus:outline-none focus:border-[#8B4513]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#2C1810] mb-1">
                    মোবাইল নম্বর *
                  </label>
                  <input
                    type="tel"
                    required
                    value={phone}
                    onChange={e => setPhone(e.target.value)}
                    placeholder="যেমন: 01712345678"
                    className="w-full px-3 py-2 text-xs sm:text-sm bg-[#FAF7F2] border border-[#D8CEBF] rounded-lg text-[#2C1810] focus:outline-none focus:border-[#8B4513]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#2C1810] mb-1">
                    বার্তা বা বিশেষ নোট
                  </label>
                  <textarea
                    rows={2}
                    value={message}
                    onChange={e => setMessage(e.target.value)}
                    className="w-full px-3 py-2 text-xs sm:text-sm bg-[#FAF7F2] border border-[#D8CEBF] rounded-lg text-[#2C1810] focus:outline-none focus:border-[#8B4513] resize-none"
                  />
                </div>

                <div className="pt-2 flex flex-col gap-2">
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-[#B45309] text-white font-bold text-xs sm:text-sm hover:bg-[#92400E] transition-all disabled:opacity-50"
                  >
                    <Send className="w-4 h-4" />
                    <span>{isSubmitting ? 'প্রেরণ করা হচ্ছে...' : 'মেসেজ জমা দিন'}</span>
                  </button>

                  <a
                    href={whatsappUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-[#25D366] text-white font-bold text-xs sm:text-sm hover:bg-[#20BA5A] transition-all"
                  >
                    <MessageCircle className="w-4 h-4" />
                    <span>অথবা হোয়াটসঅ্যাপে সরাসরি যোগাযোগ করুন</span>
                  </a>
                </div>
              </form>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
