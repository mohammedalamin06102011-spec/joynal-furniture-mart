import { WebsiteSettings } from '../types.ts';
import SafeImage from './SafeImage.tsx';
import { ArrowRight, MessageCircle, ShieldCheck, Truck, Sparkles, Award } from 'lucide-react';

interface HeroProps {
  settings?: WebsiteSettings;
  onExploreProducts: () => void;
  onContactClick: () => void;
}

export default function Hero({ settings, onExploreProducts, onContactClick }: HeroProps) {
  const whatsappNumber = settings?.whatsapp_number?.replace(/[^0-9]/g, '') || '8801712345678';
  const heroImage = settings?.hero_image || '/images/hero_furniture_cover_1793102992976.jpg';

  return (
    <section className="relative overflow-hidden bg-gradient-to-b from-[#FAF7F2] to-[#F5EFE6] pt-6 sm:pt-10 pb-12 sm:pb-16 border-b border-[#E8DFD3]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          {/* Left Text Column */}
          <div className="lg:col-span-7 flex flex-col items-start text-left">
            {/* Trust Kicker */}
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-[#EFE7DE] border border-[#DFCFC0] text-xs font-semibold text-[#8B4513] mb-4">
              <Sparkles className="w-3.5 h-3.5 text-[#B45309]" />
              <span>ঐতিহ্য ও আধুনিকতার নিখুঁত সংমিশ্রণ</span>
            </div>

            {/* Display Headline */}
            <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-[44px] font-bold text-[#2C1810] tracking-tight leading-[1.25] text-balance">
              {settings?.hero_title || 'আপনার স্বপ্নের গৃহসজ্জায় ঐতিহ্যের সেরা কাঠের ফার্নিচার'}
            </h1>

            {/* Subtitle */}
            <p className="mt-4 sm:mt-5 text-base sm:text-lg text-[#5A483C] leading-relaxed max-w-2xl">
              {settings?.hero_subtitle ||
                'চিটাগাং সেগুন ও সিজনড মেহগনি কাঠে তৈরি শৈল্পিক কারুকার্যখচিত খাট, সোফা, ডাইনিং ও আলমারি কালেকশন। তিন দশকেরও বেশি সময় ধরে আপনার আস্থার বিশ্বস্ত প্রতিষ্ঠান।'}
            </p>

            {/* CTA Buttons */}
            <div className="mt-6 sm:mt-8 flex flex-wrap items-center gap-3 sm:gap-4 w-full sm:w-auto">
              <button
                onClick={onExploreProducts}
                className="w-full sm:w-auto flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl bg-[#B45309] text-white font-bold text-sm sm:text-base hover:bg-[#92400E] shadow-sm hover:shadow-md transition-all active:scale-[0.99]"
              >
                <span>ফার্নিচার কালেকশন দেখুন</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <a
                href={`https://wa.me/${whatsappNumber}?text=${encodeURIComponent('আসসালামু আলাইকুম, আমি জয়নাল ফার্নিচার মার্ট থেকে ফার্নিচার অর্ডার ও ক্যাটালগ দেখতে চাই।')}`}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full sm:w-auto flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl bg-white border border-[#D5C2B1] text-[#2C1810] font-bold text-sm sm:text-base hover:bg-[#FAF7F2] hover:border-[#8B4513] shadow-2xs transition-all"
              >
                <MessageCircle className="w-4 h-4 text-[#25D366]" />
                <span>হোয়াটসঅ্যাপে কথা বলুন</span>
              </a>
            </div>

            {/* Proof Points Strip */}
            <div className="mt-8 sm:mt-10 pt-6 border-t border-[#E8DFD3] grid grid-cols-3 gap-3 sm:gap-6 w-full text-left">
              <div className="flex flex-col">
                <div className="flex items-center gap-1.5 text-[#8B4513] font-bold text-xs sm:text-sm">
                  <ShieldCheck className="w-4 h-4 shrink-0 text-[#B45309]" />
                  <span>১৫ বছর গ্যারান্টি</span>
                </div>
                <span className="text-[11px] sm:text-xs text-[#7A695C] mt-0.5">ঘুণের বিরুদ্ধে সুরক্ষা</span>
              </div>

              <div className="flex flex-col">
                <div className="flex items-center gap-1.5 text-[#8B4513] font-bold text-xs sm:text-sm">
                  <Award className="w-4 h-4 shrink-0 text-[#B45309]" />
                  <span>১০০% খাঁটি কাঠ</span>
                </div>
                <span className="text-[11px] sm:text-xs text-[#7A695C] mt-0.5">সেগুন ও মেহগনি</span>
              </div>

              <div className="flex flex-col">
                <div className="flex items-center gap-1.5 text-[#8B4513] font-bold text-xs sm:text-sm">
                  <Truck className="w-4 h-4 shrink-0 text-[#B45309]" />
                  <span>হোম ডেলিভারি</span>
                </div>
                <span className="text-[11px] sm:text-xs text-[#7A695C] mt-0.5">সমগ্র বাংলাদেশে</span>
              </div>
            </div>
          </div>

          {/* Right Showcase Image */}
          <div className="lg:col-span-5 relative">
            <div className="relative rounded-2xl overflow-hidden shadow-xl border-4 border-white">
              <SafeImage
                src={heroImage}
                alt="জয়নাল ফার্নিচার মার্ট শো-রুম"
                aspectRatioClass="aspect-[4/3] lg:aspect-[5/4]"
              />

              {/* Floating Badge */}
              <div className="absolute bottom-4 left-4 right-4 bg-white/95 backdrop-blur-md p-3.5 rounded-xl border border-[#E8DFD3] shadow-md flex items-center justify-between">
                <div>
                  <p className="text-xs font-bold text-[#2C1810]">জয়নাল ফার্নিচার মার্ট</p>
                  <p className="text-[11px] text-[#7A695C]">অভিজাত কাঠের আসবাবপত্র প্রদর্শনী</p>
                </div>
                <span className="px-2.5 py-1 rounded bg-[#F5EFE6] text-[#8B4513] text-xs font-bold border border-[#DFCFC0]">
                  সেরা মান
                </span>
              </div>
            </div>

            {/* Subtle decorative background accent */}
            <div className="absolute -top-4 -right-4 w-32 h-32 bg-[#D97706]/10 rounded-full blur-2xl -z-10" />
            <div className="absolute -bottom-6 -left-6 w-40 h-40 bg-[#8B4513]/10 rounded-full blur-3xl -z-10" />
          </div>
        </div>
      </div>
    </section>
  );
}
