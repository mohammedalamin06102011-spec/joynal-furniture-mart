import { useState } from 'react';
import { Product, Advertisement, WebsiteSettings } from '../types.ts';
import SafeImage from './SafeImage.tsx';
import ProductCard from './ProductCard.tsx';
import AdvertisementBanner from './AdvertisementBanner.tsx';
import {
  MessageCircle,
  Phone,
  ShieldCheck,
  Truck,
  RotateCcw,
  CheckCircle2,
  Clock,
  Ruler,
  Layers,
  Palette,
  ChevronRight,
  Share2,
  Check
} from 'lucide-react';

interface ProductDetailsProps {
  product: Product;
  relatedProducts: Product[];
  advertisements: Advertisement[];
  settings?: WebsiteSettings;
  onViewProduct: (product: Product) => void;
  onNavigateCategory: (slug: string) => void;
  onNavigateHome: () => void;
  onOpenInquiryModal: (product: Product) => void;
}

export default function ProductDetailsPage({
  product,
  relatedProducts,
  advertisements,
  settings,
  onViewProduct,
  onNavigateCategory,
  onNavigateHome,
  onOpenInquiryModal
}: ProductDetailsProps) {
  // Additional images list
  const allImages = Array.from(new Set([product.main_image, ...(product.additional_images || [])]));
  const [selectedImage, setSelectedImage] = useState(allImages[0]);
  const [selectedColor, setSelectedColor] = useState(product.colors?.[0] || '');
  const [copiedLink, setCopiedLink] = useState(false);

  const currentPrice = product.discount_price || product.price;
  const hasDiscount = Boolean(product.discount_price && product.discount_price < product.price);
  const formattedPrice = `৳ ${currentPrice.toLocaleString('en-US')}`;
  const formattedOriginalPrice = `৳ ${product.price.toLocaleString('en-US')}`;

  const whatsappNumber = settings?.whatsapp_number?.replace(/[^0-9]/g, '') || '8801712345678';
  const phonePrimary = settings?.phone_primary || '+880 1712-345678';

  // WhatsApp prefilled message containing product name and price
  const whatsappMessage = encodeURIComponent(
    `আসসালামু আলাইকুম! আমি জয়নাল ফার্নিচার মার্ট থেকে "${product.name_bn}" (মূল্য: ${formattedPrice}, কোড: ${product.id}) সম্পর্কে জানতে চাই এবং এটি অর্ডার করতে আগ্রহী।`
  );
  const whatsappUrl = `https://wa.me/${whatsappNumber}?text=${whatsappMessage}`;

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: product.name_bn,
        text: `${product.name_bn} - জয়নাল ফার্নিচার মার্ট`,
        url: window.location.href
      }).catch(() => {});
    } else {
      navigator.clipboard.writeText(window.location.href);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2000);
    }
  };

  const adBelowInfo = advertisements.find(a => a.placement === 'product_below_info');
  const adBelowRelated = advertisements.find(a => a.placement === 'product_below_related');

  return (
    <div className="min-h-screen bg-[#FAF7F2] pb-16 pt-4 sm:pt-6">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Breadcrumb */}
        <nav className="flex items-center gap-1.5 text-xs text-[#7A695C] mb-6 flex-wrap">
          <button onClick={onNavigateHome} className="hover:text-[#B45309] transition-colors">
            হোম
          </button>
          <ChevronRight className="w-3.5 h-3.5" />
          <button
            onClick={() => onNavigateCategory(product.category_slug)}
            className="hover:text-[#B45309] transition-colors capitalize"
          >
            {product.category_slug}
          </button>
          <ChevronRight className="w-3.5 h-3.5" />
          <span className="text-[#2C1810] font-semibold line-clamp-1">{product.name_bn}</span>
        </nav>

        {/* Main Product Showcase Split */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 bg-white rounded-2xl p-4 sm:p-8 border border-[#E8DFD3] shadow-xs">
          {/* Gallery Column (Left 7 Cols) */}
          <div className="lg:col-span-7 flex flex-col gap-4">
            {/* Primary Display Viewport */}
            <div className="relative rounded-xl overflow-hidden bg-[#FAF7F2] border border-[#E8DFD3]">
              <SafeImage
                src={selectedImage || product.main_image}
                alt={product.name_bn}
                aspectRatioClass="aspect-[4/3] sm:aspect-[16/10]"
              />

              {hasDiscount && (
                <div className="absolute top-3 left-3 bg-[#B45309] text-white text-xs font-bold px-3 py-1 rounded shadow-sm">
                  ছাড় মূল্য
                </div>
              )}
            </div>

            {/* Thumbnail Selectors */}
            {allImages.length > 1 && (
              <div className="flex items-center gap-3 overflow-x-auto pb-2">
                {allImages.map((img, idx) => (
                  <button
                    key={idx}
                    onClick={() => setSelectedImage(img)}
                    className={`relative w-20 h-16 rounded-lg overflow-hidden border-2 transition-all shrink-0 ${
                      selectedImage === img
                        ? 'border-[#B45309] ring-2 ring-[#B45309]/30 scale-102'
                        : 'border-[#E5DACD] opacity-75 hover:opacity-100'
                    }`}
                  >
                    <img
                      src={img}
                      alt={`কোণ ${idx + 1}`}
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                  </button>
                ))}
              </div>
            )}

            {/* Quality & Service Guarantees Strip */}
            <div className="grid grid-cols-3 gap-2 sm:gap-4 mt-2 pt-4 border-t border-[#F2ECE3]">
              <div className="flex items-center gap-2 p-2 rounded-lg bg-[#FAF7F2]">
                <ShieldCheck className="w-5 h-5 text-[#B45309] shrink-0" />
                <div className="text-[11px] leading-tight">
                  <p className="font-bold text-[#2C1810]">১৫ বছর গ্যারান্টি</p>
                  <p className="text-[#7A695C]">ঘুণের সুরক্ষা</p>
                </div>
              </div>

              <div className="flex items-center gap-2 p-2 rounded-lg bg-[#FAF7F2]">
                <Truck className="w-5 h-5 text-[#B45309] shrink-0" />
                <div className="text-[11px] leading-tight">
                  <p className="font-bold text-[#2C1810]">হোম ডেলিভারি</p>
                  <p className="text-[#7A695C]">সারা বাংলাদেশে</p>
                </div>
              </div>

              <div className="flex items-center gap-2 p-2 rounded-lg bg-[#FAF7F2]">
                <RotateCcw className="w-5 h-5 text-[#B45309] shrink-0" />
                <div className="text-[11px] leading-tight">
                  <p className="font-bold text-[#2C1810]">সার্ভিসিং সাপোর্ট</p>
                  <p className="text-[#7A695C]">১ বছর ফ্রি সার্ভিস</p>
                </div>
              </div>
            </div>
          </div>

          {/* Product Purchase & Details Module (Right 5 Cols) */}
          <div className="lg:col-span-5 flex flex-col justify-between">
            <div>
              {/* Category & Code */}
              <div className="flex items-center justify-between text-xs text-[#8B7363] mb-2">
                <span className="font-semibold uppercase tracking-wider">
                  ক্যাটাগরি: {product.category_slug}
                </span>
                <button
                  onClick={handleShare}
                  className="flex items-center gap-1 text-[#8B4513] hover:text-[#B45309]"
                >
                  {copiedLink ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Share2 className="w-3.5 h-3.5" />}
                  <span>{copiedLink ? 'কপি হয়েছে' : 'শেয়ার করুন'}</span>
                </button>
              </div>

              {/* Title */}
              <h1 className="text-2xl sm:text-3xl font-bold text-[#2C1810] leading-snug">
                {product.name_bn}
              </h1>
              <p className="text-xs text-[#A28B78] uppercase font-semibold mt-0.5">
                {product.name_en}
              </p>

              {/* Price Banner */}
              <div className="mt-4 p-3.5 rounded-xl bg-[#FAF7F2] border border-[#E8DFD3] flex items-baseline justify-between">
                <div>
                  <span className="text-2xl sm:text-3xl font-bold text-[#8B4513] tabular-nums">
                    {formattedPrice}
                  </span>
                  {hasDiscount && (
                    <span className="ml-3 text-sm text-[#9CA3AF] line-through tabular-nums">
                      {formattedOriginalPrice}
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-1.5 text-xs font-semibold">
                  {product.in_stock ? (
                    <span className="flex items-center gap-1 text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                      ইন স্টক
                    </span>
                  ) : (
                    <span className="flex items-center gap-1 text-amber-800 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                      <Clock className="w-3.5 h-3.5 text-amber-600" />
                      অর্ডারে তৈরি
                    </span>
                  )}
                </div>
              </div>

              {/* Short Bio */}
              <p className="mt-4 text-sm text-[#5A483C] leading-relaxed">
                {product.short_desc_bn}
              </p>

              {/* Specifications Block */}
              <div className="mt-6 space-y-3 pt-4 border-t border-[#F0EAE1]">
                {/* Dimensions */}
                {product.dimensions && (
                  <div className="flex items-start gap-3">
                    <Ruler className="w-4 h-4 text-[#8B4513] shrink-0 mt-0.5" />
                    <div className="text-xs sm:text-sm">
                      <span className="font-bold text-[#2C1810]">পরিমাপ (Dimensions): </span>
                      <span className="text-[#5A483C]">{product.dimensions}</span>
                    </div>
                  </div>
                )}

                {/* Materials */}
                {product.materials && (
                  <div className="flex items-start gap-3">
                    <Layers className="w-4 h-4 text-[#8B4513] shrink-0 mt-0.5" />
                    <div className="text-xs sm:text-sm">
                      <span className="font-bold text-[#2C1810]">কাঠ ও ম্যাটেরিয়াল: </span>
                      <span className="text-[#5A483C]">{product.materials}</span>
                    </div>
                  </div>
                )}

                {/* Colors */}
                {product.colors && product.colors.length > 0 && (
                  <div className="flex items-start gap-3">
                    <Palette className="w-4 h-4 text-[#8B4513] shrink-0 mt-0.5" />
                    <div className="text-xs sm:text-sm">
                      <span className="font-bold text-[#2C1810]">কালার ও পলিশ: </span>
                      <div className="flex flex-wrap gap-1.5 mt-1.5">
                        {product.colors.map((color, idx) => (
                          <button
                            key={idx}
                            onClick={() => setSelectedColor(color)}
                            className={`px-2.5 py-1 text-xs font-medium rounded border transition-colors ${
                              selectedColor === color
                                ? 'bg-[#4A2818] text-white border-[#4A2818]'
                                : 'bg-[#FAF7F2] text-[#4A3B32] border-[#D8CEBF] hover:border-[#8B4513]'
                            }`}
                          >
                            {color}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Direct Order / Contact Action Strip */}
            <div className="mt-8 pt-4 border-t border-[#F0EAE1] space-y-3">
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full flex items-center justify-center gap-2.5 py-3.5 px-4 rounded-xl bg-[#25D366] text-white font-bold text-sm sm:text-base hover:bg-[#20BA5A] shadow-sm hover:shadow transition-all"
              >
                <MessageCircle className="w-5 h-5" />
                <span>হোয়াটসঅ্যাপে সরাসরি অর্ডার / তথ্য জানুন</span>
              </a>

              <div className="grid grid-cols-2 gap-2">
                <a
                  href={`tel:${phonePrimary.replace(/[^0-9+]/g, '')}`}
                  className="flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-white border border-[#D5C2B1] text-[#2C1810] font-semibold text-xs sm:text-sm hover:bg-[#FAF7F2]"
                >
                  <Phone className="w-4 h-4 text-[#8B4513]" />
                  <span>সরাসরি কল</span>
                </a>

                <button
                  onClick={() => onOpenInquiryModal(product)}
                  className="flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-[#B45309] text-white font-semibold text-xs sm:text-sm hover:bg-[#92400E] shadow-xs"
                >
                  <span>অনলাইনে মেসেজ পাঠান</span>
                </button>
              </div>

              <p className="text-[11px] text-center text-[#8B7363]">
                শো-রুম ভিজিট করতে চাইলে আমাদের মিরপুর শাখায় স্বাগতম।
              </p>
            </div>
          </div>
        </div>

        {/* Full Bengali Description Section */}
        <div className="mt-8 bg-white rounded-2xl p-6 sm:p-8 border border-[#E8DFD3]">
          <h2 className="text-lg sm:text-xl font-bold text-[#2C1810] pb-3 border-b border-[#F2ECE3] mb-4">
            পণ্যটির বিস্তারিত বিবরণ
          </h2>
          <div className="text-sm sm:text-base text-[#4A3B32] leading-relaxed whitespace-pre-line">
            {product.full_desc_bn}
          </div>
        </div>

        {/* Ad Placement Below Product Information */}
        {adBelowInfo && (
          <div className="mt-8">
            <AdvertisementBanner ad={adBelowInfo} />
          </div>
        )}

        {/* Related Products Section */}
        {relatedProducts && relatedProducts.length > 0 && (
          <div className="mt-12 sm:mt-16">
            <div className="flex items-center justify-between pb-3 border-b border-[#E8DFD3] mb-6">
              <div>
                <h3 className="text-xl sm:text-2xl font-bold text-[#2C1810]">
                  একই ক্যাটাগরির অন্যান্য ফার্নিচার
                </h3>
                <p className="text-xs sm:text-sm text-[#7A695C]">
                  আপনার ঘরের সৌন্দর্য আরও বাড়িয়ে তুলতে পারেন এসব ডিজাইনে।
                </p>
              </div>
              <button
                onClick={() => onNavigateCategory(product.category_slug)}
                className="text-xs sm:text-sm font-bold text-[#B45309] hover:underline"
              >
                সবগুলো দেখুন
              </button>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-6">
              {relatedProducts.map(rel => (
                <ProductCard
                  key={rel.id}
                  product={rel}
                  settings={settings}
                  onViewDetails={onViewProduct}
                />
              ))}
            </div>
          </div>
        )}

        {/* Ad Placement Below Related Products */}
        {adBelowRelated && (
          <div className="mt-12">
            <AdvertisementBanner ad={adBelowRelated} />
          </div>
        )}
      </div>
    </div>
  );
}
