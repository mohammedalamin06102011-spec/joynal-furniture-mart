import { Product, WebsiteSettings } from '../types.ts';
import SafeImage from './SafeImage.tsx';
import { Eye, MessageCircle, Phone } from 'lucide-react';

interface ProductCardProps {
  product: Product;
  settings?: WebsiteSettings;
  onViewDetails: (product: Product) => void;
  onQuickContact?: (product: Product) => void;
}

export default function ProductCard({
  product,
  settings,
  onViewDetails,
  onQuickContact
}: ProductCardProps) {
  const currentPrice = product.discount_price || product.price;
  const hasDiscount = Boolean(product.discount_price && product.discount_price < product.price);

  const formattedPrice = `৳ ${currentPrice.toLocaleString('en-US')}`;
  const formattedOriginalPrice = `৳ ${product.price.toLocaleString('en-US')}`;

  const whatsappNumber = settings?.whatsapp_number?.replace(/[^0-9]/g, '') || '8801712345678';
  const whatsappText = encodeURIComponent(
    `আসসালামু আলাইকুম, আমি জয়নাল ফার্নিচার মার্ট থেকে "${product.name_bn}" (মূল্য: ${formattedPrice}) সম্পর্কে জানতে আগ্রহী। এই পণ্যটি কি স্টকে পাওয়া যাবে?`
  );
  const whatsappUrl = `https://wa.me/${whatsappNumber}?text=${whatsappText}`;

  return (
    <div className="group flex flex-col bg-white rounded-xl overflow-hidden border border-[#EBE3D7] shadow-sm hover:shadow-md transition-all duration-300">
      {/* Product Image Box */}
      <div
        className="relative cursor-pointer overflow-hidden bg-[#FAF7F2]"
        onClick={() => onViewDetails(product)}
      >
        <SafeImage
          src={product.main_image}
          alt={product.name_bn}
          aspectRatioClass="aspect-[4/3]"
          className="group-hover:scale-105 transition-transform duration-500"
        />

        {/* Stock / Discount Tags */}
        <div className="absolute top-2.5 left-2.5 flex flex-col gap-1 items-start">
          {hasDiscount && (
            <span className="bg-[#B45309] text-white text-[11px] font-semibold px-2 py-0.5 rounded shadow-sm">
              ছাড় অফার
            </span>
          )}
          {!product.in_stock && (
            <span className="bg-[#4A2818]/90 text-amber-100 text-[11px] font-medium px-2 py-0.5 rounded backdrop-blur-xs">
              অর্ডার সাপেক্ষে
            </span>
          )}
        </div>
      </div>

      {/* Card Body */}
      <div className="p-3.5 sm:p-4 flex flex-col flex-1 justify-between">
        <div>
          {/* Category kicker */}
          <span className="text-[11px] font-semibold tracking-wider text-[#A28B78] uppercase">
            {product.category_slug}
          </span>

          {/* Product Title */}
          <h3
            onClick={() => onViewDetails(product)}
            className="text-sm sm:text-base font-bold text-[#2C1810] mt-1 line-clamp-1 hover:text-[#B45309] cursor-pointer transition-colors"
          >
            {product.name_bn}
          </h3>

          {/* Short description */}
          <p className="text-xs text-[#6B5A4E] mt-1 line-clamp-2 leading-relaxed">
            {product.short_desc_bn}
          </p>
        </div>

        <div className="mt-3 pt-3 border-t border-[#F0EAE1]">
          {/* Price display */}
          <div className="flex items-baseline gap-2 mb-3">
            <span className="text-base sm:text-lg font-bold text-[#8B4513] tabular-nums">
              {formattedPrice}
            </span>
            {hasDiscount && (
              <span className="text-xs text-[#9CA3AF] line-through tabular-nums">
                {formattedOriginalPrice}
              </span>
            )}
          </div>

          {/* Action Buttons */}
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => onViewDetails(product)}
              className="flex items-center justify-center gap-1.5 py-2 px-2.5 text-xs font-semibold rounded-lg bg-[#FAF7F2] text-[#2C1810] border border-[#D8CEBF] hover:bg-[#F3ECE0] hover:border-[#8B4513] transition-colors"
            >
              <Eye className="w-3.5 h-3.5 text-[#8B4513]" />
              <span>বিস্তারিত</span>
            </button>

            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              onClick={(e) => {
                if (onQuickContact) {
                  // Allow quick action or direct link
                }
              }}
              className="flex items-center justify-center gap-1.5 py-2 px-2.5 text-xs font-semibold rounded-lg bg-[#B45309] text-white hover:bg-[#92400E] shadow-xs hover:shadow transition-all"
            >
              <MessageCircle className="w-3.5 h-3.5" />
              <span>যোগাযোগ</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
