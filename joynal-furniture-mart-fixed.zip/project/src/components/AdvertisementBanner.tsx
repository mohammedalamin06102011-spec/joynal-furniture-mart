import { useState } from 'react';
import { Advertisement } from '../types.ts';
import { Megaphone, ExternalLink } from 'lucide-react';

interface AdBannerProps {
  ad?: Advertisement | null;
  className?: string;
  onNavigate?: (url: string) => void;
}

export default function AdvertisementBanner({ ad, className = '', onNavigate }: AdBannerProps) {
  const [imageError, setImageError] = useState(false);

  if (!ad || !ad.is_enabled) {
    return null;
  }

  // Check start and end dates
  const today = new Date().toISOString().split('T')[0];
  if (ad.start_date && ad.start_date > today) return null;
  if (ad.end_date && ad.end_date < today) return null;
  if (!ad.image_url && !ad.title) return null;

  const handleClick = (e: React.MouseEvent) => {
    if (!ad.destination_url) return;
    if (ad.destination_url.startsWith('http://') || ad.destination_url.startsWith('https://')) {
      window.open(ad.destination_url, '_blank', 'noopener,noreferrer');
    } else if (onNavigate) {
      e.preventDefault();
      onNavigate(ad.destination_url);
    }
  };

  return (
    <div
      onClick={handleClick}
      className={`relative w-full overflow-hidden rounded-xl bg-gradient-to-r from-[#2C1810] via-[#4A2818] to-[#2C1810] border border-[#5C3825]/40 text-white cursor-pointer group shadow-sm transition-all hover:shadow-md ${className}`}
    >
      <div className="flex items-center justify-between px-3 py-1.5 bg-black/25 text-[11px] text-amber-200/90 font-medium">
        <span className="flex items-center gap-1.5 tracking-wider uppercase">
          <Megaphone className="w-3.5 h-3.5 text-amber-400" />
          বিশেষ অফার ও বিজ্ঞাপন
        </span>
        <span className="flex items-center gap-1 text-[11px] text-amber-300 group-hover:underline">
          বিস্তারিত দেখুন <ExternalLink className="w-3 h-3" />
        </span>
      </div>

      <div className="relative">
        {ad.image_url && !imageError ? (
          <img
            src={ad.image_url}
            alt={ad.title || 'স্পেশাল অফার'}
            referrerPolicy="no-referrer"
            onError={() => setImageError(true)}
            className="w-full max-h-48 md:max-h-64 object-cover object-center transition-transform duration-500 group-hover:scale-[1.01]"
          />
        ) : (
          <div className="py-8 px-6 text-center">
            <h4 className="text-lg md:text-xl font-bold text-amber-100">{ad.title}</h4>
            <p className="text-xs md:text-sm text-amber-200/80 mt-1">জয়নাল ফার্নিচার মার্টের প্রিমিয়াম আসবাবে আকর্ষণীয় সুযোগ</p>
          </div>
        )}

        {ad.title && ad.image_url && !imageError && (
          <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent p-3 pt-6">
            <p className="text-xs md:text-sm font-semibold text-white drop-shadow-sm">{ad.title}</p>
          </div>
        )}
      </div>
    </div>
  );
}
