import { useState } from 'react';
import { WebsiteSettings } from '../types.ts';
import { submitInquiry } from '../services/api.ts';
import {
  Phone,
  MessageCircle,
  MapPin,
  Mail,
  Facebook,
  Clock,
  Send,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';

interface ContactPageProps {
  settings?: WebsiteSettings;
}

export default function ContactPage({ settings }: ContactPageProps) {
  const [customerName, setCustomerName] = useState('');
  const [phone, setPhone] = useState('');
  const [message, setMessage] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  const phonePrimary = settings?.phone_primary || '+880 1712-345678';
  const phoneSecondary = settings?.phone_secondary || '+880 1812-987654';
  const whatsappNumber = settings?.whatsapp_number?.replace(/[^0-9]/g, '') || '8801712345678';
  const addressBn =
    settings?.address_bn || 'দোকান নং ১২-১৫, প্রধান সড়ক, মিরপুর-১০ গোলচত্বর, ঢাকা-১২১৬';
  const email = settings?.email || 'info@joynalfurniture.com';
  const facebookUrl = settings?.facebook_url || 'https://facebook.com';

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName.trim() || !phone.trim()) {
      setErrorMessage('দয়া করে আপনার নাম এবং মোবাইল নম্বর প্রদান করুন।');
      return;
    }

    try {
      setIsSubmitting(true);
      setErrorMessage('');
      await submitInquiry({
        customer_name: customerName,
        phone,
        message
      });
      setSubmitSuccess(true);
      setCustomerName('');
      setPhone('');
      setMessage('');
    } catch (err: any) {
      setErrorMessage(err.message || 'মেসেজ পাঠাতে সমস্যা হয়েছে। আবার চেষ্টা করুন।');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#FAF7F2] py-8 sm:py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-10 sm:mb-14">
          <span className="text-xs font-semibold text-[#8B4513] uppercase tracking-wider">
            যোগাযোগ ও অবস্থান
          </span>
          <h1 className="text-3xl sm:text-4xl font-bold text-[#2C1810] mt-1">
            আমাদের সাথে যোগাযোগ করুন
          </h1>
          <p className="text-sm sm:text-base text-[#6B5A4E] mt-2">
            ফার্নিচার অর্ডার, কাস্টমাইজড ডিজাইন তৈরি বা যেকোনো তথ্যের জন্য আমাদের শো-রুমে আসুন অথবা সরাসরি কল বা হোয়াটসঅ্যাপে কথা বলুন।
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Contact Details Cards (Left 5 Cols) */}
          <div className="lg:col-span-5 space-y-4">
            {/* Showroom Address */}
            <div className="bg-white rounded-2xl p-5 sm:p-6 border border-[#E8DFD3] shadow-xs flex items-start gap-4">
              <div className="w-11 h-11 rounded-xl bg-[#FAF7F2] border border-[#E5DACD] flex items-center justify-center text-[#8B4513] shrink-0">
                <MapPin className="w-5 h-5 text-[#B45309]" />
              </div>
              <div>
                <h3 className="text-base font-bold text-[#2C1810]">শো-রুমের ঠিকানা</h3>
                <p className="text-xs sm:text-sm text-[#5A483C] mt-1 leading-relaxed">
                  {addressBn}
                </p>
                <p className="text-xs text-[#8B7363] mt-1">{settings?.address_en}</p>
              </div>
            </div>

            {/* Direct Phone Numbers */}
            <div className="bg-white rounded-2xl p-5 sm:p-6 border border-[#E8DFD3] shadow-xs flex items-start gap-4">
              <div className="w-11 h-11 rounded-xl bg-[#FAF7F2] border border-[#E5DACD] flex items-center justify-center text-[#8B4513] shrink-0">
                <Phone className="w-5 h-5 text-[#B45309]" />
              </div>
              <div className="flex-1">
                <h3 className="text-base font-bold text-[#2C1810]">মোবাইল নম্বর</h3>
                <div className="mt-2 space-y-1.5">
                  <a
                    href={`tel:${phonePrimary.replace(/[^0-9+]/g, '')}`}
                    className="block text-sm font-semibold text-[#8B4513] hover:text-[#B45309] tabular-nums"
                  >
                    {phonePrimary} (হটলাইন)
                  </a>
                  {phoneSecondary && (
                    <a
                      href={`tel:${phoneSecondary.replace(/[^0-9+]/g, '')}`}
                      className="block text-sm font-semibold text-[#5A483C] hover:text-[#B45309] tabular-nums"
                    >
                      {phoneSecondary}
                    </a>
                  )}
                </div>
              </div>
            </div>

            {/* WhatsApp Direct Chat */}
            <div className="bg-white rounded-2xl p-5 sm:p-6 border border-[#E8DFD3] shadow-xs flex items-start gap-4">
              <div className="w-11 h-11 rounded-xl bg-[#25D366]/15 border border-[#25D366]/30 flex items-center justify-center text-[#128C7E] shrink-0">
                <MessageCircle className="w-5 h-5" />
              </div>
              <div className="flex-1">
                <h3 className="text-base font-bold text-[#2C1810]">হোয়াটসঅ্যাপ হেল্পলাইন</h3>
                <p className="text-xs text-[#6B5A4E] mt-0.5">ছবি পাঠিয়ে সরাসরি কোটেশন নিন</p>
                <a
                  href={`https://wa.me/${whatsappNumber}?text=${encodeURIComponent('আসসালামু আলাইকুম, আমি জয়নাল ফার্নিচার মার্ট থেকে তথ্য জানতে চাচ্ছি।')}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 mt-3 px-3.5 py-1.5 text-xs font-bold rounded-lg bg-[#25D366] text-white hover:bg-[#20BA5A] shadow-xs"
                >
                  <MessageCircle className="w-3.5 h-3.5" />
                  <span>চ্যাট শুরু করুন</span>
                </a>
              </div>
            </div>

            {/* Social & Email */}
            <div className="bg-white rounded-2xl p-5 sm:p-6 border border-[#E8DFD3] shadow-xs flex flex-col gap-3">
              <div className="flex items-center gap-3">
                <Mail className="w-4 h-4 text-[#8B4513]" />
                <span className="text-xs sm:text-sm text-[#4A3B32]">{email}</span>
              </div>
              <div className="flex items-center gap-3">
                <Facebook className="w-4 h-4 text-[#1877F2]" />
                <a
                  href={facebookUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-xs sm:text-sm font-semibold text-[#1877F2] hover:underline"
                >
                  ফেসবুক পেজ ভিজিট করুন
                </a>
              </div>
              <div className="flex items-center gap-3 pt-2 border-t border-[#F2ECE3]">
                <Clock className="w-4 h-4 text-[#8B4513]" />
                <span className="text-xs text-[#6B5A4E]">
                  শো-রুম খোলা: প্রতিদিন সকাল ১০টা – রাত ৯টা (শুক্রবার খোলা)
                </span>
              </div>
            </div>
          </div>

          {/* Contact Inquiry Form (Right 7 Cols) */}
          <div className="lg:col-span-7 bg-white rounded-2xl p-6 sm:p-8 border border-[#E8DFD3] shadow-xs">
            <h2 className="text-xl sm:text-2xl font-bold text-[#2C1810]">
              অনলাইনে মেসেজ পাঠান
            </h2>
            <p className="text-xs sm:text-sm text-[#6B5A4E] mt-1 mb-6">
              আপনার চাহিদা অনুযায়ী পছন্দের মাপ বা কাঠের বিবরণ লিখে পাঠান, আমাদের প্রতিনিধি অতি দ্রুত আপনার সাথে যোগাযোগ করবেন।
            </p>

            {submitSuccess ? (
              <div className="p-6 rounded-xl bg-emerald-50 border border-emerald-200 text-center my-4 animate-fadeIn">
                <CheckCircle2 className="w-12 h-12 text-emerald-600 mx-auto mb-2" />
                <h3 className="text-base font-bold text-emerald-900">
                  ধন্যবাদ! আপনার মেসেজটি সফলভাবে গৃহীত হয়েছে।
                </h3>
                <p className="text-xs text-emerald-700 mt-1">
                  আমাদের শো-রুম এক্সিকিউটিভ খুব শীঘ্রই আপনার সাথে যোগাযোগ করবেন।
                </p>
                <button
                  onClick={() => setSubmitSuccess(false)}
                  className="mt-4 px-4 py-2 text-xs font-semibold rounded-lg bg-white border border-emerald-300 text-emerald-800 hover:bg-emerald-100"
                >
                  আরেকটি মেসেজ পাঠান
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                {errorMessage && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 flex items-center gap-2 text-xs text-red-800">
                    <AlertCircle className="w-4 h-4 shrink-0" />
                    <span>{errorMessage}</span>
                  </div>
                )}

                <div>
                  <label className="block text-xs font-bold text-[#2C1810] mb-1">
                    আপনার নাম *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="যেমন: মোঃ রফিকুল ইসলাম"
                    value={customerName}
                    onChange={e => setCustomerName(e.target.value)}
                    className="w-full px-3.5 py-2.5 text-sm bg-[#FAF7F2] border border-[#D8CEBF] rounded-xl text-[#2C1810] focus:outline-none focus:border-[#8B4513]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#2C1810] mb-1">
                    মোবাইল নম্বর *
                  </label>
                  <input
                    type="tel"
                    required
                    placeholder="যেমন: 017xxxxxxxx"
                    value={phone}
                    onChange={e => setPhone(e.target.value)}
                    className="w-full px-3.5 py-2.5 text-sm bg-[#FAF7F2] border border-[#D8CEBF] rounded-xl text-[#2C1810] focus:outline-none focus:border-[#8B4513]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#2C1810] mb-1">
                    আপনার প্রশ্ন বা পছন্দের আসবাবের বিবরণ
                  </label>
                  <textarea
                    rows={4}
                    placeholder="যেমন: আমি একটি ৬ ফুট × ৭ ফুট সেগুন কাঠের খাট তৈরি করতে চাই..."
                    value={message}
                    onChange={e => setMessage(e.target.value)}
                    className="w-full px-3.5 py-2.5 text-sm bg-[#FAF7F2] border border-[#D8CEBF] rounded-xl text-[#2C1810] focus:outline-none focus:border-[#8B4513] resize-none"
                  />
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full flex items-center justify-center gap-2 py-3 px-6 rounded-xl bg-[#B45309] text-white font-bold text-sm sm:text-base hover:bg-[#92400E] shadow-sm hover:shadow transition-all disabled:opacity-50"
                >
                  <Send className="w-4 h-4" />
                  <span>{isSubmitting ? 'পাঠানো হচ্ছে...' : 'মেসেজ জমা দিন'}</span>
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
