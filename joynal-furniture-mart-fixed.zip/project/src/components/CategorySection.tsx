import { Category } from '../types.ts';
import SafeImage from './SafeImage.tsx';
import { ArrowRight, Layers } from 'lucide-react';

interface CategorySectionProps {
  categories: Category[];
  onSelectCategory: (categorySlug: string) => void;
}

export default function CategorySection({ categories, onSelectCategory }: CategorySectionProps) {
  return (
    <section className="py-12 sm:py-16 bg-[#FAF7F2]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 sm:mb-10 pb-4 border-b border-[#E8DFD3] gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#8B4513] uppercase tracking-wider mb-1">
              <Layers className="w-3.5 h-3.5" />
              <span>ফার্নিচার ক্যাটাগরি</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-bold text-[#2C1810]">
              পছন্দের ক্যাটাগরি বেছে নিন
            </h2>
            <p className="text-sm text-[#6B5A4E] mt-1 max-w-xl">
              খাট, সোফা, ডাইনিং টেবিল ও আলমারি সহ আপনার ঘরের প্রতিটি রুমের জন্য মানসম্মত কাঠের আসবাব।
            </p>
          </div>

          <span className="text-xs text-[#8B7363] font-medium hidden sm:inline">
            সর্বমোট {categories.length} টি ক্যাটাগরি
          </span>
        </div>

        {/* Category Cards Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
          {categories.map(cat => (
            <div
              key={cat.id}
              onClick={() => onSelectCategory(cat.slug)}
              className="group flex flex-col bg-white rounded-xl overflow-hidden border border-[#E8DFD3] shadow-xs hover:shadow-md transition-all duration-300 cursor-pointer"
            >
              {/* Category Cover Image */}
              <div className="relative overflow-hidden bg-[#F0EAE1]">
                <SafeImage
                  src={cat.cover_image}
                  alt={cat.name_bn}
                  aspectRatioClass="aspect-[4/3]"
                  className="group-hover:scale-106 transition-transform duration-500"
                />

                {/* Optional Product Count Overlay */}
                {typeof cat.product_count === 'number' && (
                  <div className="absolute top-2.5 right-2.5 bg-black/60 backdrop-blur-xs text-white text-[11px] font-medium px-2 py-0.5 rounded">
                    {cat.product_count} টি পণ্য
                  </div>
                )}
              </div>

              {/* Category Info */}
              <div className="p-3.5 sm:p-4 flex flex-col flex-1 justify-between">
                <div>
                  <h3 className="text-base sm:text-lg font-bold text-[#2C1810] group-hover:text-[#B45309] transition-colors">
                    {cat.name_bn}
                  </h3>
                  <span className="text-[11px] font-medium text-[#A28B78] uppercase">
                    {cat.name_en}
                  </span>
                  {cat.description_bn && (
                    <p className="text-xs text-[#6B5A4E] mt-1.5 line-clamp-2 leading-relaxed">
                      {cat.description_bn}
                    </p>
                  )}
                </div>

                <div className="mt-3 pt-3 border-t border-[#F2ECE3] flex items-center justify-between text-xs font-semibold text-[#8B4513] group-hover:text-[#B45309]">
                  <span>পণ্য দেখুন</span>
                  <ArrowRight className="w-4 h-4 transform group-hover:translate-x-1 transition-transform" />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
