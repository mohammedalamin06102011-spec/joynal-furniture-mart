import { WebsiteSettings } from '../types.ts';
import { ShieldCheck, Award, Hammer, Clock, CheckCircle2, Phone, MapPin } from 'lucide-react';

interface AboutSectionProps {
  settings?: WebsiteSettings;
  onContactClick: () => void;
}

export default function AboutSection({ settings, onContactClick }: AboutSectionProps) {
  const phonePrimary = settings?.phone_primary || '+880 1712-345678';
  const addressBn =
    settings?.address_bn || 'দোকান নং ১২-১৫, প্রধান সড়ক, মিরপুর-১০ গোলচত্বর, ঢাকা-১২১৬';

  return (
    <section className="py-12 sm:py-16 bg-[#F5EFE6] border-y border-[#E8DFD3]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          {/* Left Text */}
          <div className="lg:col-span-7">
            <div className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#8B4513] uppercase tracking-wider mb-2">
              <Award className="w-3.5 h-3.5" />
              <span>আমাদের সম্পর্কে ও প্রতিশ্রুতি</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-bold text-[#2C1810]">
              জয়নাল ফার্নিচার মার্ট — তিন দশকের আস্থার প্রতীক
            </h2>
            <p className="text-sm sm:text-base text-[#5A483C] mt-4 leading-relaxed">
              {settings?.about_story_bn ||
                'জয়নাল ফার্নিচার মার্ট দীর্ঘ ৩০ বছর ধরে গুণগত মান ও সততার সাথে বাংলাদেশের গৃহসজ্জা ও কর্পোরেট প্রতিষ্ঠানে কাঠজাত ফার্নিচার সরবরাহ করে আসছে। আমাদের প্রতিটি ফার্নিচারে রয়েছে স্থায়িত্ব ও নান্দনিক আভিজাত্যের নিশ্চয়তা।'}
            </p>

            {/* Feature Bullets */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-6">
              <div className="flex items-start gap-3 bg-white/80 p-3.5 rounded-xl border border-[#E5DACD]">
                <ShieldCheck className="w-5 h-5 text-[#B45309] shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-sm font-bold text-[#2C1810]">১৫ বছরের ঘুণের গ্যারান্টি</h4>
                  <p className="text-xs text-[#7A695C] mt-0.5">
                    উন্নত সিজনিং ও কেমিক্যাল ট্রিটমেন্টের মাধ্যমে কাঠে দীর্ঘস্থায়ী সুরক্ষা।
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3 bg-white/80 p-3.5 rounded-xl border border-[#E5DACD]">
                <Award className="w-5 h-5 text-[#B45309] shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-sm font-bold text-[#2C1810]">১০০% খাঁটি সেগুন কাঠ</h4>
                  <p className="text-xs text-[#7A695C] mt-0.5">
                    অকৃত্রিম চিটাগাং সেগুন ও সিজনড মেহগনি কাঠের নিশ্চয়তা।
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3 bg-white/80 p-3.5 rounded-xl border border-[#E5DACD]">
                <Hammer className="w-5 h-5 text-[#B45309] shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-sm font-bold text-[#2C1810]">দক্ষ কারিগরি ও কাস্টমাইজেশন</h4>
                  <p className="text-xs text-[#7A695C] mt-0.5">
                    আপনার ঘর ও রুচির মাপ অনুযায়ী যেকোনো ডিজাইনে ফার্নিচার তৈরির সুবিধা।
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3 bg-white/80 p-3.5 rounded-xl border border-[#E5DACD]">
                <Clock className="w-5 h-5 text-[#B45309] shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-sm font-bold text-[#2C1810]">সময়মতো নিরাপদ ডেলিভারি</h4>
                  <p className="text-xs text-[#7A695C] mt-0.5">
                    বিশেষ প্যাকেজিং সহ দেশের যেকোনো প্রান্তে নিখুঁত ডেলিভারি ব্যবস্থা।
                  </p>
                </div>
              </div>
            </div>

            <div className="mt-8 flex flex-wrap items-center gap-4">
              <button
                onClick={onContactClick}
                className="px-5 py-2.5 rounded-xl bg-[#B45309] text-white font-bold text-xs sm:text-sm hover:bg-[#92400E] shadow-xs"
              >
                আমাদের সাথে কথা বলুন
              </button>
              <div className="flex items-center gap-2 text-xs sm:text-sm font-bold text-[#2C1810]">
                <Phone className="w-4 h-4 text-[#8B4513]" />
                <span>হটলাইন: {phonePrimary}</span>
              </div>
            </div>
          </div>

          {/* Right Trust Showcase Card */}
          <div className="lg:col-span-5 bg-white p-6 sm:p-8 rounded-2xl border border-[#E8DFD3] shadow-sm">
            <h3 className="text-lg font-bold text-[#2C1810] pb-2 border-b border-[#F0EAE1]">
              কেন জয়নাল ফার্নিচার মার্ট বেছে নেবেন?
            </h3>

            <div className="mt-4 space-y-3.5">
              <div className="flex items-center gap-3">
                <CheckCircle2 className="w-4 h-4 text-[#B45309] shrink-0" />
                <span className="text-xs sm:text-sm text-[#4A3B32]">
                  অভিজ্ঞ কাঠ বিশেষজ্ঞ দ্বারা কাঠ নির্বাচন
                </span>
              </div>
              <div className="flex items-center gap-3">
                <CheckCircle2 className="w-4 h-4 text-[#B45309] shrink-0" />
                <span className="text-xs sm:text-sm text-[#4A3B32]">
                  হাতে খোদাই করা অনন্য শৈল্পিক নকশা
                </span>
              </div>
              <div className="flex items-center gap-3">
                <CheckCircle2 className="w-4 h-4 text-[#B45309] shrink-0" />
                <span className="text-xs sm:text-sm text-[#4A3B32]">
                  প্রাকৃতিক লাক্ষা পলিশ ও ইতালি পিইউ ফিনিশিং
                </span>
              </div>
              <div className="flex items-center gap-3">
                <CheckCircle2 className="w-4 h-4 text-[#B45309] shrink-0" />
                <span className="text-xs sm:text-sm text-[#4A3B32]">
                  ন্যায্য মূল্য ও দীর্ঘস্থায়িত্বের নিশ্চয়তা
                </span>
              </div>
              <div className="flex items-center gap-3">
                <CheckCircle2 className="w-4 h-4 text-[#B45309] shrink-0" />
                <span className="text-xs sm:text-sm text-[#4A3B32]">
                  ১ বছর বিক্রয়োত্তর ফ্রি সার্ভিসিং সেবা
                </span>
              </div>
            </div>

            <div className="mt-6 pt-5 border-t border-[#F0EAE1] bg-[#FAF7F2] p-4 rounded-xl">
              <div className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-[#8B4513] shrink-0 mt-0.5" />
                <div className="text-xs">
                  <p className="font-bold text-[#2C1810]">শো-রুম পরিদর্শন</p>
                  <p className="text-[#6B5A4E] mt-0.5">{addressBn}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
