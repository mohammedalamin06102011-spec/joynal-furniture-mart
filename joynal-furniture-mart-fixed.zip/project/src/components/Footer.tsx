import { Category, WebsiteSettings } from '../types.ts';
import { Armchair, Phone, MessageCircle, MapPin, Mail, ShieldCheck, ChevronRight } from 'lucide-react';

interface FooterProps {
  categories: Category[];
  settings?: WebsiteSettings;
  onSelectCategory: (slug: string) => void;
  onNavigate: (view: string) => void;
}

export default function Footer({
  categories,
  settings,
  onSelectCategory,
  onNavigate
}: FooterProps) {
  const phonePrimary = settings?.phone_primary || '+880 1712-345678';
  const whatsappNumber = settings?.whatsapp_number?.replace(/[^0-9]/g, '') || '8801712345678';
  const addressBn =
    settings?.address_bn || 'দোকান নং ১২-১৫, প্রধান সড়ক, মিরপুর-১০ গোলচত্বর, ঢাকা-১২১৬';
  const email = settings?.email || 'info@joynalfurniture.com';

  return (
    <footer className="bg-[#24130C] text-[#E0D5C7] pt-12 sm:pt-16 pb-8 border-t border-[#3D2316]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-8 lg:gap-12 pb-12 border-b border-[#3D2316]">
          {/* Brand & Story Col (Left 4 Cols) */}
          <div className="lg:col-span-4">
            <div
              onClick={() => onNavigate('home')}
              className="flex items-center gap-3 cursor-pointer group mb-4"
            >
              <div className="w-10 h-10 rounded-xl bg-[#8B4513] flex items-center justify-center text-amber-200">
                <Armchair className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-white tracking-tight">
                  {settings?.site_name_bn || 'জয়নাল ফার্নিচার মার্ট'}
                </h3>
                <span className="text-[11px] font-semibold tracking-wider text-amber-300/80 uppercase">
                  {settings?.site_name_en || 'Joynal Furniture Mart'}
                </span>
              </div>
            </div>

            <p className="text-xs sm:text-sm text-[#B7A495] leading-relaxed mb-4">
              {settings?.about_story_bn?.slice(0, 160) ||
                'জয়নাল ফার্নিচার মার্ট দীর্ঘ ৩০ বছর ধরে গুণগত মান ও বিশ্বস্ততার সাথে কাঠের আধুনিক ও ক্লাসিক ফার্নিচার প্রস্তুত ও সরবরাহ করে আসছে।'}
              ...
            </p>

            <div className="inline-flex items-center gap-2 p-2.5 rounded-lg bg-[#311B11] border border-[#482819] text-xs text-amber-200">
              <ShieldCheck className="w-4 h-4 text-amber-400 shrink-0" />
              <span>১৫ বছরের ঘুণের বিরুদ্ধে গ্যারান্টি</span>
            </div>
          </div>

          {/* Categories Quick Links (3 Cols) */}
          <div className="lg:col-span-3">
            <h4 className="text-sm font-bold text-white uppercase tracking-wider mb-4 pb-1 border-b border-[#3D2316] inline-block">
              জনপ্রিয় ক্যাটাগরি
            </h4>
            <ul className="space-y-2 text-xs sm:text-sm">
              {categories.slice(0, 6).map(cat => (
                <li key={cat.id}>
                  <button
                    onClick={() => onSelectCategory(cat.slug)}
                    className="flex items-center gap-1.5 text-[#B7A495] hover:text-white transition-colors"
                  >
                    <ChevronRight className="w-3.5 h-3.5 text-amber-500/70" />
                    <span>{cat.name_bn} কালেকশন</span>
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Quick Navigation (2 Cols) */}
          <div className="lg:col-span-2">
            <h4 className="text-sm font-bold text-white uppercase tracking-wider mb-4 pb-1 border-b border-[#3D2316] inline-block">
              প্রয়োজনীয় লিংক
            </h4>
            <ul className="space-y-2 text-xs sm:text-sm">
              <li>
                <button
                  onClick={() => onNavigate('home')}
                  className="text-[#B7A495] hover:text-white transition-colors"
                >
                  হোম পেজ
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('categories')}
                  className="text-[#B7A495] hover:text-white transition-colors"
                >
                  সকল ক্যাটাগরি
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('popular')}
                  className="text-[#B7A495] hover:text-white transition-colors"
                >
                  জনপ্রিয় পণ্য
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('about')}
                  className="text-[#B7A495] hover:text-white transition-colors"
                >
                  আমাদের সম্পর্কে
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('contact')}
                  className="text-[#B7A495] hover:text-white transition-colors"
                >
                  যোগাযোগ ও শো-রুম
                </button>
              </li>
            </ul>
          </div>

          {/* Contact Details (3 Cols) */}
          <div className="lg:col-span-3">
            <h4 className="text-sm font-bold text-white uppercase tracking-wider mb-4 pb-1 border-b border-[#3D2316] inline-block">
              শো-রুম ও যোগাযোগ
            </h4>
            <div className="space-y-3 text-xs sm:text-sm text-[#B7A495]">
              <div className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <span>{addressBn}</span>
              </div>
              <div className="flex items-center gap-2.5">
                <Phone className="w-4 h-4 text-amber-400 shrink-0" />
                <a
                  href={`tel:${phonePrimary.replace(/[^0-9+]/g, '')}`}
                  className="hover:text-white"
                >
                  {phonePrimary}
                </a>
              </div>
              <div className="flex items-center gap-2.5">
                <MessageCircle className="w-4 h-4 text-[#25D366] shrink-0" />
                <a
                  href={`https://wa.me/${whatsappNumber}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-amber-200 hover:underline"
                >
                  হোয়াটসঅ্যাপ: +{whatsappNumber}
                </a>
              </div>
              <div className="flex items-center gap-2.5">
                <Mail className="w-4 h-4 text-amber-400 shrink-0" />
                <span>{email}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Copyright & Guarantee */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[#8E7969] text-center sm:text-left">
          <p>© ২০২৬ জয়নাল ফার্নিচার মার্ট (Joynal Furniture Mart). সর্বস্বত্ব সংরক্ষিত।</p>
          <p className="text-[11px] text-[#A58D7B]">
            ১০০% খাঁটি সিজনড সেগুন ও মেহগনি কাঠ দিয়ে নির্মিত হস্তশিল্প ফার্নিচার।
          </p>
        </div>
      </div>
    </footer>
  );
}
